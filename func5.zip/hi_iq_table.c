/* HI-IQ System, the High Information Internet Query System,
	Copyright 1995, 1996, 1997, 1998 Utah Office of Health Data Analysis.

	hi_iq_table.c	11/11/98
	Format the query results into HTML tables.

	We provide the interactive interface to make your data available
	to public through Internet.
*/

#include "hi_iq.h"
#include "hi_iq_var.h"

void enc_note() {
	FILE * dat;
	char str[BUFFER_N], *tmp;

	if (!(tmp=get_sasname(str))) hbase_error(45, NULL);
	strcat(tmp, ".dat");
	if (!(dat=fopen(tmp, "r"))) hbase_error(12, tmp);
	while (!feof(dat)) {
		if (!(tmp=fgets(str, BUFFER_N, dat))) break;
		if ((form==1 || form==3 || form==4) && str[29]=='X') {
			printf("\n<font size=+1><b>NOTE:</b></font> The result in the cell with small number of observations was encrypted as <b>X</b>.");
			fflush(stdout);
			break; 
		}
	}
	fclose(dat);
}

int dat_get(char ***dx1t, char ***dx2t, char ***dyct, char *value) {
	char str[BUFFER_N], str2[BUFFER_N], *cross1, *cross2, *tmp;
	char **dx1, **dx2, **dyc;
	int i, j, k, flag=0;
	FILE * dat;
	NAME * n_ptr;

	if (cross1=find_path("cross1")) {
		if (!(n_ptr=find_name(cross1, 1))) cross1=NULL;
		else cross1=n_ptr->name_html;
	}
	if (cross2=find_path("cross2")) {
		if (!strcmp(cross2, "none")) cross2=NULL;
		else if (!(n_ptr=find_name(cross2, 1))) cross2=NULL;
			else cross2=n_ptr->name_html;
	}
	if (!(tmp=get_sasname(str))) hbase_error(45, NULL);
	strcat(tmp, value);
	strcat(tmp, ".dat");
	if (!(dat=fopen(tmp, "r"))) hbase_error(45, tmp);

	str[0]=0;
	tmp=fgets(str, BUFFER_N, dat);
	if (!tmp || (strlen(str)<=5)) {
		if (form!=21 && form!=22) std_html(3, 1);
		return(0);
	}

	for (i=0; !feof(dat); i++) 
		if (!(tmp=fgets(str, BUFFER_N, dat))) break;
	if (!(dx1=(char **) malloc((i+1)*sizeof(char *)))) hbase_error(3, "table-1");
	if (!(dx2=(char **) malloc((i+1)*sizeof(char *)))) hbase_error(3, "table-2");
	if (!(dyc=(char **) malloc((i+1)*sizeof(char *)))) hbase_error(3, "table-3");

	j=atoi(find_path("form"));
	rewind(dat);
	for (i=0; !feof(dat); i++) {
		if (!(tmp=fgets(str, BUFFER_N, dat))) break;
		if (j==2 && !isdigit(str[30]) && str[30]!=' ') {
			i--;
			continue;
		}
		for (k=0; k<15; k++) str2[k]=str[k];
		str2[k]=0;
		tmp=de_space(str2);
		dx1[i]=(char *) malloc((strlen(tmp)+1)*sizeof(char));
		strcpy(dx1[i], tmp);
		if (cross2) {
			for (k=15; k<30; k++) str2[k-15]=str[k];
			str2[k-15]=0;
			tmp=de_space(str2);
			dx2[i]=(char *) malloc((strlen(tmp)+1)*sizeof(char));
			strcpy(dx2[i], tmp);
		}
		else dx2=NULL;
		tmp=de_space(str+30);
		dyc[i]=(char *) malloc((strlen(tmp)+1)*sizeof(char));
		strcpy(dyc[i], tmp);
	}
	fclose(dat);
	*dx1t=dx1; *dx2t=dx2; *dyct=dyc;
	return(i);
}

int dat_get2(char ***dx1t, char ***dyct, char *value) {
	char str[BUFFER_N], str2[BUFFER_N], *tmp;
	char **dx1, **dyc;
	int i, j, k, flag=0;
	FILE * dat;

	if (!(tmp=get_sasname(str))) hbase_error(45, NULL);
	strcat(tmp, value);
	strcat(tmp, ".dat");
	if (!(dat=fopen(tmp, "r"))) hbase_error(45, tmp);
	str[0]=0;
	tmp=fgets(str, BUFFER_N, dat);
	if (!tmp || (strlen(str)<=5)) {
		std_html(3, 1);
		return(0);
	}

	for (i=0; !feof(dat); i++) 
		if (!(tmp=fgets(str, BUFFER_N, dat))) break;
	if (!(dx1=(char **) malloc((i+1)*sizeof(char *)))) hbase_error(3, "table-1");
	if (!(dyc=(char **) malloc((i+1)*sizeof(char *)))) hbase_error(3, "table-3");

	j=atoi(find_path("form"));
	rewind(dat);
	for (i=0; !feof(dat);) {
		if (!(tmp=fgets(str, BUFFER_N, dat))) break;
		if (!isdigit(str[30]) && str[30]!=' ') {
			continue;
		}
		for (k=15; k<30; k++) str2[k-15]=str[k];
		str2[k-15]=0;
		tmp=de_space(str2);
		if (atoi(tmp)==_out_variable) {
			for (k=0; k<15; k++) str2[k]=str[k];
			str2[k]=0;
			tmp=de_space(str2);
			dx1[i]=(char *) malloc((strlen(tmp)+1)*sizeof(char));
			strcpy(dx1[i], tmp);
		
			tmp=de_space(str+30);
			dyc[i]=(char *) malloc((strlen(tmp)+1)*sizeof(char));
			strcpy(dyc[i], tmp);
			i++;
		}
	}

	fclose(dat);
	*dx1t=dx1; *dyct=dyc;
	return(i);
}

void cross_in(CROS ** root, char * value) {
	CROS * cp1, * cp2, *cpt;

	cp1=*root;
	cp2=*root;
	cpt=*root;
	do {
		if (!cpt) {
			if (!(cpt=(CROS *) malloc(sizeof(CROS)))) hbase_error(3, "table-4");
			cpt->value=value;
			cpt->cros_ptr=NULL;
			cpt->number=1;
			*root=cpt;
			return;
		}

		if (!cp1) {
			if (!(cp2->cros_ptr=(struct CROS *) malloc(sizeof(CROS)))) hbase_error(3, "table-5");
			((CROS *)cp2->cros_ptr)->value=value;
			((CROS *)cp2->cros_ptr)->cros_ptr=NULL;
			cpt->number++;
			return;
		}
		if (!strcmp(cp1->value, value)) return;
		cp2=cp1;
		cp1=(CROS *)cp1->cros_ptr;

	} while (1);
}

void cross_list(char ***cxt, CROS * root) {
	CROS * cp1;
	char ** cx;
	int i=0;

	if (!(cx=(char **) malloc(root->number*sizeof(char **)))) hbase_error(3, "table-6");
	while (root) {
		cx[i]=root->value;
		i++;
		cp1=root;
		root=(CROS *)root->cros_ptr;
		if (!root) break;
		free(cp1);
	}
	free(cp1);
	*cxt=cx;
}

void dat_cross(char **dx1, char **dx2, char ***cx1t, char ***cx2t, int *c1, int *c2, int n) {
	int i;
	char ** cx1;
	CROS * root;

	root=NULL;
	for (i=0; i<n; i++) {
		cross_in(&root, dx1[i]);
	}
	if (root) {
		*c1=root->number;
		cross_list(&cx1, root);
		*cx1t=cx1;
	}
	else {
		*c1=0;
		cx1t=NULL;
	}
		
	if (dx2) {
		root=NULL;
		for (i=0; i<n; i++) {
			cross_in(&root, dx2[i]);
		}
		if (root) {
			*c2=root->number;
			cross_list(cx2t, root);
		}
		else {
			*c2=0;
			cx2t=NULL;
		}
	}
	else {
		*c2=0;
		cx2t=NULL;
	}
}

int dat_find(char **dx1, char **dx2, char *key1, char *key2, int n, int flag) {
	int i;

	if (flag) {
		for (i=0; i<n; i++) {
			if (!strcmp(dx1[i], key1) && !strcmp(dx2[i], key2)) return(i);
		}
	}
	else { 
		for (i=0; i<n; i++) {
			if (!strcmp(dx1[i], key1)) return(i);
		}
	}
	return(-1);
}

char *cross_back(char *cross, char *buf) {
	char *tmp, c;
	int i;
	VARI ** v_ptr;

	if ((!(tmp=strstr(cross, "_f"))) 
		|| (!(v_ptr=find_vari(cross, 1, 8, &i)))) {
		strcpy(buf, cross);
	}
	else {
		c=tmp[0];
		tmp[0]='\0';
		sprintf(buf, "%s%s", cross, v_ptr[0]->value);
		tmp[0]=c;
		free(v_ptr);
	}
	return buf;
}	

void tb_sub(char **dx1, char **dx2, char **dyc, char **cx1, char **cx2, char *lbl,
		int pb, int lb, int ps, int ls, int pc, int lc, int n) {
	int i, j, k, tc=0;
	char *bgcolor, *tabcolor[2];
	char *tmp, *tmp2, buf[BUFFER_N], *cross1, *cross2;
	NAME *n_ptr1=NULL, *n_ptr2=NULL;

	if (cross1=find_path("cross1")) {
		if (!(n_ptr1=find_name(cross1, 1))) cross1=NULL;
		else cross1=n_ptr1->name_html;
	}
	if (cross2=find_path("cross2")) {
		if (!strcmp(cross2, "none")) cross2=NULL;
		else if (!(n_ptr2=find_name(cross2, 1))) cross2=NULL;
			else cross2=n_ptr2->name_html;
	}

	printf("\n<center>");
	tmp=find_path("func");
	sprintf(buf, "func%s", tmp);
	if ((tmp=find_path(buf)))
		printf("\n<p><font size=+2>%s</font>", tmp);
	printf("\n<br><font size=+1>%s</font>", lbl);
	if ((strstr(tmp, "Age-adjusted"))) {
		tmp2=find_stdpop(1);
		printf("\n<br>(Standard population is %s.)", tmp2);
	}

	printf("\n<table border=1 cellpadding=1 cellspacing=0>");
	bgcolor=find_path("titlebg");
	tabcolor[0]=find_path("tablebg1");
	tabcolor[1]=find_path("tablebg2");
	if (bgcolor)
	  printf("\n<tr><th bgcolor=\"%s\">%s</th>", bgcolor, n_ptr1? n_ptr1->prompt : " ");
	else
	  printf("\n<tr><th>%s</th>", n_ptr1? n_ptr1->prompt : " ");
	i=lb>(lc+1)*ls ? ls : lb-lc*ls;
	i=ls ? i : 1;
	if (bgcolor)
	  printf("<th colspan=%d bgcolor=\"%s\">%s</th></tr>", i, bgcolor, n_ptr2 ? n_ptr2->prompt : " ");
	else
	  printf("<th colspan=%d>%s</th></tr>", i, n_ptr2 ? n_ptr2->prompt : " ");
	printf("\n<tr><th></th>");

	tmp2=find_path("sequence");
	if (cross2) {
		for(i=0; i<ls && (lc*ls+i)<lb; i++) {
			tmp=find_label(cross2, cx2[lc*ls+i]);
			if (cx2[lc*ls+i][0]=='.' ||
			    cx2[lc*ls+i][0]=='-' ||
			    cx2[lc*ls+i][0]==' ' ||
			    cx2[lc*ls+i][0]=='\0' ||
			    !tmp2 ||
			    tmp2[0]==' ' ||
			    tmp2[0]=='\0' ||
			    n_ptr2->type2[0]=='6') 
				if (bgcolor)
				printf("\n<th bgcolor=\"%s\">%s</th>", bgcolor, tmp? tmp : cx2[lc*ls+i]);
				else
				printf("\n<th>%s</th>", tmp? tmp : cx2[lc*ls+i]);
			else
if (bgcolor)
printf("\n<th bgcolor=\"%s\"><a href=\"javascript:drill_down('%s', '%s');\">%s</a></th>", 
			bgcolor, cross_back(cross2, buf), 
			n_ptr2->type2[0]=='8'? tmp : cx2[lc*ls+i], 
					tmp? tmp : cx2[lc*ls+i]);
				else
printf("\n<th><a href=\"javascript:drill_down('%s', '%s');\">%s</a></th>", 
			cross_back(cross2, buf), 
			n_ptr2->type2[0]=='8'? tmp : cx2[lc*ls+i], 
					tmp? tmp : cx2[lc*ls+i]);
		}
		printf("\n</tr>");
	
		for (j=0; j<ps && (pc*ps+j)<pb; j++) {
			tmp=find_label(cross1, cx1[pc*ps+j]);
			if (cx1[pc*ps+j][0]=='.' ||
			    cx1[pc*ps+j][0]=='-' ||
			    cx1[pc*ps+j][0]==' ' ||
			    cx1[pc*ps+j][0]=='\0' ||
			    tmp2[0]==' ' ||
			    tmp2[0]=='\0' )
			    if (bgcolor)
				printf("\n<tr><th bgcolor=\"%s\">%s</th>", bgcolor, tmp? tmp : cx1[pc*ps+j]);
			    else
				printf("\n<tr><th>%s</th>", tmp? tmp : cx1[pc*ps+j]);
			else
			   if (bgcolor)
				printf("\n<th bgcolor=\"%s\"><a href=\"javascript:drill_down('%s', '%s');\">%s</a></th>", 
					bgcolor, cross_back(cross1, buf), 
					n_ptr1->type2[0]=='8'? tmp : cx1[pc*ps+j], 
					tmp? tmp : cx1[pc*ps+j]);
			   else
				printf("\n<th><a href=\"javascript:drill_down('%s', '%s');\">%s</a></th>", 
					cross_back(cross1, buf), 
					n_ptr1->type2[0]=='8'? tmp : cx1[pc*ps+j], 
					tmp? tmp : cx1[pc*ps+j]);
			for(k=0; k<ls && (lc*ls+k)<lb; k++) {
				i=dat_find(dx1, dx2, cx1[pc*ps+j], cx2[lc*ls+k], n, 1);
				if (bgcolor)
				printf("\n<td bgcolor=\"%s\">%s</td>", tabcolor[tc], i==-1 ? "." : dyc[i]);
				else
				printf("\n<td>%s</td>", i==-1 ? "." : dyc[i]);
			}
			printf("\n</tr>");
			tc=(++tc)%2;
		}
		printf("\n</table></center>");
		if (((lc*ls+k)<lb) || ((pc*ps+j)<pb)) printf("\n(to be continued.)");
	}
	else {
		if (bgcolor)
		printf("\n<th bgcolor=\"%s\"></th></tr>", bgcolor);
		else
		printf("\n<th></th></tr>");

		for (j=0; j<ps && (pc*ps+j)<pb; j++){
			tmp=find_label(cross1, cx1[pc*ps+j]);
			if (cx1[pc*ps+j][0]=='.' ||
			    cx1[pc*ps+j][0]==' ' ||
			    cx1[pc*ps+j][0]=='\0' ||
			    !tmp2 ||
			    tmp2[0]==' ' ||
			    tmp2[0]=='\0' )
				if (bgcolor)
				printf("\n<tr><th bgcolor=\"%s\">%s</th>", bgcolor, tmp? tmp : cx1[pc*ps+j]);
				else
				printf("\n<tr><th>%s</th>", tmp? tmp : cx1[pc*ps+j]);
			else
				if (bgcolor)
				printf("\n<th bgcolor=\"%s\"><a href=\"javascript:drill_down('%s', '%s');\">%s</a></th>", 
					bgcolor, cross_back(cross1, buf),
					n_ptr1->type2[0]=='8'? tmp : cx1[pc*ps+j], 
					tmp? tmp : cx1[pc*ps+j]);
				else
				printf("\n<th><a href=\"javascript:drill_down('%s', '%s');\">%s</a></th>", 
					cross_back(cross1, buf),
					n_ptr1->type2[0]=='8'? tmp : cx1[pc*ps+j], 
					tmp? tmp : cx1[pc*ps+j]);

			i=dat_find(dx1, dx2, cx1[pc*ps+j], NULL, n, 0);
			if (bgcolor)
			printf("\n<td bgcolor=\"%s\">%s</td></tr>", tabcolor[tc], i==-1 ? "." : dyc[i]);
			else
			printf("\n<td>%s</td></tr>", i==-1 ? "." : dyc[i]);
			tc=(++tc)%2;
		}
		printf("\n</table></center>");
		if ((pc*ps+j)<pb) printf("\n(to be continued.)<p>");
	}
}

void tb_out() {
	char * tmp, *tmp1, *tmp2, *cross2, buf[BUFFER_N], buf2[BUFFER_N];
	int flag=0;
	FILE * format;
    NAME *  n_ptr;

	sequence_select();
    if (tmp2=find_path("cross2")) {
         if (!strcmp(tmp2, "none")) cross2=NULL;
         else {
              if (!(n_ptr=find_name(tmp2, 1))) cross2=NULL;
              else {
                  cross2=n_ptr->name_sas;
              }
         }
    }

	if (!_cross_3 || !cross2 || !strcmp(cross2, "detail")) {
		tb_lbl_out("", "");
		return;
	}
		
	tmp1=get_sasname(buf);
	sprintf(buf2, "%s%s.lbl", tmp1, n_ptr->name_html);
	if ((format=file_open(buf2, 0))) flag=1;

	if (!flag) {
		sprintf(buf2, "%s.lbl",  n_ptr->name_html);
		if (!(format=file_open(buf2, 0))) hbase_error(42, buf2);
	}

	flag=1;
	while (!feof(format)) {
		if (!(tmp=fgets(buf, BUFFER_N, format))) break;
		if (!(tmp1=strchr(tmp, '~'))) 
			if (!(tmp1=strchr(tmp, ' ' ))) continue;
		tmp1[0]=0;
		tmp1++;
		if (tmp[0]=='.' || tmp[0]=='~' || tmp[0]==' ') tmp[0]='\0';
		else if (flag) {
                	_cross_2=malloc(strlen(tmp2)+1);
                	strcpy(_cross_2, tmp2);
                	strcpy(tmp2, _cross_3);
			flag=0;
			printf("\n <hr>");
		}
		sprintf(buf2, " for %s=%s", n_ptr->prompt, tmp1);
		tb_lbl_out(tmp, buf2);
	}
	fclose(format);
	return;
}

void tb_lbl_out(char * value, char * lbl) {
	int ps, ls, pb, lb, n, c1, c2, j, k;
	char **dx1=NULL, **dx2=NULL, **cx1=NULL, **cx2=NULL, **dyc=NULL;
	char *tmp;

	if (!(n=dat_get(&dx1, &dx2, &dyc, value))) return;
	dat_cross(dx1, dx2, &cx1, &cx2, &c1, &c2, n);

	if (!(tmp=find_path("ps"))) ps=20;
	else {
		ps = atoi(tmp);
		if (ps<5) ps=5;
		if (ps>50) ps=50;
	}
	if (!(tmp=find_path("ls"))) ls=10;
	else {
		ls = atoi(tmp);
		if (ls<5) ls=5;
		if (ls>50) ls=50;
	}
	pb=(int) ((c1-0.5)/ps + 1);
	lb=(int) ((c2-0.5)/ls + 1);
	lb=lb ? lb : 1;

	for (j=0; j<pb; j++) {
		for (k=0; k<lb; k++) {
			tb_sub(dx1, dx2, dyc, cx1, cx2, lbl, c1, c2, 
				c1>ps ? ps : c1, c2>ls ? ls : c2, j, k, n);
		}
	}
	fflush(stdout);
    for (j=0; j<n; j++) {
        if (dx1[j]) free(dx1[j]);
        if (dyc[j]) free(dyc[j]);
    }
    free(dx1); free(dyc);; 
    if (dx2) {
        for (j=0; j<n; j++) if (dx2[j]) free(dx2[j]);
        free(dx2);
    }
}

char * tb8_space(char * str) {
	unsigned short  i, j=0, flag=1;
	char buf[BUFFER_N];

	for (i=0; i<strlen(str); i++) {
		if (flag || str[i]!=' ') {
			buf[j]=str[i];
			if (str[i]==' ') flag=0;
			else flag=1;
			j++;
		}
	}
	strcpy(str, buf);
	return(str);
}

void tb8_out(int func) {
	int i;
	char str[BUFFER_N], *tmp;
	FILE * dat;

	if (!(tmp=get_sasname(str))) hbase_error(45, NULL);
	strcat(tmp, ".dat");
	if (!(dat=fopen(tmp, "r"))) hbase_error(12, tmp);
	str[0]=0;
	tmp=fgets(str, BUFFER_N, dat);
	if (!tmp || (strlen(tmp)<=5)) {
		std_html(3, 1);
		return;
	}
	rewind(dat);

	i=1;
	while (!feof(dat)) {
		if (!(tmp=fgets(str, BUFFER_N, dat))) break;
		if (func==8) {
			printf("\nRecord %d<center>", i);
			tb8_body(tb8_space(tmp));
		}
		if (func==9) {
			printf("\n<center>", i);
			tb9_body(tb8_space(tmp));
		}
		printf("\n</center><br>");
		i++;
	}
	fclose(dat);
}

char * to_lower(char * str) {
	unsigned short i;

	for (i=0; i<strlen(str); i++) str[i]=tolower(str[i]);
	return str;
}

void tb8_body(char *rec) {
	char * tmp1, * tmp2,  * tmp3, str[BUFFER_N];
	NAME * n_ptr;

	printf("\n<table border=3 cellpadding=1 cellspacing=0>");
	sprintf(str,"func%s", find_path("func"));
	printf("\n<tr align=center><td colspan=4><font size=+3><b>%s</b></font></td></tr>", find_path(str));
	printf("\n<tr><th>Variable Name</th><th>Label</th><th>Value</th><th>format</th></tr>");
	if (rec[strlen(rec)-1]=='\n') rec[strlen(rec)-1]=' ';
	else { rec[strlen(rec)]=' ';
		rec[strlen(rec)+1]=0;
	}
	tmp1=rec;
	for (;;) {
		if (!(tmp2=strchr(tmp1, ' '))) break;
		tmp2[0]=0;
		if ((tmp3=strchr(tmp1, '='))) tmp3[0]=0;
		if ((n_ptr=find_name(to_lower(tmp1), 2))) {
			printf("\n<tr><td> %s", tmp1);
			printf("</td><td> %s", n_ptr->prompt);
			tmp1 = find_format(n_ptr->name_html, tmp3+1, str);
		}
		else continue;
		printf("</td><td> %s", tmp3+1);
		printf("</td><td> %s</td></tr>", tmp1? tmp1 : tmp3+1);
		tmp1=tmp2+1;
	}
	printf("</table><br>");
}

void tb9_body(char *rec) {
	char * tmp1, * tmp2,  * tmp3, str[BUFFER_N];
	NAME * n_ptr;

	if (!(tmp1=find_path("edit_action"))) hbase_error(24, "edit_action");
	printf("\n<form method=\"get\" action=\"%s\">", tmp1);
	if (!(tmp1=find_path("config"))) hbase_error(25, "config");
	printf("\n<input type=hidden name=config value=%s>", tmp1);
	printf("\n<input type=hidden name=func value=9>");
	printf("\n<table border=3 cellpadding=1 cellspacing=0>");
	sprintf(str,"func%s", find_path("func"));
	printf("\n<tr align=center><td colspan=4><font size=+3><b>%s</b></font></td></tr>", find_path(str));
	printf("\n<tr><th>Variable Name</th><th>Label</th><th>Value</th><th>format</th></tr>");
	if (rec[strlen(rec)-1]=='\n') rec[strlen(rec)-1]=' ';
	else { rec[strlen(rec)]=' ';
		rec[strlen(rec)+1]=0;
	}
	tmp1=rec;
	for (;;) {
		if (!(tmp2=strchr(tmp1, ' '))) break;
		tmp2[0]=0;
		if ((tmp3=strchr(tmp1, '='))) tmp3[0]=0;
		if ((n_ptr=find_name(to_lower(tmp1), 2))) {
			printf("\n<tr><td> %s", tmp1);
			printf("</td><td> %s", n_ptr->prompt);
			tmp1 = find_format(n_ptr->name_html, tmp3+1, str);
		}
		else continue;
		printf("</td><td><input type=text size=10 ");
		printf("name=%s value=%s>", n_ptr->name_html, tmp3+1);
		printf("</td><td> %s</td></tr>", tmp1? tmp1 : tmp3+1);
		tmp1=tmp2+1;
	}
	printf("</table><br>");
	printf("\n<input type=\"submit\" value=\"  Send  \">");
	printf("\n<input type=\"reset\" value=\"  Clear  \">");
	printf("\n</form>");
}

char ** decomma(char * str, int * cols) {
	int i, cnt, len, flag;
	char *tmp, **dat, buf[BUFFER_N];;
        long j;

	cnt=0;
	len=strlen(str);
	flag=0;
	tmp=str;
	dat=NULL;
	while (1) {
	  if (flag) {
	    j=(long) strchr(tmp, '\"');
	    if (!j) break;
	    cnt++;
	  }
	  else {
	    j=(long) strchr(tmp, '\"');
	    if (!j) break;
	  }
	  tmp=(char *) j+1;
	  flag=!flag;
	}

	if (!(dat=(char **) malloc((cnt+1)*sizeof(char *)))) 
	  hbase_error(3, "decomma-1");
	*cols=cnt;

	flag=0;
	j=0;
	buf[0]=0;
	cnt=0;
	for (i=0; i<len; i++) {
	  if (flag) {
	    if (str[i]=='\"') {
	      buf[j]=0;
	      if (cnt>*cols) break;
	      if (!(dat[cnt]=(char *) malloc((j+1)*sizeof(char))))
	        hbase_error(3, "decomma-2");
	      strcpy(dat[cnt], buf);
	      cnt++;
	      j=0;
	      flag=!flag;
	      continue;
	    }
	    buf[j]=str[i];
	    j++;
	  }
	  else {
	    if (str[i]=='\"') {
	      flag=!flag;
	      continue;
	    }
	  }
	}

	return dat;
}

void check_sas_error() {
	char *tmp, buf[BUFFER_N];
	char * error="NOTE: The SAS System stopped processing this step because of errors.";
	int i;
	FILE * dfile;

	if (!(tmp=get_sasname(buf))) hbase_error(45, "dat_get3-1");
	strcat(tmp, ".log");
	if (!(dfile=fopen(tmp, "r"))) hbase_error(45, tmp);

	while (!feof(dfile)) {
	  if (!(tmp=fgets(buf, BUFFER_N, dfile))) break;
	  if (!strcmp(de_space(tmp), error)) hbase_error(55, error);
	}
}

char *** dat_get3(int *rows, int *cols) {
	char *tmp, buf[BUFFER_N];
	char *** dat=NULL;
	int i, c=0, d;
	FILE * dfile;

	if (!(tmp=get_sasname(buf))) hbase_error(45, "dat_get3-1");
	strcat(tmp, ".dat");
	if (!(dfile=fopen(tmp, "r"))) hbase_error(45, tmp);


	buf[0]=0;
	tmp=fgets(buf, BUFFER_N, dfile);
	if (!tmp || (strlen(buf)<=5)) {
		i=atoi(find_path("form"));
		if (i==21 || i==22) check_sas_error();
		else std_html(3, 1);
		return(0);
	}

	for (i=0; !feof(dfile); i++) 
		if (!(tmp=fgets(buf, BUFFER_N, dfile))) break;
	if (!(dat=(char ***) malloc((i+1)*sizeof(char **)))) 
	  hbase_error(3, "dat_get2-1");
	rewind(dfile);
	for (i=0; !feof(dfile); i++) {
	  if (!(tmp=fgets(buf, BUFFER_N, dfile))) break;
	  dat[i]=decomma(tmp, &d);
	  c=c>d? c : d;
	}
	*rows=i;
	*cols=c;
	return dat;
}

void tb_out2() {
	CROSS ** crosses;
	char *** dat;
	int i, j, crosses_cnt, rows, cols, rowcolor;
	FUNC * func_p;
        char *bgcolor, *tabcolor[2];
	char buf[BUFFER_N], buf2[BUFFER_N], *tmp;
	FILE * format;


	sequence_select();

        crosses=find_crosses(&crosses_cnt);
	if (!(dat=dat_get3(&rows, &cols))) return;
        func_p=(FUNC *) find_func(h_func, "type");

	printf("\n<center>");
	tmp=find_path("func");
	sprintf(buf, "func%s", tmp);
	if ((tmp=find_path(buf)))
		printf("\n<p><font size=+2>%s</font>", tmp);
	if (!strcmp(func_p->value, "ajrate")) {
	  tmp=find_stdpop(1);
	  printf("\n<br>(Standard population is %s.)", tmp);
	}

	tmp=find_path("titlebg");
	if (tmp) {
	  bgcolor = (char *) malloc(64);
	  sprintf(bgcolor, " bgcolor=\"%s\"", tmp);
	}
	else bgcolor = " ";
	tmp=find_path("tablebg1");
	if (tmp) {
	  tabcolor[0] = (char *) malloc(64);
	  sprintf(tabcolor[0], "bgcolor=\"%s\"", tmp);
	}
	else tabcolor[0] = " ";
	tmp=find_path("tablebg2");
	if (tmp) {
	  tabcolor[1] = (char *) malloc(64);
	  sprintf(tabcolor[1], "bgcolor=\"%s\"", tmp);
	}
	else tabcolor[1] = " ";
	rowcolor=0;

	printf("\n<table border=1 cellpadding=1 cellspacing=0>");
	printf("\n<tr>");
	for (i=0; i<crosses_cnt; i++) {
	  if (crosses[i] && crosses[i]->name_ptr)
	    printf("\n<th %s>%s</th>", bgcolor, crosses[i]->name_ptr->prompt);
	}
	tmp=find_path("func");
	sprintf(buf2, "out_%s", tmp);
	for (i=0; i<cols-crosses_cnt; i++) {
	  sprintf(buf, "%d", i+1);
	  tmp=find_label(buf2, buf);
	  if (tmp) printf("\n<th %s>%s</th>", bgcolor, tmp);
	}
	printf("\n</tr>");

	for (j=0; j<rows; j++) {
	  printf("\n<tr>");
	  for (i=0; i<crosses_cnt; i++) {
	    tmp=find_label(crosses[i]->name_ptr->name_html, de_space(dat[j][i]));
	    if (!tmp) tmp=dat[j][i];
	    if (atoi(crosses[i]->name_ptr->type2))
	      printf("\n<td %s>%s</td>", tabcolor[rowcolor], tmp);
	    else
	      printf("\n<td %s><a href=\"javascript:drill_down('%s', '%s');\">%s</a></td>", tabcolor[rowcolor], crosses[i]->name_ptr->name_html, dat[j][i], tmp);
	  }

	  for (i=i; i<cols; i++) {
	    printf("\n<td %s>%s</td>", tabcolor[rowcolor], dat[j][i]);
	  }
	  printf("\n</tr>");
	  rowcolor=!rowcolor;
	}

	printf("\n</table></center>");
	
	return;
}

