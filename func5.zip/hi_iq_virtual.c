/* HI-IQ System, the High Information Internet Query System,
	Copyright 1995, 1996, 1997, 1998 Utah Office of Health Data Analysis.

	hi_iq_virtual.c 11/11/98
	unformatted results output for robot access.

	We provide the interactive interface to make your data available
	to public through Internet.
*/

#include "hi_iq.h"
#include "hi_iq_var.h"

void plain_lbl_out(char * value, char * lbl) {
	char str[BUFFER_N], *cross1, *cross2, *tmp;
	int flag=0;
	FILE * dat;
	NAME * n_ptr;
			
	printf("%s\n", BONDARY);
	if (cross1=find_path("cross1")) {
		if (!(n_ptr=find_name(cross1, 1))) cross1=NULL;
		else cross1=n_ptr->name_html;
	}
	if (cross2=find_path("cross2")) {
		if (!strcmp(cross2, "none")) cross2=NULL;
		else if (!(n_ptr=find_name(cross2, 1))) cross2=NULL;
			else cross2=n_ptr->name_html;
	}
	if (!(tmp=get_sasname(str))) hbase_error(45, NULL);
	strcat(tmp, value);
	strcat(tmp, ".dat");
	if (!(dat=fopen(tmp, "r"))) hbase_error(12, tmp);
	while (!(feof(dat))) {
		if (!(tmp=fgets(str, BUFFER_N, dat))) break;
		printf("%s", str);
	}
	printf("%s\n", BONDARY);
	fflush(stdout);
	fclose(dat);
}

void plain_out() {
	char *tmp, *tmp1, *tmp2, *cross2, buf[BUFFER_N], buf2[BUFFER_N];
	int flag=0;
	FILE * format;
    NAME *  n_ptr;

    if (tmp2=find_path("cross2")) {
         if (!strcmp(tmp2, "none")) cross2=NULL;
         else {
              if (!(n_ptr=find_name(tmp2, 1))) cross2=NULL;
              else {
                  cross2=n_ptr->name_sas;
              }
         }
    }

	if (!_cross_3 || !cross2 || !strcmp(cross2, "detail")) {
		plain_lbl_out("", "");
		return;
	}
		
	tmp1=get_sasname(buf);
	sprintf(buf2, "%s%s.lbl", tmp1, n_ptr->name_html);
	if ((format=fopen(buf2, "r"))) flag=1;

	if (!flag) {
		sprintf(buf2, "%s.lbl", n_ptr->name_html);
		if (!(format=file_open(buf2, 0))) hbase_error(42, buf2);
	}

	flag=1;
	while (!feof(format)) {
		if (!(tmp=fgets(buf, BUFFER_N, format))) break;
		if (!(tmp1=strchr(tmp, '~'))) 
			if (!(tmp1=strchr(tmp, ' ' ))) continue;
		tmp1[0]=0;
		tmp1++;
		if (tmp[0]=='.' || tmp[0]=='~' || tmp[0]==' ') tmp[0]='\0';
		else if (flag) {
                	_cross_2=malloc(strlen(tmp2)+1);
                	strcpy(_cross_2, tmp2);
                	strcpy(tmp2, _cross_3);
			flag=0;
		}
		sprintf(buf2, " for %s=%s", n_ptr->prompt, tmp1);
		plain_lbl_out(tmp, buf2);
	}
	fclose(format);
	return;
}

