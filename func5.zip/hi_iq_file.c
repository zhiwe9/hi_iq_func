/* HI-IQ System, the High Information Internet Query System,
	Copyright 1995, 1996, 1997, 198 Utah Office of Health Data Analysis.

	hi_iq_file.c	11/11/98
	send the file back to user and replace the variables with proper values.

	We provide the interactive interface to make your data available
	to public through Internet.
*/

#include "hi_iq.h"
#include "hi_iq_var.h"

void replace(char *buf, REPLACE **repla) {
	char *tmp, *tmp3, *tmp2, str[STRING_N], buf2[BUFFER_N];
	char sp=' ';
	int i, j, k, flag, vp;

	for (i=0; repla[i]; i++) {
		if (!(tmp=strstr(buf, repla[i]->key))) continue;
		
		strcpy(buf2, tmp+strlen(repla[i]->key));
		flag=0;
		if ((tmp2=strstr(buf, "type=radio"))) flag=1;
		else if ((tmp2=strstr(buf, "option"))) flag=2;
		tmp[0]='\0';

		switch(flag) {
		default:
		case 0:
			sprintf(tmp, "%s", repla[i]->rep);
			break;
		case 1:
			if ((tmp3=strstr(buf, "value="))) {
				vp=0;
				for (j=6, k=0; ; j++) {
					if (!vp) {
						if (tmp3[j]=='>' || tmp3[j]=='\n' || tmp3[j]=='\0') {str[k]='\0'; break;}
						else if (tmp3[j]==' ') continue;
						else if (tmp3[j]=='\"') {sp='\"'; vp++;}
						else if (tmp3[j]=='\'') {sp='\''; vp++;}
						else vp++;
					}
					else {
						if (tmp3[j]==sp || tmp3[j]=='>' || tmp3[j]=='\n' || tmp3[j]=='\0') {str[k]='\0'; break;}
						str[k]=tmp3[j];
						k++;
					}
				}
				if (!strcmp(str, repla[i]->rep)) 
					strcpy(tmp, "checked");
				else {
					strcpy(tmp, "");
					
				}
			}
			break;
		case 2:
			if ((tmp3=strstr(buf, "value="))) {
				vp=0;
				for (j=6, k=0; ; j++) {
					if (!vp) {
						if (tmp3[j]=='>' || tmp3[j]=='\n' || tmp3[j]=='\0') {str[k]='\0'; break;}
						else if (tmp3[j]==' ') continue;
						else if (tmp3[j]=='\"') {sp='\"'; vp++;}
						else if (tmp3[j]=='\'') {sp='\''; vp++;}
						else vp++;
					}
					else {
						if (tmp3[j]==sp || tmp3[j]=='>' || tmp3[j]=='\n' || tmp3[j]=='\0') {str[k]='\0'; break;}
						str[k]=tmp3[j];
						k++;
					}
				}
				if (!strcmp(str, repla[i]->rep)) 
					strcpy(tmp, "selected");
				else {
					strcpy(tmp, "");
					
				}
			}
			break;
		}
		strcat(buf, buf2);
	}
	printf("%s", buf);
}

void put_file_rep(char *name, int flag, REPLACE **repla) {
	char *tmp1, buf[BUFFER_N];
	FILE *fp;

	switch(flag) {
	case 1:
		if (!(fp=file_open(name, 0))) hbase_error(44, buf);
		break;
	case 2: 
		if (!(tmp1=find_path("workpath"))) hbase_error(43, NULL);
		sprintf(buf, "%s%s%s", tmp1, 
			tmp1[strlen(tmp1)-1]=='/'? "" : "/", name);
		if (!(fp=fopen(buf, "r"))) hbase_error(44, buf);
		break;
	default:
		strcpy(buf, name);
		if (!(fp=fopen(buf, "r"))) hbase_error(44, buf);
		break;
	}

	while (!feof(fp)) {
		fgets(buf, BUFFER_N, fp);
		replace(buf, repla);
	}
	fclose(fp);
}

void put_file_norep(char *filename) {
	FILE * fp;
	char buf[BUFFER_N];
	int esp=0;

	
	if (!filename) hbase_error(54, "");
	if (!strcmp(filename+strlen(filename)-3, "sas")
	    || !strcmp(filename+strlen(filename)-3, "log")
	    || !strcmp(filename+strlen(filename)-3, "lst")
	    || !strcmp(filename+strlen(filename)-3, "dat")) esp=1;

	if (!(fp=file_open(filename, 0))) return;

	fgets(buf, BUFFER_N, fp);
	while (!feof(fp)) {
		if (esp && (form==21 || form==22)) printf("%s\n", escape_special(buf));
		else printf("%s", buf);
		fgets(buf, BUFFER_N, fp);
	}
	fclose(fp);
}

void put_file_xml(char *filename) {
	FILE * fp;
	char buf[BUFFER_N], *tmp;

	if (!(fp=file_open(filename, 0))) return;

	fgets(buf, BUFFER_N, fp);
	while (!feof(fp)) {
		if (!(tmp=fgets(buf, BUFFER_N, fp))) break;
		printf("%s", buf);
	}
	fclose(fp);
}

void std_html(int flag, int pre) {
	char * tmp, buf[BUFFER_N];
	int sas=0;

	fflush(stdout);

	if (pre) {
	    if (form==21 || form==22) {
	 	switch(flag) {
		case 3:
		sas=3;
		break;
		case 4:
		sas=1;
		break;
		case 5:
		sas=2;
		break;
		case 6:
		sas=4;
		break;
		}
		//printf("\n<DEBUG>");
		printf("\n<TYPE>sas</TYPE>");
	        printf("\n<VALUE>%d</VALUE>", sas);
		printf("\n<TEXT>");
	    }
	    else printf("\n<pre>");
	    fflush(stdout);
	}

	switch(flag) {
	case 1: tmp=find_path("htmlhead");
		if (!tmp) {
		  tmp=find_path("response_head_content");
		  if (!tmp)  hbase_error(55, "htmlhead/response_head_content");
		}

		put_file_norep(tmp);
		break;
	case 2: tmp=find_path("htmltail");
		if (!tmp) {
		  tmp=find_path("response_tail_content");
		  if (!tmp) hbase_error(55, "htmltail/response_tail_content");
		}
		std_htmltail(tmp);
		break;
	case 3: if (!(tmp=get_sasname(buf))) hbase_error(45, NULL);
		strcat(tmp, ".lst");
		put_file_norep(tmp);
		break;
	case 4: if (!(tmp=get_sasname(buf))) hbase_error(45, NULL);
		strcat(tmp, ".sas");
		put_file_norep(tmp);
		break;
	case 5: if (!(tmp=get_sasname(buf))) hbase_error(45, NULL);
		strcat(tmp, ".log");
		put_file_norep(tmp);
		break;
	case 6: if (!(tmp=get_sasname(buf))) hbase_error(45, NULL);
		strcat(tmp, ".dat");
		put_file_norep(tmp);
		break;
	case 7: if (!(tmp=get_sasname(buf))) hbase_error(45, NULL);
		strcat(tmp, ".xml");
		put_file_xml(tmp);
		break;
	}

	if (pre) {
	    if (form==21 || form==22) {
		printf("\n</TEXT>\n");
		//printf("</DEBUG>");
	    }
	    else printf("\n</pre>");
	    fflush(stdout);
	}

	fflush(stdout);
}

