/* HI-IQ System, the High Information Internet Query System,
	Copyright 1995, 1996, 1997, 1998 Utah Office of Health Data Analysis.

	hi_iq_mail.c 11/11/98
	Send result in ASCII format through email for Unix platform, but to standard output for 
	windows NT.

	We provide the interactive interface to make your data available
	to public through Internet.
*/

#include "hi_iq.h"
#include "hi_iq_var.h"

extern int _flag_ ;
int COL_1  =15;
int COL_2  =10;

void mail_sub(FILE * mail, char **dx1, char **dx2, char **dyc, char **cx1, char **cx2, 
		int c1, int c2, int n) {
	int i, j, l, k, o;
	char *tmp, buf[BUFFER_N], *cross1, *cross2;
	NAME *n_ptr1=NULL, *n_ptr2=NULL;

	if (cross1=find_path("cross1")) {
		if (!(n_ptr1=find_name(cross1, 1))) cross1=NULL;
		else cross1=n_ptr1->name_html;
	}
	if (cross2=find_path("cross2")) {
		if (!strcmp(cross2, "none")) cross2=NULL;
		else if (!(n_ptr2=find_name(cross2, 1))) cross2=NULL;
			else cross2=n_ptr2->name_html;
	}

	if (cross2) {
		for (j=0, k=1; k==1; j++) {
			k=0;
			tmp=find_label(cross1, cx1[c1]);
			tmp=tmp? tmp : cx1[c1];
			l = strlen(tmp);
			if (l > j*(COL_1-2)) {
				for (o=0; o<(COL_1-2); o++) {
					if (j*(COL_1-2)+o<l) buf[o]=tmp[j*(COL_1-2)+o];
					else buf[o]=' ';
				}
				buf[o]='\0';
				fprintf(mail, "\n%s  ", buf);
				k = l>(j+1)*(COL_1-2)? 1 : k;
			}
			else {
				fprintf(mail, "\n");
				for (i=0; i<COL_1; i++) fputc(' ', mail);
			}

			if (!j) {
				for(i=0; i<c2; i++) {
					o=dat_find(dx1, dx2, cx1[c1], cx2[i], n, 1);
					sprintf(buf, "%s", o==-1 ? "." : dyc[o]);
					for (o=strlen(buf); o<COL_2; o++) buf[o]=' ';
					buf[o]='\0';
					fprintf(mail, "%s", buf);
				}
			}
		} /* for (j=0...) */
	} /* if (cross2) */
	else {
		for (j=0, k=1; k==1; j++) {
			k=0;
			tmp=find_label(cross1, cx1[c1]);
			tmp=tmp? tmp : cx1[c1];
			l = strlen(tmp);
			if (l > j*(COL_1-2)) {
				for (o=0; o<(COL_1-2); o++) {
					if (j*(COL_1-2)+o<l) buf[o]=tmp[j*(COL_1-2)+o];
					else buf[o]=' ';
				}
				buf[o]='\0';
				fprintf(mail, "\n%s  ", buf);
				k = l>(j+1)*(COL_1-2)? 1 : k;
			}
			else fprintf(mail, "\n%15s", " ");

			if (!j) {
				i=dat_find(dx1, dx2, cx1[c1], NULL, n, 0);
				sprintf(buf, "%s", i==-1 ? "." : dyc[i]);
				for (o=strlen(buf); o<COL_2; o++) buf[o]=' ';
				buf[o]='\0';
				fprintf(mail, "%s", buf);
			}
		} /* for (j=0...) */
	} /* else */
}

void mail_tb(FILE *mail, char *value, char *lbl) {
	int  c1, c2, i, j, k, l, m, n, o;
	char **dx1=NULL, **dx2=NULL, **cx1, **cx2, **dyc;
	char *tmp, *tmp2, *cross1, *cross2;
	char str[BUFFER_N], buf[64];
 	NAME *n_ptr1=NULL, *n_ptr2=NULL;

	if (cross1=find_path("cross1")) {
		if (!(n_ptr1=find_name(cross1, 1))) cross1=NULL;
		else cross1=n_ptr1->name_html;
	}
	if (cross2=find_path("cross2")) {
		if (!strcmp(cross2, "none")) cross2=NULL;
		else if (!(n_ptr2=find_name(cross2, 1))) cross2=NULL;
			else cross2=n_ptr2->name_html;
	}

	if (!(n=dat_get(&dx1, &dx2, &dyc, value))) return;
	dat_cross(dx1, dx2, &cx1, &cx2, &c1, &c2, n);
	if (c2<3)      {COL_1=35; COL_2=20;}
	else if (c2<5) {COL_1=30; COL_2=15;}
	else if (c2<7) {COL_1=25; COL_2=12;}
	else if (c2<9) {COL_1=20; COL_2=10;}
	else           {COL_1=10; COL_2=8 ;}

	tmp=find_path("func");
	sprintf(str, "func%s", tmp);
	if ((tmp=find_path(str))) {
		j = (COL_1+c2*COL_2-strlen(tmp))/2;
		j = j>0? j : 0;
		for (i=0; i<j; i++) fputc(' ', mail);
		fprintf(mail, "%s\n", tmp);
	}
	fprintf(mail, "\n\t %s", lbl);
	if ((strstr(tmp, "Age-adjusted"))) {
		tmp2=find_stdpop(1);
		sprintf(str, "(Standard population is %s.)", tmp2);
		j = (COL_1+c2*COL_2-strlen(str))/2;
		j = j>0? j : 0;
		for (i=0; i<j; i++) fputc(' ', mail);
		fprintf(mail, "%s %s", str, lbl);
	}
	fprintf(mail, "\n\n");

	for (j=0; j<COL_1; j++) fputc(' ', mail);
	fprintf(mail, "%s", n_ptr2? n_ptr2->prompt : " ");

	l = strlen(n_ptr1->prompt);
	for (j=0, k=1; k>0; j++) {
		k=0;
		if (n_ptr1 && (l > j*(COL_1-2))) {
			for (o=0; o<(COL_1-2); o++) {
				if (j*(COL_1-2)+o<l) buf[o]=n_ptr1->prompt[j*(COL_1-2)+o];
				else buf[o]=' ';
			}
			buf[o]='\0';
			fprintf(mail, "\n%s  ", buf);
			k = l>(j+1)*(COL_1-2)? 1 : k;
		}
		else {
			fputc('\n', mail);
			for (i=0; i<COL_1; i++) fputc(' ', mail);
		}

		for(i=0; i<c2; i++) {
			tmp=find_label(cross2, cx2[i]);
			tmp=tmp? tmp : cx2[i];
			m = strlen(tmp);
			if (m > j*(COL_2-1)) {
				for (o=0; o<(COL_2-1); o++) {
					if (j*(COL_2-1)+o<m) buf[o]=tmp[j*(COL_2-1)+o];
					else buf[o]=' ';
				}
				buf[o]='\0';
				fprintf(mail, "%s ", buf);
				k = m>(j+1)*(COL_2-1)? 1 : k;
			}
			else { 
				for (m=0; m<COL_2; m++) fputc(' ', mail);
			}
		}
	}

	for (i=0; i<c1; i++) {
		mail_sub(mail, dx1, dx2, dyc, cx1, cx2, i, c2, n);
	}

        for (j=0; j<n; j++) {
                if (dx1[j]) free(dx1[j]);
                if (dyc[j]) free(dyc[j]);
        }
       free(dx1); free(dyc);
      if (dx2) {
                for (j=0; j<n; j++) if (dx2[j]) free(dx2[j]);
        }
      free(dx2);
}

void mail_out() {
	char * tmp, *tmp1, *tmp2, *cross2, buf[BUFFER_N], buf2[BUFFER_N];
	int flag=0;
	FILE * format, * mail;
    NAME *  n_ptr;

#ifdef WIN_NT
	mail=stdout;
#else
	if (!(tmp=find_path("email_bin"))) hbase_error(28, "email_bin");
	if (!(tmp2=find_path("recipient"))) hbase_error(29, "recipient");
	sprintf(buf, "%s %s ", tmp, tmp2);
	if (!(mail=popen(buf, "w"))) hbase_error(30, buf);
	tmp=find_path("subject");
	fprintf(mail, "Subject: %s\n", tmp? tmp :  "none");
	tmp=find_path("reply_to");
	fprintf(mail, "Reply-To: %s\n", tmp? tmp : "none");
	tmp=getenv("REMOTE_USER");
	tmp2=getenv("REMOTE_HOST");
	fprintf(mail, "Supposedly-From: %s%s%s\n\n", tmp? tmp : "",
			tmp? "@" : "", tmp2? tmp2 : "");
	fprintf(mail, "[This message was sent through Internet Health Information System.]\n--\n");
#endif
	
	mail_select(mail);
	mail_group(mail);
	fprintf(mail, "\n--\n");

        if (tmp2=find_path("cross2")) {
                if (!strcmp(tmp2, "none")) cross2=NULL;
                else {
                        if (!(n_ptr=find_name(tmp2, 1))) cross2=NULL;
                        else {
                                cross2=n_ptr->name_sas;
                        }
                }
        }

	if (!_cross_3 || !cross2 || !strcmp(cross2, "detail")) {
		mail_tb(mail, "", "");
		return;
	}

	if ((tmp=find_path("workpath"))) {
		tmp1=get_sasname(buf);
		sprintf(buf2, "%s/%s%s.lbl", tmp, tmp1, n_ptr->name_html);
		if ((format=fopen(buf2, "r"))) flag=1;
	}

	if (!flag) {
		sprintf(buf2, "%s.lbl", tmp, n_ptr->name_html);
		if (!(format=file_open(buf2, 0))) hbase_error(42, buf2);
	}

	flag=1;
	while (!feof(format)) {
		if (!(tmp=fgets(buf, BUFFER_N, format))) break;
		if (!(tmp1=strchr(tmp, '~'))) 
			if (!(tmp1=strchr(tmp, ' ' ))) continue;
		tmp1[0]=0;
		tmp1++;
		if (tmp[0]=='.' || tmp[0]=='~' || tmp[0]==' ') tmp[0]='\0';
		else if (flag) {
                	_cross_2=malloc(strlen(tmp2)+1);
                	strcpy(_cross_2, tmp2);
                	strcpy(tmp2, _cross_3);
			flag=0;
		}
		sprintf(buf2, " for %s=%s", n_ptr->prompt, tmp1);
		mail_tb(mail, tmp, buf2);
	}
	fclose(format);
#ifndef WIN_NT
	pclose(mail);
#endif
	return;
}

void mail_out_std() {
	char * tmp, * tmp2, buf[BUFFER_N];
	time_t now;
	struct tm *tp;

	tmp=find_path("func");
	sprintf(buf, "func%s", tmp);
	if ((tmp=find_path(buf)))
	printf("\n<font size=+2>%s</font>", tmp);
	if ((strstr(tmp, "Age-adjusted"))) {
		tmp2=find_stdpop(1);
		printf("\n<br>(Standard population is %s.)", tmp2);
	}

	if (!(tmp2=find_path("recipient"))) hbase_error(29, "recipient");
	printf("\n<hr><font size=+1>The results of your query will be sent to <b>%s</b> through <font color=blue>IBISQ</font><p>", tmp2);
fflush(stdout);
	tmp=find_path("subject");
	printf("<b>Subject</b>: %s\n<br>", tmp? tmp :  "none");
	tmp=find_path("reply_to");
	printf("<b>Reply-To</b>: %s\n<br>", tmp? tmp : "none");
	tmp=getenv("REMOTE_USER");
	tmp2=getenv("REMOTE_HOST");
/*
	printf("<br><b>Query Request Supposedly-From</b>: %s%s%s\n<br>", tmp? tmp : "",
			tmp? "@" : "", tmp2? tmp2 : "");
*/
	time(&now);
	tp=localtime(&now);
	strftime(buf, 79, "%a, %d %b %Y %H:%M:%S %Z\n", tp);
	printf("<b>DATE</b>: %s<br>", buf);
}

#ifndef WIN_NT
void detach() {
	int x;

	chdir("/");
	if ((x=fork()) > 0) {
		enc_note();
		hbase_clear();
		exit(0);
	}
	else if (x==-1) {
		hbase_error(35, NULL);
	}
}
#endif

void mail_select(FILE * mail) {
	char * tmp;
	int i, j, c, flag=0;
	VARI ** vari_ptr;

	tmp=find_path("dataset");
	fprintf(mail, "\nQuery: %s", tmp? tmp : "no dataset name");

	_flag_ = 0;
	for (i=0; i<h_name_i; i++) {
		j = atoi(h_name[i]->type2);
		if (j==0 || j==1) {
			if ((vari_ptr=find_vari(h_name[i]->name_html,1,j,&c))) {
				if (c<=0 || !strlen(de_space(vari_ptr[0]->value))) continue;
				mail_vari_bld(vari_ptr, mail, c, flag);
				free(vari_ptr);
				vari_ptr=NULL;
				flag = 1;
				_flag_ = flag;
			}
		}
	}
	fflush(mail);
}
		
void mail_vari_bld(VARI ** v_ptr, FILE * mail, int c, int flag) {
	int j;
	char str[BUFFER_N];
	
	j = atoi(v_ptr[0]->name_ptr->type2);
	if (j==2) {
		strcpy(str, v_ptr[0]->value);
		if (strlen(de_space(str))==0) return;
	}
	fprintf(mail, "\n %s( ", flag ? "and" : "");
	switch(j) {
		case 0: mail_type1(v_ptr, mail, c);
			break;
		case 1: mail_type2(v_ptr, mail, c);
			break;
		case 9: break;
		default: hbase_error(17, v_ptr[0]->name_ptr->type2);
			break;
	}
	fprintf(mail, "\n )");
}

void mail_type2(VARI ** v_ptr, FILE * mail, int c) {
	char * name, *name2, * tmp, *tmp2, *tmp3, str[BUFFER_N];
	int i, j=1, k, l=0;

	if (!strcmp(v_ptr[0]->name_ptr->type1, "char")) l=1;
	name=v_ptr[0]->name_ptr->prompt;
	name2=v_ptr[0]->name_ptr->name_sas;
   for (k=0; k<c; k++) {
	tmp=v_ptr[k]->value;
	if (strlen(tmp)>BUFFER_N) hbase_error(18, tmp);
	tmp2=v_ptr[k]->label;
	if (tmp2) {
		if (l) fprintf(mail, "\n %s%s = '%s'", k ? "or " : " ", name, tmp2);
		else fprintf(mail, "\n %s%s = %s", k ? "or " : " ", name, tmp2);
		j=0;
	}
	else {
		fprintf(mail, "\n %s", k ? "or " : "");
		j=1;
	}
	for (i=0; ; i++) {
		if (!(tmp=sas_type2_cut(tmp, str))) break;
		if (!(tmp2=strchr(str, '-'))) {
			tmp2=de_space(str);
			if (j) {
				if (l) fprintf(mail, "\n %s(%s=:'%s') ", i ? " or " : " ", 
				name, tmp2);
				else fprintf(mail, "\n %s(%s=%s) ", i ? " or " : " ", 
				name, tmp2);
			}
		}
		else {
			tmp2[0]=0;
			tmp3=de_space(tmp2+1);
			tmp2=de_space(str);
			if (j) { 
				if (l) fprintf(mail, "\n %s('%s'<=:(%s)<=:'%s') ", i ? " or " : " ", 
				tmp2, name, tmp3);
				else fprintf(mail, "\n %s(%s<=(%s)<=%s) ", i ? " or " : " ", 
				tmp2, name, tmp3);
			}
		}
	}
   }
}

void mail_type1(VARI ** v_ptr, FILE * mail, int c) {
	char * tmp;
	int i, j=0;

	if (!strcmp(v_ptr[0]->name_ptr->type1, "char")) j=1;
	tmp=v_ptr[0]->name_ptr->prompt;
	if (j) {
		for (i=0; i<c; i++) {
			fprintf(mail, "\n %s(%s = '%s') ", i ? " or " : " ", tmp, 
				v_ptr[i]->label ? v_ptr[i]->label : v_ptr[i]->value);
		}
	}
	else {
		for (i=0; i<c; i++) {
			fprintf(mail, "\n %s(%s = %s) ", i ? " or " : " ", tmp, 
				v_ptr[i]->label ? v_ptr[i]->label : v_ptr[i]->value);
		}
	}
}

void mail_group_type3(VARI * vari_p, FILE * mail, int l) {
	int i;
	char *tmp, *tmp2, *tmp3, *name, *prompt, str[BUFFER_N];

	tmp=strcpy(str, vari_p->value);
	name=vari_p->name_ptr->name_sas;
	prompt=vari_p->name_ptr->prompt;
	for (i=0; ; i++) {
		if (!(tmp=sas_type2_cut(tmp, str))) break;
		if (!(tmp2=strchr(str, '-'))) {
			if (!(tmp2=strchr(str, '+'))) {
				tmp2=de_space(str);
				if (_flag_ > 1) {
					if (l) fprintf(mail, "%s(%s=:'%s') ", i ? "\n  or " : "", prompt, tmp2);
					else fprintf(mail, "%s(%s=%s) ", i ? "\n  or " : "", prompt, tmp2);
				}
			}
			else {
				tmp2[0]=0;
				tmp2=de_space(str);
				if (_flag_ > 1) {
					if (l) fprintf(mail, "%s(%s>=:'%s') ", i ? "\n  or " : "", prompt, tmp2);
					else fprintf(mail, "%s(%s>=%s) ", i ? "\n  or " : "", prompt, tmp2);
				}
			}
		}
		else {
			tmp2[0]=0;
			tmp3=de_space(tmp2+1);
			tmp2=de_space(str);
			if (_flag_ > 1) {
				if (l) fprintf(mail, "%s('%s' <=: %s <=: '%s') ", i? "\n  or " : "", tmp2, prompt, tmp3);
				else fprintf(mail, "%s(%s <= %s <= %s) ", i ? "\n  or " : "", tmp2, prompt, tmp3);
			}
		}
	}
}

void mail_group_bld(VARI * vari_p, FILE * mail) {
	char buf1[BUFFER_N], buf2[BUFFER_N], *tmp;
	int i, j, d;
	VARI ** v_ptr;

	strcpy(buf1, vari_p->value);
	strcpy(buf2, vari_p->name_ptr->name_html);
	if (tmp=strstr(buf2, "_f")) {
		tmp[0]=0;
		strcat(buf2, buf1);
		v_ptr=find_vari(buf2, 1, 3, &d);
		if (v_ptr && d>0) {
			j= (!(strcmp(v_ptr[0]->name_ptr->type1, "char")));
			fprintf(mail, "\n %s ( ", _flag_ ? "and" : "");
			_flag_+=2;

			for (i=0; i<d; i++) {
				fprintf(mail, "\n%s", i ? "  or " : "  ");
				mail_group_type3(v_ptr[i], mail, j);
			}
			_flag_-=2;
			if (!_flag_) _flag_=1;
			fprintf(mail, "\n )");
		}
		free(v_ptr);
	}
}

void mail_group (FILE *mail) {
	int i, j, c;
	VARI ** vari_p;

	for (i=0; i<h_name_i; i++) {
		j=atoi(h_name[i]->type2);
		if (j==8) {
			vari_p=find_vari(h_name[i]->name_html, 1, j, &c);
			if (c<=0 || !vari_p) continue;
			mail_group_bld(vari_p[0], mail);
			free(vari_p);
		}
	}
	fflush(mail);
}
		
void mail_tb2(FILE *mail, char *value, char *lbl) {
	CROSS ** crosses;
	char *** dat;
	int i, j, crosses_cnt, rows, cols, rowcolor;
	FUNC * func_p;
        char *bgcolor, *tabcolor[2];
	char buf[BUFFER_N], buf2[BUFFER_N], *tmp;
	FILE * format;

        crosses=find_crosses(&crosses_cnt);
	if (!(dat=dat_get3(&rows, &cols))) return;
        func_p=(FUNC *) find_func(h_func, "type");

	tmp=find_path("func");
	sprintf(buf, "func%s", tmp);
	if ((tmp=find_path(buf)))
	if (!strcmp(func_p->value, "ajrate")) {
	  tmp=find_stdpop(1);
	  fprintf(mail, "\n(Standard population is %s.)", tmp);
	}

	fprintf(mail, "\n");
	for (i=0; i<crosses_cnt; i++) {
	  if (crosses[i] && crosses[i]->name_ptr)
	    fprintf(mail, "\"%s\"", crosses[i]->name_ptr->prompt);
	}
	tmp=find_path("func");
	sprintf(buf2, "out_%s", tmp);
	for (i=0; i<cols-crosses_cnt; i++) {
	  sprintf(buf, "%d", i+1);
	  tmp=find_label(buf2, buf);
	  if (tmp) fprintf(mail, ",\"%s\"", tmp);
	}

	for (j=0; j<rows; j++) {
	  fprintf(mail, "\n");
	  for (i=0; i<crosses_cnt; i++) {
	    tmp=find_label(crosses[i]->name_ptr->name_html, de_space(dat[j][i]));
	    if (!tmp) tmp=dat[j][i];
	    fprintf(mail, "%s\"%s\"", (i==0? "" : ","), tmp);
	  }

	  for (i=i; i<cols; i++) {
	    fprintf(mail, ",\"%s\"", dat[j][i]);
	  }
	}

	fflush(mail);
	return;
}

void mail_out2() {
	char * tmp, *tmp1, *tmp2, *cross2, buf[BUFFER_N], buf2[BUFFER_N];
	int flag=0;
	FILE * format, * mail;
    NAME *  n_ptr;

#ifdef WIN_NT
	mail=stdout;
#else
	if (!(tmp=find_path("email_bin"))) hbase_error(28, "email_bin");
	if (!(tmp2=find_path("recipient"))) hbase_error(29, "recipient");
	sprintf(buf, "%s %s ", tmp, tmp2);
	if (!(mail=popen(buf, "w"))) hbase_error(30, buf);
	tmp=find_path("subject");
	fprintf(mail, "Subject: %s\n", tmp? tmp :  "none");
	tmp=find_path("reply_to");
	fprintf(mail, "Reply-To: %s\n", tmp? tmp : "none");
	tmp=getenv("REMOTE_USER");
	tmp2=getenv("REMOTE_HOST");
	fprintf(mail, "Supposedly-From: %s%s%s\n\n", tmp? tmp : "",
			tmp? "@" : "", tmp2? tmp2 : "");
	fprintf(mail, "[This message was sent through Internet Health Information System.]\n--\n");
#endif
	
	mail_select(mail);
	mail_group(mail);
	fprintf(mail, "\n--\n");

        if (tmp2=find_path("cross2")) {
                if (!strcmp(tmp2, "none")) cross2=NULL;
                else {
                        if (!(n_ptr=find_name(tmp2, 1))) cross2=NULL;
                        else {
                                cross2=n_ptr->name_sas;
                        }
                }
        }

	if (!_cross_3 || !cross2 || !strcmp(cross2, "detail")) {
		mail_tb2(mail, "", "");
		return;
	}

	if ((tmp=find_path("workpath"))) {
		tmp1=get_sasname(buf);
		sprintf(buf2, "%s/%s%s.lbl", tmp, tmp1, n_ptr->name_html);
		if ((format=fopen(buf2, "r"))) flag=1;
	}

	if (!flag) {
		sprintf(buf2, "%s.lbl", tmp, n_ptr->name_html);
		if (!(format=file_open(buf2, 0))) hbase_error(42, buf2);
	}

	flag=1;
	while (!feof(format)) {
		if (!(tmp=fgets(buf, BUFFER_N, format))) break;
		if (!(tmp1=strchr(tmp, '~'))) 
			if (!(tmp1=strchr(tmp, ' ' ))) continue;
		tmp1[0]=0;
		tmp1++;
		if (tmp[0]=='.' || tmp[0]=='~' || tmp[0]==' ') tmp[0]='\0';
		else if (flag) {
                	_cross_2=malloc(strlen(tmp2)+1);
                	strcpy(_cross_2, tmp2);
                	strcpy(tmp2, _cross_3);
			flag=0;
		}
		sprintf(buf2, " for %s=%s", n_ptr->prompt, tmp1);
		mail_tb2(mail, tmp, buf2);
	}
	fclose(format);
#ifndef WIN_NT
	pclose(mail);
#endif
	return;
}

