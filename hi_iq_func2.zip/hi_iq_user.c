/* HI-IQ System, the High Information Internet Query System,
	Copyright 1995, 1996, 1997, 1998 Utah Office of Health Data Analysis.

	hi_iq_user.c	11/11/98
	Access control.

	We provide the interactive interface to make your data available
	to public through Internet.
*/

#include "hi_iq.h"
#include "hi_iq_var.h"

static unsigned char *itoa64=
	"./abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWZYZ";

#ifdef WIN_NT
char * crypt(char *pass, char *salt) {
		return pass;
}
#else
	extern char * crypt(char *pass, char *salt);
#endif

char * crypt_pass(char *pass) {
	char salt[3];

	srand((int) time ((time_t *) NULL));
	salt[0]=itoa64[rand()&0x3f];
	salt[1]=itoa64[rand()&0x3f];
	salt[2]='\0';
	return crypt(pass, salt);
}

char * to_amp(char *str) {
	char *tmp;

	tmp=str;
	while (str++[0])
		if (str[0]==' ') str[0]='&';
	return tmp;
}

void sas_append() {
	FILE *sas;
	char *tmp1, *tmp2, str[STRING_N], str1[STRING_N];
	int i, j;
	unsigned short k;

	tmp1=get_sasname(str);
	strcat(tmp1, ".sas");
	if (!(sas=fopen(tmp1, "w"))) hbase_error(5, tmp1);

	if (!(tmp1=find_path("saspath"))) hbase_error(6, "saspath");

	fprintf(sas, "\n\n /*Following codes from sas_append() */\n\n");
	fprintf(sas, "\n libname data \"%s\";", tmp1);
	fprintf(sas, "\n option ls=78 ps=78 nocaps;");

	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n length ");
	for (i=0; i<h_name_i; i++) {
		if (h_name[i]) 
			fprintf(sas, "\n\t %s %s%s.", h_name[i]->name_sas, 
			strcmp(h_name[i]->type1, "num") ? "$" : "",
			h_name[i]->note);
	}
	fprintf(sas, "\n\t operator $12. \n\t ip $20.;");
	tmp1=0;
	for (i=0; i<h_vari_i; i++) {
		if (!h_vari[i]) continue;
		if (h_vari[i]->name_ptr && h_vari[i]->name_ptr->name_sas) {
			if (!strcmp(h_vari[i]->name_ptr->name_html, "password"))
				h_vari[i]->value=crypt_pass(h_vari[i]->value);
			if (tmp1==h_vari[i]->name_ptr->name_sas) j++;
			else j=0;	
			if (strlen(h_vari[i]->name_ptr->name_sas)>8) 
				h_vari[i]->name_ptr->name_sas[8]=0;
			if (strcmp(h_vari[i]->name_ptr->type1,"char")) {
				for (k=0; k<strlen(h_vari[i]->value); k++) {
					if (!(isdigit(h_vari[i]->value[k])) 
					  && (h_vari[i]->value[k]!='.')) break;
				}
				if (!k) {h_vari[i]->value[0]='.';
					 h_vari[i]->value[1]='\0';
				}
				else h_vari[i]->value[k]='\0';
				if (j) {
					sprintf(str, "%s%d", h_vari[i]->name_ptr->name_sas, j);
					if (strlen(str)>8) str[8]=0;
					fprintf(sas, "\n\t %s=%s;", str,h_vari[i]->value);
				}
				else fprintf(sas, "\n\t %s=%s;", 
			h_vari[i]->name_ptr->name_sas, h_vari[i]->value);
			}
			else {
				while ((tmp2=strchr(h_vari[i]->value, '"')))
					tmp2[0]='\'';
				if (strlen(h_vari[i]->value)>198)
					h_vari[i]->value[198]='\0';
				if (j) {
					sprintf(str, "%s%d", h_vari[i]->name_ptr->name_sas, j);
					if (strlen(str)>8) str[8]=0;
					fprintf(sas, "\n\t %s=\"%s\";", str,h_vari[i]->value);
				}
				else fprintf(sas, "\n\t %s=\"%s\";", 
			h_vari[i]->name_ptr->name_sas, h_vari[i]->value);
			}
			tmp1=h_vari[i]->name_ptr->name_sas;
		}
	}
	tmp1=find_path("user_name");
	tmp2=getenv("REMOTE_ADDR");
	fprintf(sas, "\n\t operator='%s';", tmp1? tmp1 : "");
	fprintf(sas, "\n\t ip='%s';", tmp2? tmp2 : "");
	fprintf(sas, "\n\t timestmp=datetime();");
	fprintf(sas, "\n run;");

	if (!(tmp1=find_path("userdata"))) hbase_error(50, NULL);
	fprintf(sas, "\n proc append base=data.%s data=work.tmp force;", tmp1);
	fprintf(sas, "\n run;");

	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n status='n';");
	fprintf(sas, "\n run;");
	if (!(tmp1=find_path("userback"))) hbase_error(50, NULL);
	fprintf(sas, "\n proc append base=data.%s data=work.tmp force;", tmp1);
	fprintf(sas, "\n run;");
	fclose(sas);

	tmp1=get_sasname(str);
	sprintf(str1, "sas %s.sas", tmp1);
	system(str1);
}

void sas_update() {
	FILE *sas;
	char *tmp1, *tmp2, str[STRING_N], str1[STRING_N];
	int i, j;
	unsigned short k;

	tmp1=get_sasname(str);
	strcat(tmp1, ".sas");
	if (!(sas=fopen(tmp1, "w"))) hbase_error(5, tmp1);

	if (!(tmp1=find_path("saspath"))) hbase_error(6, "saspath");
	fprintf(sas, "\n\n /*Following codes from sas_update() */\n\n");
	fprintf(sas, "\n libname data \"%s\";", tmp1);
	fprintf(sas, "\n option ls=78 ps=78 nocaps;");

	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n length ");
	for (i=0; i<h_name_i; i++) {
		if (h_name[i]) 
			fprintf(sas, "\n\t %s %s%s.", h_name[i]->name_sas, 
			strcmp(h_name[i]->type1, "num") ? "$" : "",
			h_name[i]->note);
	}
	fprintf(sas, "\n\t operator $12. \n\t ip $20.;");
	tmp1=0;
	for (i=0; i<h_vari_i; i++) {
		if (!h_vari[i]) continue;
		if (h_vari[i]->name_ptr && h_vari[i]->name_ptr->name_sas) {
			if (!strcmp(h_vari[i]->name_ptr->name_html, "password"))
				h_vari[i]->value=crypt_pass(h_vari[i]->value);
			if (tmp1==h_vari[i]->name_ptr->name_sas) j++;
			else j=0;	
			if (strlen(h_vari[i]->name_ptr->name_sas)>8) 
				h_vari[i]->name_ptr->name_sas[8]=0;
			if (strcmp(h_vari[i]->name_ptr->type1,"char")) {
				for (k=0; k<strlen(h_vari[i]->value); k++) {
					if (!(isdigit(h_vari[i]->value[k])) 
					  && (h_vari[i]->value[k]!='.')) break;
				}
				if (!k) {h_vari[i]->value[0]='.';
					 h_vari[i]->value[1]='\0';
				}
				else h_vari[i]->value[k]='\0';
				if (j) {
					sprintf(str, "%s%d", h_vari[i]->name_ptr->name_sas, j);
					if (strlen(str)>8) str[8]=0;
					fprintf(sas, "\n\t %s=%s;", str,h_vari[i]->value);
				}
				else fprintf(sas, "\n\t %s=%s;", 
			h_vari[i]->name_ptr->name_sas, h_vari[i]->value);
			}
			else {
				while ((tmp2=strchr(h_vari[i]->value, '"')))
					tmp2[0]='\'';
				if (strlen(h_vari[i]->value)>198)
					h_vari[i]->value[198]='\0';
				if (j) {
					sprintf(str, "%s%d", h_vari[i]->name_ptr->name_sas, j);
					if (strlen(str)>8) str[8]=0;
					fprintf(sas, "\n\t %s=\"%s\";", str,h_vari[i]->value);
				}
				else fprintf(sas, "\n\t %s=\"%s\";", 
			h_vari[i]->name_ptr->name_sas, h_vari[i]->value);
			}
			tmp1=h_vari[i]->name_ptr->name_sas;
		}
	}
	tmp1=find_path("user_name");
	tmp2=getenv("REMOTE_ADDR");
	fprintf(sas, "\n\t operator='%s';", tmp1? tmp1 : "");
	fprintf(sas, "\n\t ip='%s';", tmp2? tmp2 : "");
	fprintf(sas, "\n\t timestmp=datetime();");
	fprintf(sas, "\n run;");

	if (!(tmp1=find_path("userdata"))) hbase_error(50, NULL);
	fprintf(sas, "\n proc sort data=data.%s;", tmp1);
	fprintf(sas, "\n by u_name;");
	fprintf(sas, "\n run;");
	fprintf(sas, "\n proc sort data=tmp;");
	fprintf(sas, "\n by u_name;");
	fprintf(sas, "\n run;");
	fprintf(sas, "\n data data.%s;", tmp1);
	fprintf(sas, "\n update data.%s tmp;", tmp1);
	fprintf(sas, "\n by u_name;");
	fprintf(sas, "\n run;");

	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n set tmp;");
	fprintf(sas, "\n status='u';");
	fprintf(sas, "\n run;");
	if (!(tmp1=find_path("userback"))) hbase_error(50, NULL);
	fprintf(sas, "\n proc append base=data.%s data=work.tmp force;", tmp1);
	fprintf(sas, "\n run;");
	fclose(sas);

	tmp1=get_sasname(str);
	sprintf(str1, "sas %s.sas", tmp1);
	system(str1);
}

void sas_delete(char * u_name) {
	FILE *sas;
	char *tmp1, str[STRING_N], str1[STRING_N];

	tmp1=get_sasname(str);
	strcat(tmp1, ".sas");
	if (!(sas=fopen(tmp1, "w"))) hbase_error(5, tmp1);

	if (!(tmp1=find_path("saspath"))) hbase_error(6, "saspath");
	fprintf(sas, "\n\n /*Following codes from sas_delete() */\n\n");
	fprintf(sas, "\n libname data \"%s\";", tmp1);
	fprintf(sas, "\n option ls=78 ps=78 nocaps;");

	if (!(tmp1=find_path("userdata"))) hbase_error(50, NULL);
	fprintf(sas, "\n data data.%s tmp;", tmp1);
	fprintf(sas, "\n set data.%s;", tmp1);
	fprintf(sas, "\n if (u_name='%s') then do;", u_name);
	fprintf(sas, "\n status='d';");
	fprintf(sas, "\n output tmp; \n end;");
	fprintf(sas, "\n else output data.%s;", tmp1);
	fprintf(sas, "\n run;");

	if (!(tmp1=find_path("userback"))) hbase_error(50, NULL);
	fprintf(sas, "\n proc append base=data.%s data=work.tmp force;", tmp1);
	fprintf(sas, "\n run;");
	fclose(sas);

	tmp1=get_sasname(str);
	sprintf(str1, "sas %s.sas", tmp1);
	system(str1);
}

void sas_find_users(char * u_name) {
	FILE *sas;
	char *tmp1, *tmp2, str[STRING_N], str1[STRING_N];
	int j;

	tmp1=get_sasname(str);
	strcat(tmp1, "fu.sas");
	if (!(sas=fopen(tmp1, "w"))) hbase_error(5, tmp1);

	if (!(tmp1=find_path("saspath"))) hbase_error(6, "saspath");
	fprintf(sas, "\n\n /*Following codes from sas_find_users() */\n\n");
	fprintf(sas, "\n libname data \"%s\";", tmp1);
	fprintf(sas, "\n option ls=78 ps=78 nocaps;");

	if (!(tmp1=find_path("userdata"))) hbase_error(50, NULL);
	fprintf(sas, "\n data _null_;");
	fprintf(sas, "\n set data.%s (where=(u_name='%s'));", tmp1, u_name);
	tmp1=get_sasname(str);
	strcat(tmp1, "fu.dat");
	fprintf(sas, "\n file '%s';", tmp1);
	fprintf(sas, "\n put \"user_name=\" u_name;");
	fprintf(sas, "\n put \"password=\" password;");
	fprintf(sas, "\n put \"group=\" group;");
	fprintf(sas, "\n put \"status=\" status;");
	fprintf(sas, "\n run;");
	fclose(sas);

	tmp1=get_sasname(str);
	if (!(tmp2=find_path("sas_bin"))) tmp2="sas";
	sprintf(str1, "%s %sfu.sas", tmp2, tmp1);
	system(str1);

	sprintf(str1, "%sfu.dat", tmp1);
	h_user=NULL;
	query_user(str1);

	j=atoi(find_path("sas"));
	if (j) {printf("\n<pre>"); fflush(stdout);}
	switch(j) {
		case 1: sprintf( str1, "%sfu.sas", tmp1);
			put_file_norep(str1); break;
		case 2: sprintf( str1, "%sfu.log", tmp1);
			put_file_norep(str1); break;
		case 3: sprintf( str1, "%sfu.lst", tmp1);
			put_file_norep(str1); break;
		case 4: sprintf( str1, "%sfu.dat", tmp1);
			put_file_norep(str1); break;
		default: break;
	}

	if (j) {fflush(stdout); printf("\n</pre>"); fflush(stdout);}
/*	sprintf(str1, "rm %sfu*", tmp1);
	system(str1);
*/
}

USER * find_user(char *key) {
	int i;

	for (i=0; i<h_user_i; i++) {
		if (!strcmp(key, h_user[i]->username)) return h_user[i];
	}
	return NULL;
}

void query_user(char * userfile) {
	char *tmp1, *tmp2, buf[BUFFER_N];
	int i;
	FILE *user;

	h_user_i=0;
	if (!(user=fopen(userfile, "r"))) return;

	while (!(feof(user))) {
		if (!(tmp1=fgets(buf, BUFFER_N, user))) continue;
		if (tmp2=strstr(tmp1, "user_name=")) h_user_i++;
	}
	if (!h_user_i) {h_user=NULL; return;}
	if (!(h_user=(USER**) malloc(h_user_i*sizeof(USER *)))) hbase_error(3, "user-1");

	rewind(user);
	h_user_i=0;
	while (!(feof(user))) {
		if (!(tmp1=fgets(buf, BUFFER_N, user))) break;;
		i=strlen(tmp1);
		if (tmp1[i-1]=='\n') tmp1[i-1]='\0';
		if (tmp2=strstr(tmp1, "user_name=")) {
			if (!(h_user[h_user_i]=(USER *) malloc(sizeof(USER)))) 
				hbase_error(3, "user-2");
			h_user[h_user_i]->number=NULL;
			h_user[h_user_i]->username=NULL;
			h_user[h_user_i]->password=NULL;
			h_user[h_user_i]->group=NULL;
			h_user[h_user_i]->status=NULL;
			h_user[h_user_i]->prompt=NULL;
			if (!(h_user[h_user_i]->username=(char *) 
				malloc((strlen(tmp1+10))*sizeof(char)))) hbase_error(3, "user-3");
			strcpy(h_user[h_user_i]->username, tmp1+10);
		}
		else if (tmp2=strstr(tmp1, "password=")) {
			if (!(h_user[h_user_i]->password=(char *) 
				malloc((strlen(tmp1+9))*sizeof(char)))) hbase_error(3, "user-4");
			strcpy(h_user[h_user_i]->password, tmp1+9);
		}
		else if (tmp2=strstr(tmp1, "group=")) {
			if (!(h_user[h_user_i]->group=(char *) 
				malloc((strlen(tmp1+6))*sizeof(char)))) hbase_error(3, "user-5");
			strcpy(h_user[h_user_i]->group, tmp1+6);
		}
		else if (tmp2=strstr(tmp1, "status=")) {
			if (!(h_user[h_user_i]->status=(char *) 
				malloc((strlen(tmp1+7))*sizeof(char)))) hbase_error(3, "user-6");
			strcpy(h_user[h_user_i]->status, tmp1+7);
			h_user_i++;
		}
	}
	fclose(user);
}

char * spacetoplus(char *str) {
	int i;

	for (i=0; str[i]; i++) 
		if (str[i]==' ') str[i]='+';
	return str;
}

void get_access(VARI *v_ptr, USER *user) {
	char *tmp, str[BUFFER_N];
	REPLACE * repla[2];

	if (!(repla[0]=malloc(sizeof(REPLACE)))) hbase_error(3, "user-6");
	repla[0]->key="%user_name%";
	repla[0]->rep=user->username;
	repla[1]=NULL;

	if (tmp=find_path("measure")) {
		sprintf(str, "measure%s", tmp);
		tmp=find_path(str);
	}
	if (!tmp) tmp=find_path("getaccess");
	if (!tmp) hbase_error(51, "getaccess");
	put_file_rep(tmp, 0, repla);
}

void deny_access() {
 	char *tmp;

	if (!(tmp=find_path("denyaccess"))) {
		printf("\n<font size=+2><b>Access Denied.</b></font>");
	}
	else {
		put_file_norep(tmp);
	}
}

char * comp_pass(char *cpass, char *tpass) {
	char salt[4];

	salt[0]=cpass[0];
	salt[1]=cpass[1];
	salt[2]='\0';
	return cpass;
}

void user_exist(char * user) {
	int i, j;
	char * tmp;
	VARI ** v_ptr;
	REPLACE ** repla;

	if (!(repla=(REPLACE **) malloc((h_name_i+1)*sizeof(REPLACE *)))) 
		hbase_error(3, "user-7");
	for (i=0; i<h_name_i; i++) {
		if (!(repla[i]=malloc(sizeof(REPLACE)))) hbase_error(3, "user-8");
		if (!(repla[i]->key=malloc(strlen(h_name[i]->name_html)+4))) hbase_error(3, "user-9");
		sprintf(repla[i]->key, "%%%s%%\0", h_name[i]->name_html);
		
		v_ptr=find_vari(h_name[i]->name_html, 1, 0, &j);
		if (!v_ptr || j<=0) v_ptr=find_vari(h_name[i]->name_html, 1, 1, &j);
		if (!v_ptr || j<=0) repla[i]->rep='\0';
		else repla[i]->rep=v_ptr[0]->value;
	}

	repla[i]=NULL;
	
	if (!(tmp=find_path("userexist")))
		printf("\n User %s existed in the database.", user);
	else put_file_rep(tmp, 0, repla);
}

void user_not_exist() {
	int i, j;
	char * tmp;
	VARI ** v_ptr;
	REPLACE ** repla;

	if (!(repla=(REPLACE **) malloc((h_name_i+1)*sizeof(REPLACE *)))) 
		hbase_error(3, "user-10");
	for (i=0; i<h_name_i; i++) {
		if (!(repla[i]=malloc(sizeof(REPLACE)))) hbase_error(3, "user-11");
		if (!(repla[i]->key=malloc(strlen(h_name[i]->name_html)+4))) hbase_error(3, "user-12");
		sprintf(repla[i]->key, "%%%s%%\0", h_name[i]->name_html);
		
		v_ptr=find_vari(h_name[i]->name_html, 1, 0, &j);
		if (!v_ptr || j<=0) v_ptr=find_vari(h_name[i]->name_html, 1, 1, &j);
		if (!v_ptr || j<=0) repla[i]->rep='\0';
		else repla[i]->rep=v_ptr[0]->value;
	}

	repla[i]=NULL;
	
	if (!(tmp=find_path("usersave"))) hbase_error(51, "usersave");
	else put_file_rep(tmp, 0, repla);

	sas_update();
}

void user_save() {

	if (h_user) user_exist(h_user[0]->username);
	else user_not_exist();
}

void user_logon() {
	int i;
	USER * u_ptr;
	VARI ** v_ptr;

	v_ptr=find_vari("user_name", 1, 1, &i);
	if (!v_ptr || i<=0) deny_access();
	if (u_ptr=find_user(v_ptr[0]->value)) get_access(v_ptr[0], u_ptr);
	else deny_access();
}

int user_check(int pass) {
	char *user_name, *password, *group;
	USER * u_ptr;

	if (!(user_name=find_path("user_name"))) return 0;
	sas_find_users(user_name);
	if (!(u_ptr=find_user(user_name))) return 0;
	if (pass) {
		if (!(password=find_path("password"))) return 0;
		if (!(comp_pass(u_ptr->password, password))) return 0;
	}
	if (!(group=find_path("group"))) return 0;
	if (!strstr(group, u_ptr->group)) return 0;

	return 1;
}

int role_check() {
	char *role, *group;
	VARI ** v_ptr;
	int i;
	
	if (!(role=find_path("role"))) return 0;
	if (!(group=find_path("group"))) return 1;
	if (strcmp(role, group)) return 0;
	else return 1;
}

void sas_info(char * key) {
	char str1[STRING_N], str2[STRING_N], *tmp;
	int i;
	FILE *sas;

        tmp=get_sasname(str1);
	sprintf(str2, "%sdb.sas", str1);
        if (!(sas=fopen(str2, "w"))) hbase_error(5, str2);

        if (!(tmp=find_path("saspath"))) hbase_error(6, "saspath");
        fprintf(sas, "\n libname data \"%s\";", tmp);

		if (!(tmp=find_path("userdata"))) hbase_error(7, NULL);
	fprintf(sas, "\n\n /*Following codes from sas_info() */\n\n");
        fprintf(sas, "\n data _null_;");
        fprintf(sas, "\n set data.%s ", tmp);
	fprintf(sas, "(where=(u_name=\"%s\"));", key);
	sprintf(str2, "%sdb.dat", str1);
        fprintf(sas, "\n file \"%s\" lrecl=80;", str2);

	for (i=0; i<h_name_i; i++) {
		fprintf(sas, "\n put \"%s=\" %s;", h_name[i]->name_html, h_name[i]->name_sas);
	}
	fprintf(sas, "\n run;");
	fclose(sas);
        tmp=get_sasname(str1);
        sprintf(str2, "sas %sdb.sas", str1);
        system(str2);

	return;
}

REPLACE ** sas_rep_info(char *key) {
	char str1[STRING_N], str2[STRING_N], *tmp ;
	int i;
	FILE *dat;
	REPLACE **repla;

	sas_info(key);
	if (!(repla=(REPLACE **) malloc((h_name_i+1)*sizeof(REPLACE *)))) 
		hbase_error(3, "user-13");
	for (i=0; i<h_name_i; i++) {
		if (!(repla[i]=malloc(sizeof(REPLACE)))) hbase_error(3, "user-14");
		if (!(repla[i]->key=malloc(strlen(h_name[i]->name_html)+3)))
			hbase_error(3, "user-15");
		sprintf(repla[i]->key, "%%%s%%", h_name[i]->name_html);
		repla[i]->rep=" ";
	}
	repla[i]=NULL;

        get_sasname(str1);
        strcat(str1, "db.dat");
	if (!(dat=fopen(str1, "r"))) return repla;

	while (!feof(dat)) {
		if (!fgets(str1, STRING_N, dat)) continue;
		if (!(tmp=strchr(str1, '='))) continue;
		tmp[0]='\0';
		if (!strcmp(de_space(tmp+1), ".")) continue;
		sprintf(str2, "%%%s%%", str1);
		for (i=0; i<h_name_i; i++) {
			if (!strcmp(str2, repla[i]->key)) {
				if (!(repla[i]->rep=malloc(strlen(tmp+1)+3)))
					hbase_error(3, "user-16");
				sprintf(repla[i]->rep, "%s", de_space(tmp+1));
				break;
			}
		}
	}
	fclose(dat);

        tmp=get_sasname(str1);
	i=atoi(find_path("sas"));
	if (i) {printf("\n<pre>"); fflush(stdout);}
	switch(i) {
		case 1: sprintf( str2, "cat %sdb.sas", str1);
			system(str2); break;
		case 2: sprintf( str2, "cat %sdb.log", str1);
			system(str2); break;
		case 3: sprintf( str2, "cat %sdb.lst", str1); 
			system(str2); break;
		case 4: sprintf( str2, "cat %sdb.dat", str1); 
			system(str2); break;
		default: break;
	}
	if (i) {fflush(stdout); printf("\n</pre>"); fflush(stdout);}
        sprintf(str2, "rm %sdb*", str1);
        system(str2);
	return repla;
}

void user_update() {
	int i, j;
	char *tmp;
	USER * u_ptr;
	VARI ** v_ptr, ** p_ptr;
	REPLACE ** repla;

	v_ptr=find_vari("user_name", 1, 1, &i);
	p_ptr=find_vari("password",  1, 1, &j);
	if (!v_ptr || i<=0 || !p_ptr || j<=0) {deny_access(); return;}
	if (!(u_ptr=find_user(v_ptr[0]->value))) {deny_access(); return;}
	if (comp_pass(u_ptr->password, p_ptr[0]->value)) {deny_access(); return;}

	repla=sas_rep_info(v_ptr[0]->value);
	if (!(tmp=find_path("userupdate"))) hbase_error(51, "userupdate");
	else put_file_rep(tmp, 0, repla);
}
