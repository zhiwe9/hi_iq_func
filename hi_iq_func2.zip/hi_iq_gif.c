/* HI-IQ System, the High Information Internet Query System,
	Copyright 1995, 1996, 1997, 1998 Utah Office of Health Data Analysis.

	hi_iq_gif.c	11/11/98
	produce gif graph include bar, pie, line, etc.

	We provide the interactive interface to make your data available
	to public through Internet.

	gd library written by Thomas Boutell, 5/94.
	Copyright 1994, Cold Spring Harbor Labs.
*/

#include "hi_iq.h"
#include "hi_iq_var.h"
#include "gd.h"
#include "gdfontmb.h"
#include "gdfonts.h"

#define costScale 1024
#define sintScale 1024

extern int cost[];
extern int sint[];

double dyc_to_dy(char * dy) {
	unsigned short  i, j;
	char buf[BUFFER_N];

	for (i=0, j=0; i<strlen(dy); i++) {
		if (isdigit(dy[i]) || dy[i]=='.') {
			buf[j]=dy[i];
			j++;
		}
	}
	buf[j]=0;
	return(atof(buf));
}

void gif_out() {
	int i, j, k, l;
	char str[BUFFER_N], str2[BUFFER_N], *tmp, *tmp2, *cross2;
	char ** dx1, ** dx2=NULL, **dyc;
	double * dy;
	FILE *gif;

	if (_cross_2 && !strcmp(_cross_2, "detail")) {
		if ((i=dat_get2(&dx1, &dyc, ""))<=0) return;
		for (k=0; k<h_path_i; k++)
			if (!strcmp(h_path[k]->name, "cross2")) break;
			cross2=h_path[k]->path;
			h_path[k]->path=NULL;
	}
	else {
		if ((i=dat_get(&dx1, &dx2, &dyc, ""))<=0) return;
	}
	if (!(dy=(double *) malloc((i+1)*sizeof(double)))) hbase_error(3, "gif-1");
	for (j=0; j<i; j++) dy[j]=dyc_to_dy(dyc[j]);

	tmp=get_sasname(str2);
	tmp2=find_path("gifrpath");
    sprintf(str, "%s%s%d.gif", tmp2,tmp, j);
    if (!(gif=fopen(str, "wb"))) hbase_error(13, str);
	l=gif_graph(gif, dx1, dx2, dy, 1, i);
	fclose(gif);
	if (l) {
		tmp2=find_path("gifwpath");
		printf("\n <center><img src=\"%s%s%d.gif\"></center>", tmp2, tmp, j);
		printf("\n <br>This graph was created with Thomas Boutell's gd library."); 
	}

	for (j=0; j<i; j++) {
		if (dx1[j]) free(dx1[j]);
		if (dyc[j]) free(dyc[j]);
	}
	free(dx1); free(dyc); free(dy); 
	if (dx2) {
		for (j=0; j<i; j++) if (dx2[j]) free(dx2[j]);
		free(dx2);
	}

	if (_cross_2 && !strcmp(_cross_2, "detail")) h_path[k]->path=cross2;
}

#define SX 540
#define SY 360
#define MARGIN 20
#define EXPEND 100
#define OFFSET MARGIN+EXPEND

int unitx, unity;
double max, min, mmy;

int gif_graph(FILE * gif, char ** dx1, char ** dx2, double *dy, int j, int n) {
	gdImagePtr im;
	int i, s, sx=SX, sy=SY, g_flag;
	int white, black, red, yellow, blue, gray;
	char * tmp;

	if (!(tmp=find_path("graph"))) g_flag=1;
	else g_flag=atoi(tmp);
	for (s=0; s<n; s++) {
		if (!dx2) {
			if (strcmp(dx1[s], ".") && dx1[s][0]) break;
		}
		else {
			if (strcmp(dx1[s], ".") && dx1[s][0]) break; 
/*			if (strcmp(dx1[s], ".") && dx1[s][0] && 
				strcmp(dx2[s], ".") && dx2[s][0]) break; */
		}
	}
	if (s==n) return 0;
	max=dy[s]; min=max;
	for (i=s+1; i<n; i++) {
		if (max<dy[i]) max=dy[i];
		if (min>dy[i]) min=dy[i];
	}
	unitx=(SX-MARGIN*2)/(n-s);
	unity=(SY-MARGIN*2)/(n-s);

	if (g_flag==6) {
		im=gif_get_map();
		white=gdImageColorExact(im, 255, 255, 255);
		black=gdImageColorExact(im, 0, 0, 0);
	}
	else {
		im=gdImageCreate(sx+2*EXPEND, sy+EXPEND);
		white=gdImageColorAllocate(im, 255, 255, 255);
		black=gdImageColorAllocate(im, 0, 0, 0);
	}
	red=gdImageColorAllocate(im, 255, 0, 0);
	yellow=gdImageColorAllocate(im, 0, 255, 0);
	blue=gdImageColorAllocate(im, 0, 0, 255);
	gray=gdImageColorAllocate(im, 191, 191, 191);
	gdImageColorTransparent(im, white);
	switch(g_flag) {
	case 1: gif_bar(im, dx1, dx2, dy, j, n, s);
		break;
	case 2: gif_line(im, dx1, dx2, dy, j, n, s);
		break;
	case 3: gif_pie(im, dx1, dx2, dy, j, n, s);
		break;
	case 4: gif_bar2(im, dx1, dx2, dy, j, n, s);
		break;
	case 5: gif_line2(im, dx1, dx2, dy, j, n, s);
		break;
	case 6: gif_map(im, dx1, dx2, dy, j, n, s);
		break;
	default: gif_bar(im, dx1, dx2, dy, j, n, s);
		break;
	}
	
	gdImageGif(im, gif);
	gdImageDestroy(im);
	return 1;
}

gdImagePtr gif_get_map() {
	gdImagePtr tmp;
	FILE * map;

	if (!(map=file_open("gifbase", 1))) hbase_error(22, "map");
	if (!(tmp=gdImageCreateFromGif(map))) hbase_error(26, "map");
	fclose(map);
	return(tmp);
}

void gif_map(gdImagePtr im,char ** dx1,char ** dx2,double * dy,int j,int n,int s) {
	int white, black, blue, color[COLOR_N];
	int i, x, y;
	char * path, buf[BUFFER_N], str2[64], str3[64];
	FILE * county;

	sas_cross(str2, str3);
	if (strcmp(str2, "ptcounty") || str3[0]) hbase_error(23, str2);
	if (!(county=file_open("gifmap", 1))) hbase_error(22, "path");
	gif_color(im, color, 8);
	white=gdImageColorExact(im, 255, 255, 255);
	black=gdImageColorExact(im, 0, 0, 0);
	blue=gdImageColorExact(im, 0, 0, 255);

	while (!feof(county)) {
		path=fgets(buf, BUFFER_N, county);
		if (strlen(buf)<2) break;
		i=gif_map_county(path, dx1, dy, &x, &y, s, n, str3);
		if (i<0) continue;
		gif_fill(im, x, y, black, color[i]);  
	}

	rewind(county);
	while (!feof(county)) {
		path=fgets(buf, BUFFER_N, county);
		if (strlen(buf)<2) break;
		i=gif_map_county(path, dx1, dy, &x, &y, s, n, str3);
		gdImageString(im, gdFontSmall, (int) (x-4*strlen(str3)), y-8, str3, black); 
	}
	gif_title(im, j, 5);
	gif_map_legend(im, color, 5);

}

int gif_map_county(char * str, char ** dx1, double * dy, int * x, int * y, int s, int n, char * name) {
	int i, k=0;
	unsigned short j;
	char * tmp, * tmp2;

	tmp=strchr(str, ' ');
	tmp[0]=0;
	for (i=s; i<n; i++) {
		if (atoi(dx1[i])==atoi(str)) break;
	}
	if (i>=n) k=-1;
	tmp2=strchr(tmp+1, ' ');
	tmp2[0]=0;
	*x=atoi(tmp+1);
	tmp=strchr(tmp2+1, ' ');
	tmp[0]=0;
	*y=atoi(tmp2+1);
	for (j=1; j<strlen(tmp+1); j++) {
		if (tmp[j]=='&') name[j-1]=' ';
		else name[j-1]=tmp[j];
	}
	name[j-1]=0;
	if (max==min) return(1);
	if (dy[i]==max) i=5;
	else i=(int) (5*(dy[i]-min)/(max-min)+1);
	return(k? k : i);
}

void gif_map_legend(gdImagePtr im, int *color, int n) {
	int i, black, x0=460, y0=160;
	double unit;
	char buf[BUFFER_N];

	black=gdImageColorExact(im, 0, 0, 0);
	unit=(max-min)/n;
	for (i=0; i<n; i++) {
		gif_box(im, x0, y0-10+i*40, 20, 10, black, color[i+1]);
		sprintf(buf, "%.2f -- %.2f", i*unit+min, (i+1)*unit+min);
		gdImageString(im, gdFontSmall, x0, y0+i*40, buf, black);
	}
}

void gif_bar(gdImagePtr im,char ** dx1,char ** dx2,double * dy,int j,int n,int s) {
	int white, black, blue, color[COLOR_N];
	int i, m=0, k, l;
	char * dxc[COLOR_N], * tmp, * tmp2, buf[BUFFER_N], str2[64], str3[64];

	if (n-s>COLOR_N) {
		sprintf(buf, "%d", n-s);
		hbase_error(15, buf);
	}
	sas_cross(str2, str3);
	if (dx2) {
		dxc[0]=dx2[s];
		m++;
		for (i=s+1; i<n; i++) {
			if (gif_exist(dxc, dx2[i], m)) {
				 dxc[m]=dx2[i];
				 m++;
			}
		}
		for (i=1; i<m; i++) {
			for (k=i+1; k<m; k++) {
				if (strcmp(dxc[i], dxc[k])) {
					tmp=dxc[i];
					dxc[i]=dxc[k];
					dxc[k]=tmp;
				}
			}
		}
		gif_color(im, color, m>COLOR_N ? COLOR_N : m);
	}

	white=gdImageColorExact(im, 255, 255, 255);
	black=gdImageColorExact(im, 0, 0, 0);
	blue=gdImageColorExact(im, 0, 0, 255);
	gdImageLine(im, OFFSET, SY-MARGIN, SX+EXPEND-MARGIN, SY-MARGIN, black);
	gdImageLine(im, OFFSET, SY-MARGIN, OFFSET, MARGIN, black);
	gif_title(im, j, 2);
	gif_label(im, max, min);

	tmp=dx1[s]; k=0;
	for (i=s; i<n; i++) {
		if (!dx2) {
			gif_box(im, (int) ((i-s)*unitx*0.8)+OFFSET+5, SY-MARGIN,
			(int) (unitx*2)/3,
			(int) ((dy[i]-min)*mmy+3), black, blue);
			if (!(tmp2=find_format(str2, dx1[i], buf)))
				tmp2=dx1[i];
			tmp2[(int) ((EXPEND+MARGIN/2-18)/8)]=0;	
			gdImageStringUp(im, gdFontSmall, (int) ((i-s)*unitx*0.8+OFFSET+5), 
				SY-MARGIN/2+strlen(tmp2)*8-1, tmp2, black);
		}
		else {
			for (l=0; l<m; l++) 
				if (!strcmp(dx2[i], dxc[l])) break;
			if (strcmp(tmp, dx1[i])) {
				if (!(tmp2=find_format(str2, tmp, buf)))
					tmp2=tmp;
				tmp2[(int) ((EXPEND+MARGIN/2-18)/8)]=0;	
				gdImageStringUp(im, gdFontSmall,
				(int) (OFFSET+((i-s-1)*0.8+(k+0.25)*0.3)*unitx),
				(int) (SY-MARGIN/2+strlen(tmp2)*8-1), 
				tmp2, black);
				tmp=dx1[i];
				k++;
				gdImageLine(im, 
				(int) (OFFSET+((i-s)*0.8+(k+0.25)*0.3)*unitx),
				(int) (SY-MARGIN), 
				(int) (OFFSET+((i-s)*0.8+(k+0.25)*0.3)*unitx),
				(int) (SY-MARGIN-5), black);
				gif_box(im, 
				(int) (OFFSET+((i-s)*0.8+(k+1)*0.3)*unitx),
				(int) (SY-MARGIN),
				(int) (unitx*2)/3,
				(int) ((dy[i]-min)*mmy+3), black, color[l]);
			}
			else {
				gif_box(im, 
				(int) (OFFSET+((i-s)*0.8+(k+1)*0.3)*unitx),
				(int) (SY-MARGIN),
				(int) (unitx*2)/3,
				(int) ((dy[i]-min)*mmy+3), black, color[l]);
			}
			
		}
	}
	if (dx2) {
		if (!(tmp2=find_format(str2, tmp, buf)))
			tmp2=tmp;
		tmp2[(int) ((EXPEND+MARGIN/2-18)/8)]=0;	
		gdImageStringUp(im, gdFontSmall, 
		(int) (OFFSET+((i-s-1)*0.8+(k+0.25)*0.3)*unitx),
		(int) (SY-MARGIN/2+strlen(tmp2)*8-1), tmp2, black);
		k++;
		gdImageLine(im, 
		(int) (OFFSET+((i-s)*0.8+(k+0.25)*0.3)*unitx),
		(int) (SY-MARGIN), 
		(int) (OFFSET+((i-s)*0.8+(k+0.25)*0.3)*unitx),
		(int) (SY-MARGIN-5), black);
	}
	if (tmp=find_path(str2)) {
		gdImageString(im, gdFontSmall, (int) (EXPEND+(SX-8*strlen(tmp))/2), 
			(int) (SY+EXPEND-17), tmp, black);
	}
	gif_legend(im, dxc, color, m, 2, SX+EXPEND);
}

void gif_bar2(gdImagePtr im, char ** dx1, char ** dx2, double * dy, int j, int n, int s) {
	int white, black, color[COLOR_N];
	int i, m=0, k, l=0, t, p;
	double sum=0, dtmp=0;
	char * dxc[COLOR_N], * tmp, * tmp2;
	char buf[BUFFER_N], str2[64], str3[64];

	if (n-s>2*COLOR_N) {
		sprintf(buf, "%d", n-s);
		hbase_error(15, buf);
	}
	sas_cross(str2, str3);
	if (dx2) {
		dxc[0]=dx2[s];
		m++;
		tmp=dx1[s];
		for (i=s+1; i<n; i++) {
			if (atoi(tmp) != atoi(dx1[i])) {
				 tmp=dx1[i];
				 l++;
			}
			if (gif_exist(dxc, dx2[i], m)) {
				 dxc[m]=dx2[i];
				 m++;
			}
		}
		for (i=1; i<m; i++) {
			for (k=i+1; k<m; k++) {
				if (atoi(dxc[i]) > atoi(dxc[k])) {
					tmp=dxc[i];
					dxc[i]=dxc[k];
					dxc[k]=tmp;
				}
			}
		}
	}
	else {
		for (i=s; i<n; i++) {
			dxc[i-s]=dx1[i];
			sum+=dy[i];
		}
		if (sum==0) hbase_error(20, NULL);
		l=n-s;
		m=n-s;
	}

	white=gdImageColorExact(im, 255, 255, 255);
	black=gdImageColorExact(im, 0, 0, 0);
	gif_color(im, color, m>COLOR_N ? COLOR_N : m);
	gif_box(im, OFFSET, SY-MARGIN, SX-2*MARGIN, SY-2*MARGIN, black, white);
	k=(int) ((SY-2*MARGIN)/10);

	if (!dx2) {
		gdImageLine(im, (int) (OFFSET+0.2*SX), MARGIN, 
			(int) (OFFSET+0.2*SX), SY-MARGIN, black);
		gdImageLine(im, (int) (OFFSET+0.8*SX), MARGIN, 
			(int) (OFFSET+0.8*SX), SY-MARGIN, black);
		for (i=s; i<n; i++) {
			gdImageLine(im, (int) (OFFSET+0.2*SX), 
				(int) (MARGIN+k*(dtmp+dy[i])/sum*10), 
				(int) (OFFSET+0.8*SX),
				(int) (MARGIN+k*(dtmp+dy[i])/sum*10), black);
			gif_fill(im, (int) (OFFSET+0.5*SX), 
				(int) (MARGIN+k*(2*dtmp+dy[i])/sum*5), 
				black, color[i-s]);
			dtmp+=dy[i];
		}
	}
	else {
		tmp="-1";  
		t=0;
		for (i=s; i<n; i++) {
			if (atoi(tmp)!=atoi(dx1[i])) {
				tmp=dx1[i];
				
				gdImageLine(im,
				(int) (OFFSET+(t+0.2)*(SX-2*MARGIN)/(l+1)),
				MARGIN, 
				(int) (OFFSET+(t+0.2)*(SX-2*MARGIN)/(l+1)), 
				SY-MARGIN, black);
				gdImageLine(im,
				(int) (OFFSET+(t+0.8)*(SX-2*MARGIN)/(l+1)),
				MARGIN, 
				(int) (OFFSET+(t+0.8)*(SX-2*MARGIN)/(l+1)), 
				SY-MARGIN, black);
				if (!(tmp2=find_format(str2, tmp, buf)))
				tmp2=tmp;
				tmp2[(int) ((EXPEND+MARGIN/2-18)/8)]=0;	
				gdImageStringUp(im, gdFontSmall, 
				(int) (OFFSET+(t+0.5)*(SX-2*MARGIN)/(l+1)-8),
				(int) (SY-MARGIN/2+strlen(tmp2)*8-1), 
				tmp2, black);
				t++;

				sum=0;
				dtmp=0;
				for (p=0; p<m && i+p<n; p++) {
					if (atoi(tmp)!=atoi(dx1[i+p])) break;
					sum+=dy[i+p];
				}
			}
			if (sum==0) continue;
			for (p=0; p<m; p++) 
				if (atoi(dx2[i])==atoi(dxc[p])) break;
			if (dy[i]!=0) {
				gdImageLine(im, 
				(int) (OFFSET+(t-0.8)*(SX-2*MARGIN)/(l+1)),
				(int) (MARGIN+k*(dtmp+dy[i])/sum*10), 
				(int) (OFFSET+(t-0.2)*(SX-2*MARGIN)/(l+1)),
				(int) (MARGIN+k*(dtmp+dy[i])/sum*10), black);
				gif_fill(im,  
				(int) (OFFSET+(t-0.5)*(SX-2*MARGIN)/(l+1)),
				(int) (MARGIN+k*(2*dtmp+dy[i])/sum*5), 
				black, color[p]);
				dtmp+=dy[i];
			}
			
		}
	}

	for (i=0; i<11; i++) {
		sprintf(buf, "%d%%", i*10);
		gdImageString(im, gdFontSmall, (int) (OFFSET-8*strlen(buf)-4), 
			(int) (SY-MARGIN-k*i-10), buf, black);
		gdImageLine(im, OFFSET, SY-MARGIN-k*i, 
			OFFSET+5, SY-MARGIN-k*i, black);
		gdImageLine(im, OFFSET+SX-2*MARGIN, SY-MARGIN-k*i, 
			OFFSET+SX-2*MARGIN-5, SY-MARGIN-k*i, black);
		if (i==2 || i==4 || i==6 || i==8) 
			gif_dot_line(im, OFFSET, SY-MARGIN-k*i, 
				OFFSET+SX-2*MARGIN, SY-MARGIN-k*i, black);
	}
	gif_title(im, j, 2);

	if (tmp=find_path(str2))
		gdImageString(im, gdFontSmall, EXPEND+(SX-8*strlen(tmp))/2, SY+EXPEND-17, tmp, black);
	gif_legend(im, dxc, color, m, dx2 ? 2 : 1, SX+EXPEND);
}

void gif_dot_line(gdImagePtr im, int x0, int y0, int x1, int y1, int color) {
	int i, flag=0, xd, yd;

	xd=x1-x0;
	yd=y1-y0;
	if (abs(yd)>abs(xd)) {
		for (i=0; i<abs(yd); i+=6) {
			if (flag) flag=0;
			else {
				gdImageLine(im, (int) (x0+xd/abs(yd)*i),
					(int) (y0+yd/abs(yd)*i), 
					(int) (x0+xd/abs(yd)*(i+4)),
					(int) (y0+yd/abs(yd)*(i+4)), color);
					
				flag=1;
			}
		}
	}
	else {
		for (i=0; i<abs(xd); i+=6) {
			if (flag) flag=0;
			else {
				gdImageLine(im, (int) (x0+xd/abs(xd)*i),
					(int) (y0+yd/abs(xd)*i), 
					(int) (x0+xd/abs(xd)*(i+4)),
					(int) (y0+yd/abs(xd)*(i+4)), color);
				flag=1;
			}
		}

	}
}

int gif_exist(char ** dxc, char * dx2, int n) {
	int i;

	for (i=0; i<n; i++) {
		if (!strcmp(dxc[i],dx2)) break;
	}
	return(i==n ? 1 : 0);
}

void gif_line2(gdImagePtr im, char ** dx1, char ** dx2, double * dy, int j, int n, int s) {
	int white, black, blue, yellow, color[COLOR_N];
	int i, m=0, k, p=0, q;
	int x0, y0, x1, y1, * yk, *yk1;
	double sum, dtmp;
	char * dxb[COLOR_N], * dxc[COLOR_N], * tmp, * tmp2;
	char buf[BUFFER_N], str2[64], str3[64];

	if (n-s>COLOR_N) {
		sprintf(buf, "%d", n-s);
		hbase_error(15, buf);
	}
	sas_cross(str2, str3);
	if (dx2) {
		dxb[0]=dx1[s];
		dxc[0]=dx2[s];
		m++;
		for (i=s+1; i<n; i++) {
			if (gif_exist(dxb, dx1[i], p)) {
				dxb[p]=dx1[i];
				p++;
			}
			if (gif_exist(dxc, dx2[i], m)) {
				dxc[m]=dx2[i];
				m++;
			}
		}
		for (i=1; i<p; i++) {
			for (k=i+1; k<p; k++) {
				if (atoi(dxb[i]) > atoi(dxb[k])) {
					tmp=dxb[i];
					dxb[i]=dxb[k];
					dxb[k]=tmp;
				}
			}
		}
		for (i=1; i<m; i++) {
			for (k=i+1; k<m; k++) {
				if (atoi(dxc[i]) > atoi(dxc[k])) {
					tmp=dxc[i];
					dxc[i]=dxc[k];
					dxc[k]=tmp;
				}
			}
		}
		sum=0;
		for (i=0; i<p; i++) {
			dtmp=0;
			for (k=0; k<m; k++) {
				dtmp+=gif_line2_find(dxb[i], dxc[k], 
						dx1, dx2, dy, n, s);
			}
			if (sum<dtmp) sum=dtmp;
		}
		gif_color(im, color, m>COLOR_N ? COLOR_N : m);
	}
	else {
		p=n-s;
	}

	white=gdImageColorExact(im, 255, 255, 255);
	black=gdImageColorExact(im, 0, 0, 0);
	blue=gdImageColorExact(im, 0, 0, 255);
	yellow=gdImageColorAllocate(im, 0, 255, 0);
	gif_box(im, OFFSET, SY-MARGIN, SX-2*MARGIN, SY-2*MARGIN, black, white);
	gif_title(im, j, 2);
	if (dx2) gif_label(im, sum, 0);
	else gif_label(im, max, min);

	if (!dx2) {
		x0=OFFSET;
		y0=(int) (SY-MARGIN-dy[s]*mmy-1);
		if (!(tmp2=find_format(str2, dx1[s], buf)))
			tmp2=dx1[s];
		tmp2[(int) ((EXPEND+MARGIN/2-18)/8)]=0;	
		gdImageStringUp(im, gdFontSmall, x0-4, 
			SY-MARGIN/2+strlen(tmp2)*8-1, tmp2, black);
		for (i=s+1; i<n; i++) {
			x1=(int) (OFFSET+(i-s)*(SX-2*MARGIN)/(p-1));
			y1=(int) (SY-MARGIN-(dy[i]-min)*mmy-1);
			gdImageLine(im, x0, y0, x1, y1, black); 
			gdImageLine(im, x1, SY-MARGIN, x1, SY-MARGIN-5, black);
			if (!(tmp2=find_format(str2, dx1[i], buf)))
				tmp2=dx1[i];
			tmp2[(int) ((EXPEND+MARGIN/2-18)/8)]=0;	
			gdImageStringUp(im, gdFontSmall, x1-4, 
				SY-MARGIN/2+strlen(tmp2)*8-1, tmp2, black);
			x0=x1;
			y0=y1;
		}
		x0=OFFSET;
		y0=(int) (SY-MARGIN-dy[s]*mmy-1);
		for (i=s+1; i<n; i++) {
			x1=(int) (OFFSET+(i-s)*(SX-2*MARGIN)/(p-1));
			y1=(int) (SY-MARGIN-(dy[i]-min)*mmy-1);
			if (gdImageGetPixel(im, (int) ((x0+x1)/2),
				(int) ((y0+y1+SY-MARGIN)/3)) == blue) {
				x0=x1;
				y0=y1;
				continue;
			}
			gif_fill(im, (int) ((x0+x1)/2),
				(int) ((y0+y1+SY-MARGIN)/3), black, blue);
			x0=x1;
			y0=y1;
		}
	}
	else {
		q=0;
		if (!(yk=(int *) malloc(m*sizeof(int)))) hbase_error(3, "gif-2");
		if (!(yk1=(int *) malloc(m*sizeof(int)))) hbase_error(3, "gif_3");
		for (k=m-1; k>=0; k--) {
			q+=(int) (gif_line2_find(dxb[0], dxc[k], 
				dx1, dx2, dy, n, s)*mmy);
			yk[k]=(int) (SY-MARGIN-q-1);
		}
		x0=OFFSET;
		if (!(tmp2=find_format(str2, 
			dxb[0], buf)))
			tmp2=dx1[i];
		tmp2[(int) ((EXPEND+MARGIN/2-18)/8)]=0;	
		gdImageStringUp(im, gdFontSmall, x0-4, 
		(int) (SY-MARGIN/2+strlen(tmp2)*8-1), 
		tmp2, black);

		for (i=1; i<p; i++) {
			x1=(int) (OFFSET+i*(SX-2*MARGIN)/(p-1));
			gdImageLine(im, x1, SY-MARGIN, x1, 
			(int) (SY-MARGIN-5), black);
			if (!(tmp2=find_format(str2, 
				dxb[i], buf)))
				tmp2=dx1[i];
			tmp2[(int) ((EXPEND+MARGIN/2-18)/8)]=0;	
			gdImageStringUp(im, gdFontSmall, x1-4, 
			(int) (SY-MARGIN/2+strlen(tmp2)*8-1), 
			tmp2, black);

			q=0;
			for (k=m-1; k>=0; k--) {
				q+=(int) (gif_line2_find(dxb[i], dxc[k], 
					dx1, dx2, dy, n, s)*mmy);
				y1=(int) (SY-MARGIN-q-1);
				gdImageLine(im, x0, yk[k], x1, y1, black); 
				yk[k]=y1;
			}
			x0=x1;
		}

		q=0;
		for (k=m-1; k>=0; k--) {
			q+=(int) (gif_line2_find(dxb[0], dxc[k], 
				dx1, dx2, dy, n, s)*mmy);
			yk[k]=(int) (SY-MARGIN-q-1);
		}
		x0=OFFSET;

		for (i=1; i<p; i++) {
			q=0;
			for (k=m-1; k>=0; k--) {
				q+=(int) (gif_line2_find(dxb[i], dxc[k], 
					dx1, dx2, dy, n, s)*mmy);
				yk1[k]=(int) (SY-MARGIN-q-1);
			}

			x1=(int) (OFFSET+i*(SX-2*MARGIN)/(p-1));
			gif_fill(im, 
			(int) ((x0+x1)/2),
			(int) ((2*(SY-MARGIN)+yk[m-1]+yk1[m-1])/4),
			black, color[m-1]);
			for (k=m-2; k>=0; k--) {
				if (yk[k+1]-yk[k]<1 || yk1[k+1]-yk1[k]<1) 
					continue;
				gif_fill(im, 
				(int) ((x0+x1)/2),
				(int) ((yk[k+1]+yk[k]+yk1[k+1]+yk1[k])/4),
				black, color[k]);
			}
			for (k=m-1; k>=0; k--) 
				yk[k]=yk1[k];
			x0=x1;
		}
		free(yk); free(yk1);
	}
	if (tmp=find_path(str2)) 
		gdImageString(im, gdFontSmall, EXPEND+(SX-8*strlen(tmp))/2, 
		(int) (SY+EXPEND-17), tmp, black);
	gif_legend(im, dxc, color, m, 2, SX+EXPEND);
}

double gif_line2_find(char * dxb, char * dxc, char ** dx1, char ** dx2, double * dy, int n, int s) {
	int k;

	for (k=s; k<n; k++) {
		if (atoi(dx1[k])==atoi(dxb) && atoi(dx2[k])==atoi(dxc))
			return(dy[k]);
	}
	return(0);
}
	

void gif_line(gdImagePtr im, char ** dx1, char ** dx2, double * dy, int j, int n, int s) {
	int white, black, blue, yellow, color[COLOR_N];
	int i, m=0, k, p=0, q;
	int x0, y0, x1, y1, * yk, *yk1;
	char * dxb[COLOR_N], * dxc[COLOR_N], * tmp, * tmp2;
	char buf[BUFFER_N], str2[64], str3[64];

	if (n-s>COLOR_N) {
		sprintf(buf, "%d", n-s);
		hbase_error(15, buf);
	}
	sas_cross(str2, str3);
	if (dx2) {
		dxb[0]=dx1[s];
		dxc[0]=dx2[s];
		m++;
		for (i=s+1; i<n; i++) {
			if (gif_exist(dxb, dx1[i], p)) {
				dxb[p]=dx1[i];
				p++;
			}
			if (gif_exist(dxc, dx2[i], m)) {
				dxc[m]=dx2[i];
				m++;
			}
		}
		for (i=1; i<p; i++) {
			for (k=i+1; k<p; k++) {
				if (atoi(dxb[i]) > atoi(dxb[k])) {
					tmp=dxb[i];
					dxb[i]=dxb[k];
					dxb[k]=tmp;
				}
			}
		}
		for (i=1; i<m; i++) {
			for (k=i+1; k<m; k++) {
				if (atoi(dxc[i]) > atoi(dxc[k])) {
					tmp=dxc[i];
					dxc[i]=dxc[k];
					dxc[k]=tmp;
				}
			}
		}
		gif_color(im, color, m>COLOR_N ? COLOR_N : m);
	}
	else {
		p=n-s;
	}

	white=gdImageColorExact(im, 255, 255, 255);
	black=gdImageColorExact(im, 0, 0, 0);
	blue=gdImageColorExact(im, 0, 0, 255);
	yellow=gdImageColorAllocate(im, 0, 255, 0);
	gif_box(im, OFFSET, SY-MARGIN, SX-2*MARGIN, SY-2*MARGIN, black, white);
	gif_title(im, j, 2);
	gif_label(im, max, min);

	if (!dx2) {
		x0=OFFSET;
		y0=(int) (SY-MARGIN-(dy[s]-min)*mmy-1);
		if (!(tmp2=find_format(str2, dx1[s], buf)))
			tmp2=dx1[s];
		tmp2[(int) ((EXPEND+MARGIN/2-18)/8)]=0;	
		gdImageStringUp(im, gdFontSmall, x0-4, 
			SY-MARGIN/2+strlen(tmp2)*8-1, tmp2, black);
		for (i=s+1; i<n; i++) {
			x1=(int) (OFFSET+(i-s)*(SX-2*MARGIN)/(p-1));
			y1=(int) (SY-MARGIN-(dy[i]-min)*mmy-1);
			gdImageLine(im, x0, y0, x1, y1, blue); 
			gdImageLine(im, x1, SY-MARGIN, x1, SY-MARGIN-5, black);
			if (!(tmp2=find_format(str2, dx1[i], buf)))
				tmp2=dx1[i];
			tmp2[(int) ((EXPEND+MARGIN/2-18)/8)]=0;	
			gdImageStringUp(im, gdFontSmall, x1-4, 
				SY-MARGIN/2+strlen(tmp2)*8-1, tmp2, black);
			x0=x1;
			y0=y1;
		}
	}
	else {
		q=0;
		if (!(yk=(int *) malloc(m*sizeof(int)))) hbase_error(3, "gif-4");
		if (!(yk1=(int *) malloc(m*sizeof(int)))) hbase_error(3, "gif-5");
		for (k=m-1; k>=0; k--) {
			q=(int) ((gif_line2_find(dxb[0], dxc[k], 
				dx1, dx2, dy, n, s)-min)*mmy);
			yk[k]=(int) (SY-MARGIN-q-1);
		}
		x0=OFFSET;
		if (!(tmp2=find_format(str2, 
			dxb[0], buf)))
			tmp2=dx1[i];
		tmp2[(int) ((EXPEND+MARGIN/2-18)/8)]=0;	
		gdImageStringUp(im, gdFontSmall, x0-4, 
		(int) (SY-MARGIN/2+strlen(tmp2)*8-1), 
		tmp2, black);

		for (i=1; i<p; i++) {
			x1=(int) (OFFSET+i*(SX-2*MARGIN)/(p-1));
			gdImageLine(im, x1, SY-MARGIN, x1, 
			(int) (SY-MARGIN-5), black);
			if (!(tmp2=find_format(str2, 
				dxb[i], buf)))
				tmp2=dx1[i];
			tmp2[(int) ((EXPEND+MARGIN/2-18)/8)]=0;	
			gdImageStringUp(im, gdFontSmall, x1-4, 
			(int) (SY-MARGIN/2+strlen(tmp2)*8-1), 
			tmp2, black);

			q=0;
			for (k=m-1; k>=0; k--) {
				q=(int) ((gif_line2_find(dxb[i], dxc[k], 
					dx1, dx2, dy, n, s)-min)*mmy);
				y1=(int) (SY-MARGIN-q-1);
				gdImageLine(im, x0, yk[k], x1, y1, color[k]); 
				yk[k]=y1;
			}
			x0=x1;
		}

		free(yk); free(yk1);
	}
	if (tmp=find_path(str2)) {
		gdImageString(im, gdFontSmall, EXPEND+(SX-8*strlen(tmp))/2, 
		(int) (SY+EXPEND-17), tmp, black);
	}
	gif_legend(im, dxc, color, m, 2, SX+EXPEND);
}

int gif_line_next(char ** dx1, char ** dx2, char * dxc, int ptr, int n) {
	int i, flag=0;
	char * tmp;

	tmp = dx1[ptr];
	for (i=ptr+1; i<n; i++) {
		if (flag==0 && strcmp(tmp, dx1[i])) {
			flag=1; 
			tmp=dx1[i];
		}
		if (flag==1 && strcmp(tmp, dx1[i])) return(1-i);
		if (flag==1 && !strcmp(dxc, dx2[i])) return(i);
	}
	return (flag ? 0-i : i);
}

void gif_pie(gdImagePtr im, char ** dx1, char ** dx2, double * dy, int j, int n, int s) {
	int white, black, color[COLOR_N];
	double * sy, t, sum=0;
	int i, k, l, as, ae, x, y, x0, y0;
	char * tmp, str[STRING_N];

	if (n-s>COLOR_N) {
		sprintf(str, "%d", n-s);
		hbase_error(15, str);
	}
	if (dx2) hbase_error(19, NULL);
	white=gdImageColorExact(im, 255, 255, 255);
	black=gdImageColorExact(im, 0, 0, 0);
	gif_color(im, color, n>COLOR_N ? COLOR_N : n);

	if (!(sy=(double *) malloc((n-s+1)*sizeof(double)))) hbase_error(3, "gif-6");
	for (i=0; i<n-s; i++) {
		sy[i]=dy[i+s];
		sum+=sy[i];
	}
	if (sum==0) hbase_error(20, NULL);
	for (i=0; i<n-s; i++) {
		for (k=i+1; k<n-s; k++) {
			if (sy[i]<sy[k]) {
				t=sy[i];
				sy[i]=sy[k];
				sy[k]=t;
				tmp=dx1[i+s];
				dx1[i+s]=dx1[k+s];
				dx1[k+s]=tmp;
			}
		}
	}
	gif_title(im, j, 1);
	as=0;
	gdImageLine(im, (int) (EXPEND+SX/2), (int) (SY/2), 
			(int) (EXPEND+SX/2+SX/3) ,(int) (SY/2), black);
	x0=(int) (EXPEND+SX/2+SX/3);
	y0=(int) (SY/2);
	gdImageArc(im, (int) (EXPEND+SX/2), (int) (SY/2), 
		(int) (SX/1.5), (int) (SY/1.5), 0, 360, black);
	for (i=0; i<n-s; i++) {
		ae = (int) (360*(sy[i]/sum));
		as += ae;
		x = ((long) cost[as%360] * (long) (SX/3)/costScale) + SX/2;
		y = ((long) sint[as%360] * (long) (SY/3)/sintScale) + SY/2;
		if (i<n-s-1)
		gdImageLine(im, (int) (EXPEND+SX/2), (int) (SY/2), EXPEND+x, y, black);
		gif_fill(im,(int) (EXPEND+(SX/2+x+x0)/3), 
			ae>=170 ? (int) (SY/1.5) : (int) ((SY/2+y+y0)/3),
			black, color[i]);
		l = (int) (ae/3.6);
		sprintf(str, "%d%%", l);
		gdImageString(im, gdFontSmall, (int) (EXPEND+(SX/2+x+x0)/3-4), 
			ae>=170 ? (int) (SY/1.5-8) : (int) ((SY/2+y+y0)/3-8),
			str, black);
		x0=x; y0=y;
		
		if (as>350) {
			break;
		}
	}
	if (i==n-s-2)
	gif_fill(im, (int) ((EXPEND+SX/3+SX+x0)/3), (int)((SY+y0)/3), 
			black, color[i+1]);
	free(sy);
	for (i=s; i<n; i++) {
		for (k=i+1; k<n; k++) {
			if (atoi(dx1[i])>atoi(dx1[k])) {
				tmp=dx1[i];
				dx1[i]=dx1[k];
				dx1[k]=tmp;
				t=color[i-s];
				color[i-s]=color[k-s];
				color[k-s]=(int) t;
			}
		}
	}
	gif_legend(im, dx1+s, color, n-s, 1, 1);
}

void gif_box(gdImagePtr im, int x0, int y0, int xl, int yl, int border, int color) {
	int mx, my;

	mx=x0+xl/2;
	my=y0-yl/2;

	gdImageLine(im, x0, y0, x0, y0-yl, border);
	gdImageLine(im, x0, y0-yl, x0+xl, y0-yl, border);
	gdImageLine(im, x0+xl, y0-yl, x0+xl, y0, border);
	gdImageLine(im, x0+xl, y0, x0, y0, border);
	gdImageFillToBorder(im, mx, my, border, color);
}

void gif_color(gdImagePtr im, int * color, int n) {
	int i, l=255, m=255;

	for (i=0; i<n; i+=12) {
		color[i] = gdImageColorAllocate(im, l, 0, 0);
		color[i+1]=gdImageColorAllocate(im, 0, l, 0);
		color[i+2]=gdImageColorAllocate(im, 0, 0, l);
		color[i+3]=gdImageColorAllocate(im, 0, l, l);
		color[i+4]=gdImageColorAllocate(im, l, 0, l);
		color[i+5]=gdImageColorAllocate(im, l, l, 0);
		color[i+6]=gdImageColorAllocate(im, l, l/2, 0);
		color[i+7]=gdImageColorAllocate(im, 0, l, l/2);
		color[i+8]=gdImageColorAllocate(im, l/2, 0, l);
		color[i+9]=gdImageColorAllocate(im, l, 0, l/2);
		color[i+10]=gdImageColorAllocate(im, l/2, l, 0);
		color[i+11]=gdImageColorAllocate(im, 0, l/2, l);
		l-=64;
	}
}

void gif_fill(gdImagePtr im, int x, int y, int border, int color) {
	int c;

	if (x<0 || x>im->sx || y<0 || y>im->sy) return;
	c = gdImageGetPixel(im, x, y);
	if (c==border || c==color) return;

	gdImageSetPixel(im, x, y, color);
	gif_fill(im, x+1, y, border, color);
	gif_fill(im, x-1, y, border, color);
	gif_fill(im, x, y+1, border, color);
	gif_fill(im, x, y-1, border, color);
	return;
}

void gif_legend(gdImagePtr im, char ** dx, int * color, int n, int flag, int x0) {
	char buf[STRING_N], str2[64], str3[64], * tmp, * tmp2;
	int black, i, y0, w, h, c;
	NAME * n_ptr;

	sas_cross(str2, str3);
	tmp = (flag==1) ? str2 : str3;
	black=gdImageColorExact(im, 0, 0, 0);
	
	y0=MARGIN/2;
	if (tmp) n_ptr=find_name(tmp, 1);
	if (n_ptr && n_ptr->prompt) strcpy(buf, n_ptr->prompt);
	else buf[0]=0;
	if (x0==1) buf[12]=0;
	else buf[(int) ((SX+2*EXPEND-x0)/8)]=0;
	gdImageString(im, gdFontSmall, x0, y0, buf, black);
	w=(int) (EXPEND/4);
	c=n;
	if (c<5) c=5;
	if (c>15) c=15;
	h=(int) ((SY-MARGIN-EXPEND)/5/c);
	for (i=0; i<n; i++) {
		y0=(int) (2*MARGIN+i*(SY-MARGIN)/(n>15 ? n : c));
		gif_box(im, x0, y0, w, h, black, color[i]);
	}
	for (i=0; i<n; i++) {
		y0=(int) (2*MARGIN+i*(SY-MARGIN)/(n>15 ? n : c));
		tmp2=find_format(tmp, dx[i], buf);
		if (!tmp2) tmp2=dx[i];
		tmp2[10]=0;
		gdImageString(im, gdFontSmall, x0, y0+2, tmp2, black);
	}
}

void gif_title(gdImagePtr im, int j, int p) {
	char *tmp, str[BUFFER_N];
	int black;

	black=gdImageColorExact(im, 0, 0, 0);
	if (tmp=find_path("func")) {
		sprintf(str, "func%s", tmp);
		tmp=find_path(str);
	}

	if (!tmp) tmp="Hbase Graph";
	strcpy(str, tmp);
	tmp=de_space(str);
	if (p==1 || p==3) str[SX]=0;
	if (p==2 || p==4) str[SY]=0;
	switch(p) {
	case 1: gdImageString(im, gdFontMediumBold, EXPEND+(SX-8*strlen(tmp))/2, MARGIN/2, tmp, black);
		break;
	case 2: gdImageStringUp(im, gdFontMediumBold, 2, (SY+8*strlen(tmp))/2, tmp, black);
		break;
	case 3: gdImageString(im, gdFontMediumBold, EXPEND+(SX-8*strlen(tmp))/2, SY+EXPEND-MARGIN/2, tmp, black);
		break;
	case 4: gdImageStringUp(im, gdFontMediumBold, SX+2*EXPEND-MARGIN/2, (SY+8*strlen(tmp))/2, tmp, black);
		break;
	case 5: gdImageString(im, gdFontMediumBold, 200, 25, tmp, black);
	        gdImageString(im, gdFontMediumBold, 199, 24, tmp, black);
		break;
	default: break;
	}
}

void gif_label(gdImagePtr im, double ma, double mi) {
	int i, k, black;
	double t, m1, m2, mm;
	char str[STRING_N];

	black=gdImageColorExact(im, 0, 0, 0);
	m1=ma; m2=mi;
	if (ma>100) {
		for (i=0; ; i++) {
			if (m1<100) break;
			m1/=10;
			m2/=10;
		}
	}
	if (ma<10) {
		for (i=0; ; i++) {
			if (m1<10) break;
			m1*=10;
			m2*=10;
		}
	}
	m1=(int) m1+1;
	m2=(int) m2-1;
	if (m2<0) m2=0;
	if (ma>100) {
		for (k=0; k<i; k++) {
			m1*=10;
			m2*=10;
		}
	}
	if (ma<10) {
		for (k=0; k<i; k++) {
			m1/=10;
			m2/=10;
		}
	}
	mm=(SY-MARGIN*4)/(m1-m2);
	max=m1; min=m2;
	ma=m1; mi=m2;
	mmy=mm;

	t=(ma-mi)/10;
	for (i=0; i<11; i++) {
		sprintf(str, "%6.2f", t*i+mi);
		gdImageString(im, gdFontSmall, (int) (OFFSET-8*strlen(str)-3), 
				(int) (SY-MARGIN-(t*i)*mm-15), str, black);
		gdImageLine(im, OFFSET, (int) (SY-MARGIN-(t*i)*mm-1),
				OFFSET+5, (int ) (SY-MARGIN-(t*i)*mm-1), 
					black);
	}
}
