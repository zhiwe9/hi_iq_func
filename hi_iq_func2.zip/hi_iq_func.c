/* HI-IQ System, the High Information Internet Query System,
	Copyright 1995, 1996, 1997, 1998 Utah Office of Health Data Analysis.

	hi_iq_func.c 11/11/98
	process function definition file to build up SAS program.

	We provide the interactive interface to make your data available
	to public through Internet.
*/

#include "hi_iq.h"
#include "hi_iq_var.h"

void func_test_out() {
  int i, j, flag=1;

    i=atoi(find_path("test"));
    if (i==9) {
        if (flag>0 && xml) {
		printf("\n<DEBUG>", flag);
		printf("\n\t<TYPE>test</TYPE>");
		printf("\n\t<VALUE>%d</VALUE>", flag);
	 	printf("\n\t<TITLE>FUNC List</TITLE>\n\t<TEXT>");
	}
	else printf("\n<br><b>Func List:</b>");

	for (i=0; h_func[i]; i++) {
                fflush(stdout);
		printf("\n key--*%s\t", h_func[i]->key? h_func[i]->key : "null");
		printf(" value--*%s\t", h_func[i]->value? h_func[i]->value : "null");
		if (h_func[i]->script) {
			printf("\n script -- ");
			for (j=0; h_func[i]->script[j]; j++) {
				printf("\n %s", h_func[i]->script[j]);
			}
		}
		else printf("\t script -- null");
	}
	if (flag>0 && xml) printf("\n\t</TEXT>\n</DEBUG>");
	fflush(stdout);
    }
}

void sas_bld() {
	FILE * sas;
	char str[STRING_N], * tmp, * tmp2;
	FUNC * func_p;

	if (form==21 || form==22 || form==23 || form==30) {
	  //printf("\n<SUB_POPULATION>");
	}

	tmp = get_sasname(str);
	strcat(tmp, ".sas");
	if (!(sas=fopen(tmp, "w"))) hbase_error(5, NULL);

	fprintf(sas, "\n /* Following code from sas_bld() */ ");
	if (!(tmp=find_path("saspath"))) hbase_error(6, NULL);
	fprintf(sas, "\n libname data \"%s\";", tmp);
	tmp2=find_path("saspop");
	fprintf(sas, "\n libname pop \"%s\";", tmp2 ? tmp2 : tmp);
	fprintf(sas, "\n options mlogic mprint source source2;");
	fflush(sas);
	sas_dataFrame_cross(sas);
	fflush(sas);
	sas_select(sas);
	fflush(sas);
	sas_group(sas);
	fflush(sas);
	sas_cross_bld(sas, "cross1", "tmp");
	fflush(sas);
	sas_cross_bld(sas, "cross2", "tmp");
	fflush(sas);
	sas_cross_bld(sas, "cross3", "tmp");
	fflush(sas);
	if (form>0 && form!=3 && form !=4 && form!=6 && form != 8 
		&& form!=21 && form!=22 && form!=23) {
		printf(" </I></UL></B><HR>");
	}
	fflush(stdout);
	sas_no_obs(sas);
	fflush(sas);

	sas_func_def(sas);

	func_p=find_func(h_func, "nogeo");
	tmp=find_path("nogeo");
	if ((func_p && atoi(func_p->value)==1) || (tmp && atoi(tmp)==1)) {
		sas_select_nogeo(sas);
		fflush(sas);
		sas_group(sas);
		fflush(sas);
		sas_cross_bld(sas, "cross1", "tmp");
		fflush(sas);
		sas_cross_bld(sas, "cross2", "tmp");
		fflush(sas);
		sas_cross_bld(sas, "cross3", "tmp");
		fflush(sas);
		sas_no_obs(sas);
		sas_pop_select_nogeo(sas, "saspopdata");
	}

	sas_func_bld(sas, h_func);
	fflush(sas);

        func_test_out();
	fclose(sas);

	if (form==21 || form==22 || form==23 || form==30) {
	  //printf("\n</SUB_POPULATION>");
	}
}

FUNC * h_func_bld(char * tmp) {
	char *tmp2;
	FUNC * func;

	if (!(func=(FUNC *) malloc(sizeof(FUNC)))) hbase_error(3, "func-1");
	if (!(tmp2=strchr(tmp, ' '))) hbase_error(46, tmp);
	tmp2[0]=0;
	if (!(func->type=malloc(strlen(tmp)+1))) hbase_error(3, "func-2");
	strcpy(func->type, tmp);
	tmp=tmp2+1;
	if (!(tmp2=strchr(tmp, ' '))) hbase_error(57, tmp);
	tmp2[0]=0;
	if (!(func->key=malloc(strlen(tmp)+1))) hbase_error(3, "func-3");
	strcpy(func->key, tmp);
	tmp=tmp2+1;
	if (tmp2=strchr(tmp, ' ')) tmp2[0]=0;
	cl_amp(tmp);
	tmp2=de_space(tmp);
	if (!(func->value=malloc(strlen(tmp2)+1))) hbase_error(3, "func-4");
	strcpy(func->value, tmp2);
	func->script=NULL;
	return func;
}

void test_func(FUNC ** func) {
	int i, j;

	for (i=0; func[i]; i++) {
		printf("\ntype--*%s key--*%s value--*%s<br>", func[i]->type,
			func[i]->key, func[i]->value? func[i]->value:"NULL");
		if (func[i]->script) {
			printf("\n script<br>");
			for (j=0; func[i]->script[j]; j++)
				printf("\n%s<br>", func[i]->script[j]);
		}
	}

	fflush(stdout);
}

FUNC * find_func(FUNC ** func, char * key) {
	int i;

	for (i=0; func[i]; i++) {
		if (!(strcmp(func[i]->key, key))) return func[i];
	}

	return NULL;
}

void data_where(FILE *sas, FUNC *func_p, char *name) {
	int i;

	fprintf(sas, "\n\n/* Following codes from data_where() */");
	fprintf(sas, "\n data %s;", name);
	fprintf(sas, "\n set %s;", name);
	fprintf(sas, "\n if (");
	if (isdigit(func_p->type[0])) {
		for (i=0; func_p->script[i]; i++) 
			fprintf(sas, "%s", func_p->script[i]);
	}
	else fprintf(sas, "%s", func_p->value);
	fprintf(sas, ");");
	fprintf(sas, "\n run;");
}

void data_filter(FILE *sas, FUNC *func_p, char *name) {
	int i, c;
	char * filter;
	VARI ** vpr;

	fprintf(sas, "\n\n/* Following codes from data_filter() */");
	filter =  func_p->value;
	vpr=find_vari(filter, 2, 0, &c);
	if (vpr!=NULL && c>0 ) {
	fprintf(sas, "\n data %s;", name);
	fprintf(sas, "\n set %s;", name);
	fprintf(sas, "\n if ( %s in (", filter);

	for (i=0; i<c; i++ ) {
		fprintf(sas, "%s %s", vpr[i]->value, (i==c-1? " " : ", "));
	}
	fprintf(sas, "));");
	fprintf(sas, "\n run;");
	}
}

void sas_count(FILE *sas, FUNC **func) {
	char c1[STRING_N], c2[STRING_N], p1[STRING_N], p2[STRING_N]; 
	FUNC * func_p;
	char *dx[4];

	fprintf(sas, "\n\n/* Following codes from sas_count() */");
	sas_find_cross(c1, c2, p1, p2);
	fprintf(sas, "\n /* c1--*%s c2--*%s */", c1, c2);

	if (func_p=find_func(func, "data_where")) {
		data_where(sas, func_p, "tmp");
	}

	if (!(func_p=find_func(func, "variable"))) {
		fprintf(sas, "\n data tmp;");
		fprintf(sas, "\n set tmp;");
		fprintf(sas, "\n x=1;");
		fprintf(sas, "\n run;");
		fprintf(sas, "\n proc summary data=tmp n;");
		fprintf(sas, "\n var x;");
	}
	else {
		fprintf(sas, "\n proc summary data=tmp n;");
		fprintf(sas, "\n var %s;", func_p->value);
	}

	if (c1[0]) {
		fprintf(sas, "\n class %s", c1);
		if (c2[0]) fprintf(sas, " %s;", c2);
		else fprintf(sas, ";");
	}
	else {
		if (c2[0]) fprintf(sas, "\n class %s;", c2);
	}
	fprintf(sas, "\n output out=tmp sum=number1;");
	fprintf(sas, "\n run;");

	dx[0]="number1";
	dx[1]=0;
	if (form==21) 
	  //xml_sas_out(sas, dx, 4);
	  sas_lbl_out3(sas, dx[0], " ", dx, func_p->value, 1, "number1", NULL);
	else if (form==22 || form==23 || form==30)  {
	  sas_lbl_out2(sas, dx[0], " ", dx, NULL, 1, "number1", NULL);
	}
	  else {
/*
	if (form==21 || form==22 || form==23 || form==30) 
	  xml_sas_out(sas, dx, 1);
	else
*/
	dx[0]="number1";
	  sas_out(sas, dx[0], "15.0", 1);
	}
}

void sas_average(FILE *sas, FUNC **func) {
	char c1[STRING_N], c2[STRING_N], p1[STRING_N], p2[STRING_N]; 
	char *dx[6];
	FUNC * func_p;

	fprintf(sas, "\n\n/* Following codes from sas_average() */");
	sas_find_cross(c1, c2, p1, p2);

	if (func_p=find_func(func, "data_where")) {
		data_where(sas, func_p, "tmp");
	}

	fprintf(sas, "\n proc summary data=tmp ;");
	if (!(func_p=find_func(func, "variable"))) hbase_error(47, "variable");
	fprintf(sas, "\n var %s;", func_p->value);

	if (c1[0]) {
		fprintf(sas, "\n class %s", c1);
		if (c2[0]) fprintf(sas, " %s;", c2);
		else fprintf(sas, ";");
	}
	else {
		if (c2[0]) fprintf(sas, "\n class %s;", c2);
	}
	fprintf(sas, "\n output out=tmp mean=mean1 n=number1 ");
	fprintf(sas, "\n sum=sum1 stderr=stderr1;");
	fprintf(sas, "\n run;");

	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n set tmp;");
	fprintf(sas, "\n length ci $15.;");
	fprintf(sas, "\n if (number1=1) then ci='-';");
	fprintf(sas, "\n else do;");
	fprintf(sas, "\n select (number1);");
	fprintf(sas, "\n when (2) std=12.706;");
	fprintf(sas, "\n when (3) std= 4.303;");
	fprintf(sas, "\n when (4) std= 3.182;");
	fprintf(sas, "\n when (5) std= 2.776;");
	fprintf(sas, "\n when (6) std= 2.571;");
	fprintf(sas, "\n when (7) std= 2.447;");
	fprintf(sas, "\n when (8) std= 2.365;");
	fprintf(sas, "\n when (9) std= 2.306;");
	fprintf(sas, "\n when (10) std= 2.262;");
	fprintf(sas, "\n when (11) std= 2.228;");
	fprintf(sas, "\n when (12) std= 2.201;");
	fprintf(sas, "\n when (13) std= 2.179;");
	fprintf(sas, "\n when (14) std= 2.160;");
	fprintf(sas, "\n when (15) std= 2.145;");
	fprintf(sas, "\n when (16) std= 2.131;");
	fprintf(sas, "\n when (17) std= 2.120;");
	fprintf(sas, "\n when (18) std= 2.110;");
	fprintf(sas, "\n when (19) std= 2.101;");
	fprintf(sas, "\n when (20) std= 2.093;");
	fprintf(sas, "\n when (21) std= 2.086;");
	fprintf(sas, "\n when (22) std= 2.074;");
	fprintf(sas, "\n when (23) std= 2.069;");
	fprintf(sas, "\n when (24) std= 2.064;");
	fprintf(sas, "\n when (25) std= 2.060;");
	fprintf(sas, "\n when (26) std= 2.056;");
	fprintf(sas, "\n when (27) std= 2.052;");
	fprintf(sas, "\n when (28) std= 2.048;");
	fprintf(sas, "\n when (29) std= 2.045;");
	fprintf(sas, "\n when (30) std= 2.042;");
	fprintf(sas, "\n otherwise std= 1.96;");
	fprintf(sas, "\n end;");
	fprintf(sas, "\n t1=mean1-std*stderr1;");
	fprintf(sas, "\n if (t1<0) then t1=0;");
	fprintf(sas, "\n r1=put(t1, 8.2);");
	fprintf(sas, "\n r2=put((mean1+std*stderr1), 8.2);");
	fprintf(sas, "\n ci=compress(r1) || ' - ' || compress(r2);");
	fprintf(sas, "\n end;");
	fprintf(sas, "\n run;");

        if (form==22 || form==23 || form==30) {
          dx[0]=" mean1   15.2";
          dx[1]=" number1 10. ";
          dx[2]=" sum1 10. ";
          dx[3]=" r1 $15.";
          dx[4]=" r2 $15.";
          dx[5]=0;

        }
        else {
          dx[0]=" sum1 10. ";
          dx[1]=" number1 10. ";
          dx[2]=" mean1   15.2";
          dx[3]=" ci $15.";
        }
	_out_variable=3;

	if (form==21) 
	  //xml_sas_out(sas, dx, 4);
	  sas_lbl_out3(sas, "mean1", "15.2", dx, func_p->value, 4, "number1", "sum1");
	else if (form==22 || form==23 || form==30)  
          sas_lbl_out2(sas, dx[0], " ", dx, func_p->value, 5, "number1", "sum1");
	else {

	  if (!(func_p=find_func(func, "out_detail"))) 
		sas_out(sas, "mean1", "15.2", 0);
	  if (atoi(find_path("form"))==2) sas_out(sas, "mean1", "15.2", 0);
	  else sas_lbl_out(sas, "mean1", "15.2", dx, func_p->value, 4, "number1", "sum1");
	}
}

void sas_average_cv(FILE *sas, FUNC **func) {
	char c1[STRING_N], c2[STRING_N], p1[STRING_N], p2[STRING_N]; 
	char *dx[6];
	FUNC * func_p;

	fprintf(sas, "\n\n/* Following codes from sas_average_cv() */");
	sas_find_cross(c1, c2, p1, p2);

	if (func_p=find_func(func, "data_where")) {
		data_where(sas, func_p, "tmp");
	}

	fprintf(sas, "\n proc summary data=tmp ;");
	if (!(func_p=find_func(func, "variable"))) hbase_error(47, "variable");
	fprintf(sas, "\n var %s;", func_p->value);

	if (c1[0]) {
		fprintf(sas, "\n class %s", c1);
		if (c2[0]) fprintf(sas, " %s;", c2);
		else fprintf(sas, ";");
	}
	else {
		if (c2[0]) fprintf(sas, "\n class %s;", c2);
	}
	fprintf(sas, "\n output out=tmp mean=mean1 n=number1 ");
	fprintf(sas, "\n sum=sum1 stderr=stderr1;");
	fprintf(sas, "\n run;");

	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n set tmp;");
	fprintf(sas, "\n length ci $15.;");
	fprintf(sas, "\n if (number1=1) then ci='-';");
	fprintf(sas, "\n else do;");
	fprintf(sas, "\n select (number1);");
	fprintf(sas, "\n when (2) std=12.706;");
	fprintf(sas, "\n when (3) std= 4.303;");
	fprintf(sas, "\n when (4) std= 3.182;");
	fprintf(sas, "\n when (5) std= 2.776;");
	fprintf(sas, "\n when (6) std= 2.571;");
	fprintf(sas, "\n when (7) std= 2.447;");
	fprintf(sas, "\n when (8) std= 2.365;");
	fprintf(sas, "\n when (9) std= 2.306;");
	fprintf(sas, "\n when (10) std= 2.262;");
	fprintf(sas, "\n when (11) std= 2.228;");
	fprintf(sas, "\n when (12) std= 2.201;");
	fprintf(sas, "\n when (13) std= 2.179;");
	fprintf(sas, "\n when (14) std= 2.160;");
	fprintf(sas, "\n when (15) std= 2.145;");
	fprintf(sas, "\n when (16) std= 2.131;");
	fprintf(sas, "\n when (17) std= 2.120;");
	fprintf(sas, "\n when (18) std= 2.110;");
	fprintf(sas, "\n when (19) std= 2.101;");
	fprintf(sas, "\n when (20) std= 2.093;");
	fprintf(sas, "\n when (21) std= 2.086;");
	fprintf(sas, "\n when (22) std= 2.074;");
	fprintf(sas, "\n when (23) std= 2.069;");
	fprintf(sas, "\n when (24) std= 2.064;");
	fprintf(sas, "\n when (25) std= 2.060;");
	fprintf(sas, "\n when (26) std= 2.056;");
	fprintf(sas, "\n when (27) std= 2.052;");
	fprintf(sas, "\n when (28) std= 2.048;");
	fprintf(sas, "\n when (29) std= 2.045;");
	fprintf(sas, "\n when (30) std= 2.042;");
	fprintf(sas, "\n otherwise std= 1.96;");
	fprintf(sas, "\n end;");
	fprintf(sas, "\n t1=mean1-std*stderr1;");
	fprintf(sas, "\n if (t1<0) then t1=0;");
	fprintf(sas, "\n r1=put(t1, 8.2);");
	fprintf(sas, "\n r2=put((mean1+std*stderr1), 8.2);");
	fprintf(sas, "\n ci=compress(r1) || ' - ' || compress(r2);");
	fprintf(sas, "\n cv=.;");
	fprintf(sas, "\n end;");
	fprintf(sas, "\n run;");

        if (form==22 || form==23 || form==30) {
          dx[0]=" mean1   15.2";
          dx[1]=" number1 10. ";
          dx[2]=" sum1 10. ";
          dx[3]=" r1 $15.";
          dx[4]=" r2 $15.";
          dx[5]=" cv 10.";
          dx[6]=0;

        }
        else {
          dx[0]=" sum1 10. ";
          dx[1]=" number1 10. ";
          dx[2]=" mean1   15.2";
          dx[3]=" ci $15.";
          dx[4]=" cv 10.";
        }
	_out_variable=3;

	if (form==21) 
	  //xml_sas_out(sas, dx, 4);
	  sas_lbl_out3(sas, "mean1", "15.2", dx, func_p->value, 4, "number1", "sum1");
	else if (form==22 || form==23 || form==30)  
          sas_lbl_out2(sas, dx[0], " ", dx, func_p->value, 5, "number1", "sum1");
	else {

	  if (!(func_p=find_func(func, "out_detail"))) 
		sas_out(sas, "mean1", "15.2", 0);
	  if (atoi(find_path("form"))==2) sas_out(sas, "mean1", "15.2", 0);
	  else sas_lbl_out(sas, "mean1", "15.2", dx, func_p->value, 4, "number1", "sum1");
	}
}

void sas_sum(FILE *sas, FUNC **func) {
	char c1[STRING_N], c2[STRING_N], p1[STRING_N], p2[STRING_N]; 
	char *dx[6];
	FUNC * func_p;

	fprintf(sas, "\n\n/* Following codes from sas_average() */");
	sas_find_cross(c1, c2, p1, p2);

	if (func_p=find_func(func, "data_where")) {
		data_where(sas, func_p, "tmp");
	}

	fprintf(sas, "\n proc summary data=tmp ;");
	if (!(func_p=find_func(func, "variable"))) hbase_error(47, "variable");
	fprintf(sas, "\n var %s;", func_p->value);

	if (c1[0]) {
		fprintf(sas, "\n class %s", c1);
		if (c2[0]) fprintf(sas, " %s;", c2);
		else fprintf(sas, ";");
	}
	else {
		if (c2[0]) fprintf(sas, "\n class %s;", c2);
	}
	fprintf(sas, "\n output out=tmp mean=mean1 n=number1 sum=sum1;");
	fprintf(sas, "\n run;");

        if (form==22 || form==23 || form==30) {
          dx[0]=" sum1   15.2";
          dx[1]=" number1 10. ";
          dx[2]=" mean1 10. ";
          dx[3]=" r1 $15.";
          dx[4]=" r2 $15.";
          dx[5]=0;

        }
        else {
          dx[0]=" sum1 10. ";
          dx[1]=" number1 10. ";
          dx[2]=" mean1   15.2";
          dx[3]=" ci $15.";
        }
	_out_variable=3;

	if (form==21) 
	  //xml_sas_out(sas, dx, 4);
	  sas_lbl_out3(sas, "sum1", "15.2", dx, func_p->value, 3, "number1", "sum1");
	else if (form==22 || form==23 || form==30)  
          sas_lbl_out2(sas, dx[0], " ", dx, func_p->value, 5, "number1", "sum1");
	  //sas_lbl_out2(sas, "sum1", "15.2", dx, func_p->value, 3, "number1", "sum1");
	else {

	  if (!(func_p=find_func(func, "out_detail"))) 
		sas_out(sas, "sum1", "15.2", 0);
	  if (atoi(find_path("form"))==2) sas_out(sas, "sum1", "15.2", 0);
	  else sas_lbl_out(sas, "sum1", "15.2", dx, func_p->value, 3, "number1", "sum1");
	}
}

void sas_median(FILE *sas, FUNC **func) {
	char c1[STRING_N], c2[STRING_N], p1[STRING_N], p2[STRING_N]; 
	char *dx[6];
	FUNC * func_p;

	fprintf(sas, "\n\n/* Following codes from sas_median() */");
	sas_find_cross(c1, c2, p1, p2);

	if (func_p=find_func(func, "data_where")) {
		data_where(sas, func_p, "tmp");
	}

	fprintf(sas, "\n\n proc sort data=tmp;");
	fprintf(sas, "\n by %s %s;", c1[0]? c1 : "", c2[0]? c2 : "");
	fprintf(sas, "\n run;");

	fprintf(sas, "\n\n proc univariate data = tmp;");
	if (!(func_p=find_func(func, "variable"))) hbase_error(47, "variable");
	fprintf(sas, "\n var %s;", func_p->value);
	fprintf(sas, "\n by %s %s;", c1[0]? c1 : "", c2[0]? c2 : "");
	fprintf(sas, "\n output out=tmp median=median N=number min=min max=max;");
	fprintf(sas, "\n run;");

        if (form==22 || form==23 || form==30) {
          dx[0]=" median   15.2 ";
          dx[1]=" number 15.2 ";
          dx[2]=" min 15.2 ";
          dx[3]=" max 15.2 ";
          dx[4]=0;

        }
        else {
          dx[0]=" median 15.2 ";
          dx[1]=" number 15.2 ";
          dx[2]=" min  15.2";
          dx[3]=" max  15.2";
        }
	_out_variable=2;

	if (form==21) 
	  //xml_sas_out(sas, dx, 4);
	  sas_lbl_out3(sas, "median", "15.2", dx, func_p->value, 4, "number", NULL);
	else if (form==22 || form==23 || form==30)  
          sas_lbl_out2(sas, dx[0], " ", dx, func_p->value, 4, "number", NULL);
	 // sas_lbl_out2(sas, "median", "15.2", dx, func_p->value, 4, "number", NULL);
	else {

	  if (!(func_p=find_func(func, "out_detail"))) 
		sas_out(sas, "median", "15.2", 0);
	  if (atoi(find_path("form"))==2) sas_out(sas, "median", "15.2", 0);
	  else sas_lbl_out(sas, "median", "15.2", dx, func_p->value, 4, "number", NULL);
	}
}

void sas_rate(FILE *sas, FUNC **func) {
	char c1[STRING_N], c2[STRING_N], p1[STRING_N], p2[STRING_N];
	char *dx[6];
	FUNC * func_p;
	int ci;

	if (!(func_p=find_func(func, "ci"))) ci=4;
	else ci=atoi(func_p->value);

	fprintf(sas, "\n\n/* Following codes from sas_rate() */");
	sas_find_cross(c1, c2, p1, p2);

	if (func_p=find_func(func, "data_where")) {
		data_where(sas, func_p, "tmp");
	}

	sas_pop_select(sas, "saspopdata");
	sas_find_cross(c1, c2, p1, p2);
	if (func_p=find_func(func, "pop_where")) {
		data_where(sas, func_p, "poptmp");
	}

	fprintf(sas, "\n proc summary data=tmp;");
	if (!(func_p=find_func(func, "count"))) fprintf(sas, "\n var x;");
	else fprintf(sas, "\n var %s;", func_p->value);

	if (c1[0]) {
		fprintf(sas, "\n class %s", c1);
		if (c2[0]) fprintf(sas, " %s;", c2);
		else fprintf(sas, ";");
	}
	else {
		if (c2[0]) fprintf(sas, "\n class %s;", c2);
	}
	fprintf(sas, "\n output out=tmp sum=number;");
	fprintf(sas, "\n run;");

	fprintf(sas, "\n proc summary data=poptmp;");
	if (!(func_p=find_func(func, "pop_count"))) hbase_error(47, "pop_count");
	fprintf(sas, "\n var %s;", func_p->value);
	if (p1[0]) {
		fprintf(sas, "\n class %s", p1);
		if (p2[0]) fprintf(sas, " %s;", p2);
		else fprintf(sas, ";");
	}
	else {
		if (p2[0]) fprintf(sas, "\n class %s;", p2);
	}
	fprintf(sas, "\n output out=pop sum=popnum;");
	fprintf(sas, "\n run;");

	fprintf(sas, "\n proc sql;");
	fprintf(sas, "\n create table rate as");
	fprintf(sas, "\n select tmp.*, pop.*");
	fprintf(sas, "\n from tmp, pop");
	if (c1[0] && p1[0]) {
		fprintf(sas, "\n where tmp.%s=pop.%s", c1, p1);
		if (c2[0] && p2[0]) fprintf(sas, " and tmp.%s=pop.%s", c2, p2);
	}
	else {
		if (c2[0] && p2[0]) fprintf(sas, "\n where tmp.%s=pop.%s", c2, p2);
	}
	fprintf(sas, "; \n quit;");

	//sas_ci_crude_rate(sas);

	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n set rate;");
	fprintf(sas, "\n rate=number/popnum;");
	fprintf(sas, "\n stdev=1.96*sqrt(rate*(1-rate)/popnum);");
	if (!(func_p=find_func(func, "multiple"))) hbase_error(47, "multiple");
	fprintf(sas, "\n t1=(rate-stdev)*%s;", func_p->value);
	fprintf(sas, "\n if (t1<0) then t1=0;");
	fprintf(sas, "\n r1=put(t1, 8.2);");
	fprintf(sas, "\n r2=put((rate+stdev)*%s, 8.2);", func_p->value);
	fprintf(sas, "\n rate=rate*%s;", func_p->value);
	fprintf(sas, "\n r1=compress(r1);");
	fprintf(sas, "\n r2=compress(r2);");
	fprintf(sas, "\n ci=r1 || ' - ' || r2;");
	fprintf(sas, "\n keep %s %s rate number popnum ci r1 r2;", c1[0]? c1 : "", c2[0]? c2 : "");
	fprintf(sas, "\n run;");

	if (form==22 || form==23 || form==30) {
	  dx[0]=" rate   15.2";
	  dx[1]=" number 10. ";
	  dx[2]=" popnum 10. ";
	  dx[3]=" r1 $15.";
	  dx[4]=" r2 $15.";
	  dx[5]=0;
	}
	else {
	  dx[0]=" number 10. ";
	  dx[1]=" popnum 10. ";
	  dx[2]=" rate   15.2";
	  dx[3]=" ci $15.";
	}
	_out_variable=3;

	if (form==21) 
	  //xml_sas_out(sas, dx, 4);
	  sas_lbl_out3(sas, "rate", "15.2", dx, func_p->value, 4, "number", "popnum");
	else if (form==22 || form==23 || form==30)  
	  sas_lbl_out2(sas, dx[0], " ", dx, func_p->value, 5, "number", "popnum");
	else {

	  if (!(func_p=find_func(func, "out_detail"))) 
		sas_out(sas, "rate", "15.2", 0);
	  if (atoi(find_path("form"))==2) sas_out(sas, "rate", "15.2", 0);
	  else sas_lbl_out(sas, "rate", "15.2", dx, func_p->value, ci, "number", "popnum");
	}
}

void sas_rate_cv(FILE *sas, FUNC **func) {
	char c1[STRING_N], c2[STRING_N], p1[STRING_N], p2[STRING_N];
	char *dx[6];
	FUNC * func_p;
	int ci;

	if (!(func_p=find_func(func, "ci"))) ci=4;
	else ci=atoi(func_p->value);

	fprintf(sas, "\n\n/* Following codes from sas_rate_cv() */");
	sas_find_cross(c1, c2, p1, p2);

	if (func_p=find_func(func, "data_where")) {
		data_where(sas, func_p, "tmp");
	}

	sas_pop_select(sas, "saspopdata");
	sas_find_cross(c1, c2, p1, p2);
	if (func_p=find_func(func, "pop_where")) {
		data_where(sas, func_p, "poptmp");
	}

	fprintf(sas, "\n proc summary data=tmp;");
	if (!(func_p=find_func(func, "count"))) fprintf(sas, "\n var x;");
	else fprintf(sas, "\n var %s;", func_p->value);

	if (c1[0]) {
		fprintf(sas, "\n class %s", c1);
		if (c2[0]) fprintf(sas, " %s;", c2);
		else fprintf(sas, ";");
	}
	else {
		if (c2[0]) fprintf(sas, "\n class %s;", c2);
	}
	fprintf(sas, "\n output out=tmp sum=number;");
	fprintf(sas, "\n run;");

	fprintf(sas, "\n proc summary data=poptmp;");
	if (!(func_p=find_func(func, "pop_count"))) hbase_error(47, "pop_count");
	fprintf(sas, "\n var %s;", func_p->value);
	if (p1[0]) {
		fprintf(sas, "\n class %s", p1);
		if (p2[0]) fprintf(sas, " %s;", p2);
		else fprintf(sas, ";");
	}
	else {
		if (p2[0]) fprintf(sas, "\n class %s;", p2);
	}
	fprintf(sas, "\n output out=pop sum=popnum;");
	fprintf(sas, "\n run;");

	fprintf(sas, "\n proc sql;");
	fprintf(sas, "\n create table rate as");
	fprintf(sas, "\n select tmp.*, pop.*");
	fprintf(sas, "\n from tmp, pop");
	if (c1[0] && p1[0]) {
		fprintf(sas, "\n where tmp.%s=pop.%s", c1, p1);
		if (c2[0] && p2[0]) fprintf(sas, " and tmp.%s=pop.%s", c2, p2);
	}
	else {
		if (c2[0] && p2[0]) fprintf(sas, "\n where tmp.%s=pop.%s", c2, p2);
	}
	fprintf(sas, "; \n quit;");

	//sas_ci_crude_rate(sas);

	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n set rate;");
	fprintf(sas, "\n rate=number/popnum;");
	fprintf(sas, "\n stdev=1.96*sqrt(rate*(1-rate)/popnum);");
	fprintf(sas, "\n if rate<.50 then cv=100*(stdev/rate);");
	fprintf(sas, "\n else cv=100*(stddev/(1-rate));");
	if (!(func_p=find_func(func, "multiple"))) hbase_error(47, "multiple");
	fprintf(sas, "\n t1=(rate-stdev)*%s;", func_p->value);
	fprintf(sas, "\n if (t1<0) then t1=0;");
	fprintf(sas, "\n r1=put(t1, 8.2);");
	fprintf(sas, "\n r2=put((rate+stdev)*%s, 8.2);", func_p->value);
	fprintf(sas, "\n rate=rate*%s;", func_p->value);
	fprintf(sas, "\n r1=compress(r1);");
	fprintf(sas, "\n r2=compress(r2);");
	fprintf(sas, "\n ci=r1 || ' - ' || r2;");
	fprintf(sas, "\n keep %s %s rate number popnum ci cv r1 r2;", c1[0]? c1 : "", c2[0]? c2 : "");
	fprintf(sas, "\n run;");

	if (form==22 || form==23 || form==30) {
	  dx[0]=" rate   15.2";
	  dx[1]=" number 10. ";
	  dx[2]=" popnum 10. ";
	  dx[3]=" r1 $15.";
	  dx[4]=" r2 $15.";
	  dx[5]=" cv 10.2";
	  dx[6]=0;
	}
	else {
	  dx[0]=" number 10. ";
	  dx[1]=" popnum 10. ";
	  dx[2]=" rate   15.2";
	  dx[3]=" ci $15.";
	  dx[4]=" cv 10.2";
	}
	_out_variable=3;

	if (form==21) 
	  //xml_sas_out(sas, dx, 4);
	  sas_lbl_out3(sas, "rate", "15.2", dx, func_p->value, 4, "number", "popnum");
	else if (form==22 || form==23 || form==30)  
	  sas_lbl_out2(sas, dx[0], " ", dx, func_p->value, 5, "number", "popnum");
	else {

	  if (!(func_p=find_func(func, "out_detail"))) 
		sas_out(sas, "rate", "15.2", 0);
	  if (atoi(find_path("form"))==2) sas_out(sas, "rate", "15.2", 0);
	  else sas_lbl_out(sas, "rate", "15.2", dx, func_p->value, ci, "number", "popnum");
	}
}

void sas_ajrate(FILE *sas, FUNC **func) {
	char c1[STRING_N], c2[STRING_N], p1[STRING_N], p2[STRING_N]; 
	char *dx[6];
	FUNC * func_p;

	fprintf(sas, "\n\n/* Following codes from sas_ajrate() */");
	sas_find_cross(c1, c2, p1, p2);

	if (func_p=find_func(func, "data_where")) {
		data_where(sas, func_p, "tmp");
	}
	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n set tmp;");
	if ((func_p=find_func(func, "age_group"))) {
		fprintf(sas, "\n agepop=%s;", func_p->value);
	}
	else if ((func_p=find_func(func, "age_variable"))) {
		fprintf(sas, "\n agepop=int((%s+5)/10)+1;", func_p->value);
		fprintf(sas, "\n if (agepop > 10) then agepop=10;");
	}
	else hbase_error(47, "age_group or age_variable");
	fprintf(sas, "\n run;");

	fprintf(sas, "\n proc summary data=tmp;");
	if (!(func_p=find_func(func, "count"))) fprintf(sas, "\n var x;");
	else fprintf(sas, "\n var %s;", func_p->value);
	if (c1[0]) {
		fprintf(sas, "\n class agepop %s", c1);
		if (c2[0]) fprintf(sas, " %s;", c2);
		else fprintf(sas, ";");
	}
	else {
		if (c2[0]) fprintf(sas, "\n class agepop %s;", c2);
	}
	fprintf(sas, "\n output out=tmp sum=number;");
	fprintf(sas, "\n run;");

	sas_pop_select(sas, "saspopdata");
	sas_find_cross(c1, c2, p1, p2);
	if (func_p=find_func(func, "pop_where")) {
		data_where(sas, func_p, "poptmp");
	}
	fprintf(sas, "\n data poptmp;");
	fprintf(sas, "\n set poptmp;");
	if ((func_p=find_func(func, "pop_group"))) {
		fprintf(sas, "\n agepop=%s;", func_p->value);
	}
	else if ((func_p=find_func(func, "pop_variable"))) {
		fprintf(sas, "\n agepop=int((%s+5)/10)+1;", func_p->value);
		fprintf(sas, "\n if (agepop > 10) then agepop=10;");
	}
	else hbase_error(47, "pop_group or pop_variable");
	fprintf(sas, "\n run;");

	fprintf(sas, "\n proc summary data=poptmp;");
	if (!(func_p=find_func(func, "pop_count"))) hbase_error(47, "pop_count");
	fprintf(sas, "\n var %s;", func_p->value);
	fprintf(sas, "\n class agepop ");
	if (p1[0]) fprintf(sas, " %s", p1);
	if (p2[0]) fprintf(sas, " %s", p2);
	fprintf(sas, ";\n output out=pop sum=popnum;");
	fprintf(sas, "\n run;");

	sas_stdpop(sas);

/*
	fprintf(sas, "\n proc sort data=pop;");
	fprintf(sas, "\n by agepop;");
	fprintf(sas, "\n run;");
	fprintf(sas, "\n proc sort data=tmp;");
	fprintf(sas, "\n by agepop;");
	fprintf(sas, "\n run;");
	fprintf(sas, "\n data number;");
	fprintf(sas, "\n merge tmp pop stdpop;");
	fprintf(sas, "\n by agepop;");
	if (c1[0]) fprintf(sas, "\n if (%s=.) then %s=-1;", c1, c1);
	if (c2[0]) fprintf(sas, "\n if (%s=.) then %s=-1;", c2, c2);
	fprintf(sas, "\n rate=number/popnum;");
	fprintf(sas, "\n run;");
*/
	
	
	fprintf(sas, "\n proc sql;");
	fprintf(sas, "\n create table number as");
	fprintf(sas, "\n select tmp.*, pop.*, stdpop.*");
	fprintf(sas, "\n from tmp, pop, stdpop");
	fprintf(sas, "\n where tmp.agepop=pop.agepop");
	fprintf(sas, "\n and tmp.agepop=stdpop.agepop");
	if (c1[0] && p1[0]) {
		fprintf(sas, "\n and tmp.%s=pop.%s", c1, p1);
		if (c2[0] && p2[0]) fprintf(sas, " and tmp.%s=pop.%s", c2, p2);
	}
	else {
		if (c2[0] && p2[0]) fprintf(sas, "\n and tmp.%s=pop.%s", c2, p2);
	}
	fprintf(sas, ";");
	fprintf(sas, "\n quit;");

	fprintf(sas, "\n data number;");
	fprintf(sas, "\n set number;");
	fprintf(sas, "\n rate=number/popnum;");
	if (c1[0]) fprintf(sas, "\n if (%s=.) then %s=-1;", c1, c1);
	if (c2[0]) fprintf(sas, "\n if (%s=.) then %s=-1;", c2, c2);
	fprintf(sas, "\n run;");
	
	
	fprintf(sas, "\n proc summary data=number;");
	fprintf(sas, "\n var rate ;");
	if (c1[0]) {
		fprintf(sas, "\n class %s", c1);
		if (c2[0]) fprintf(sas, " %s;", c2);
		else fprintf(sas, ";");
	}
	else {
		if (c2[0]) fprintf(sas, "\n class %s;", c2);
	}
	fprintf(sas, "\n weight stdpop;");
	fprintf(sas, "\n output out=rate sum(rate)=;");
	fprintf(sas, "\n run;");


	fprintf(sas, "\n proc summary data=number;");
	fprintf(sas, "\n var number popnum;");
	if (c1[0]) {
		fprintf(sas, "\n class %s", c1);
		if (c2[0]) fprintf(sas, " %s;", c2);
		else fprintf(sas, ";");
	}
	else {
		if (c2[0]) fprintf(sas, "\n class %s;", c2);
	}
	fprintf(sas, "\n output out=number sum(number popnum)=;");
	fprintf(sas, "\n run;");


	fprintf(sas, "\n proc sql;");
	fprintf(sas, "\n create table tmp as");
	fprintf(sas, "\n select number.number, number.popnum, rate.*");
	fprintf(sas, "\n from number, rate");
	if (c1[0]) {
		fprintf(sas, "\n where number.%s=rate.%s", c1, c1);
		//if (p1[0]) fprintf(sas, "\n and number.%s=pop.%s" , c1, p1);
		if (c2[0]) fprintf(sas, "\n and number.%s=rate.%s", c2, c2);
		//if (c2[0] && p2[0]) 
		//	fprintf(sas, "\n and number.%s=pop.%s" , c2, p2);
		//fprintf(sas, "\n and pop.agepop=.;");
	}
	else {
		if (c2[0]) fprintf(sas, "\n where number.%s=rate.%s", c2, c2);
		//if (c2[0] && p2[0]) 
		//	fprintf(sas, "\n and number.%s=pop.%s" , c2, p2);
		//fprintf(sas, "\n and pop.agepop=.;");
	}
	fprintf(sas, "; \n quit;");

	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n set tmp (where=(");
	if (c1[0]) {
		fprintf(sas, "(%s^=.)", c1);
		if (c2[0]) fprintf(sas, " and (%s^=.)));", c2);
		else fprintf(sas, "));");
	}
	else {
		if (c2[0]) fprintf(sas, "(%s^=.)));", c2);
	}
	fprintf(sas, "\n rate=rate/100;");
	if (!(func_p=find_func(func, "multiple"))) hbase_error(47, "multiple");
	fprintf(sas, "\n stdev=1.96*sqrt(rate*(1-rate)/popnum);");
	fprintf(sas, "\n t1=(rate-stdev)*%s;", func_p->value);
	fprintf(sas, "\n if (t1<0) then t1=0;");
	fprintf(sas, "\n r1=put(t1, 8.2);");
	fprintf(sas, "\n r2=put((rate+stdev)*%s, 8.2);", func_p->value);
	fprintf(sas, "\n rate=rate*%s;", func_p->value);
	fprintf(sas, "\n r1=compress(r1);");
	fprintf(sas, "\n r2=compress(r2);");
	fprintf(sas, "\n ci=r1 || ' - ' || r2;");
	if (c1[0]) fprintf(sas, "\n if (%s=-1) then %s=.;", c1, c1);
	if (c2[0]) fprintf(sas, "\n if (%s=-1) then %s=.;", c2, c2);
	fprintf(sas, "\n keep %s %s rate number popnum ci r1 r2;", c1[0]? c1 : "", c2[0]? c2 : "");
	fprintf(sas, "\n run;");

	if (form==22 || form==23 || form==30) {
	  dx[0]=" rate   15.2";
	  dx[1]=" number 10. ";
	  dx[2]=" popnum 10. ";
	  dx[3]=" r1 $15.";
	  dx[4]=" r2 $15.";
	  dx[5]=0;

	}
	else {
	  dx[0]=" number 10. ";
	  dx[1]=" popnum 10. ";
	  dx[2]=" rate   15.2";
	  dx[3]=" ci $15.";
	}
	_out_variable=3;

	if (form==21) 
	  //xml_sas_out(sas, dx, 4);
	  sas_lbl_out3(sas, "rate", "15.2", dx, func_p->value, 4, "number", NULL);
	else if (form==22 || form==23 || form==30)  
	  sas_lbl_out2(sas, dx[0], " ", dx, func_p->value, 5, "number", "popnum");
	else {

	  if (!(func_p=find_func(func, "out_detail"))) 
		sas_out(sas, "rate", "15.2", 0);
	  if (atoi(find_path("form"))==2) sas_out(sas, "rate", "15.2", 0);
	  else sas_lbl_out(sas, "rate", "15.2", dx, func_p->value, 4, "number", "popnum");
	}
}

void sas_ajrate_cv(FILE *sas, FUNC **func) {
	char c1[STRING_N], c2[STRING_N], p1[STRING_N], p2[STRING_N]; 
	char *dx[6];
	FUNC * func_p;

	fprintf(sas, "\n\n/* Following codes from sas_ajrate_cv() */");
	sas_find_cross(c1, c2, p1, p2);

	if (func_p=find_func(func, "data_where")) {
		data_where(sas, func_p, "tmp");
	}
	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n set tmp;");
	if ((func_p=find_func(func, "age_group"))) {
		fprintf(sas, "\n agepop=%s;", func_p->value);
	}
	else if ((func_p=find_func(func, "age_variable"))) {
		fprintf(sas, "\n agepop=int((%s+5)/10)+1;", func_p->value);
		fprintf(sas, "\n if (agepop > 10) then agepop=10;");
	}
	else hbase_error(47, "age_group or age_variable");
	fprintf(sas, "\n run;");

	fprintf(sas, "\n proc summary data=tmp;");
	if (!(func_p=find_func(func, "count"))) fprintf(sas, "\n var x;");
	else fprintf(sas, "\n var %s;", func_p->value);
	if (c1[0]) {
		fprintf(sas, "\n class agepop %s", c1);
		if (c2[0]) fprintf(sas, " %s;", c2);
		else fprintf(sas, ";");
	}
	else {
		if (c2[0]) fprintf(sas, "\n class agepop %s;", c2);
	}
	fprintf(sas, "\n output out=tmp sum=number;");
	fprintf(sas, "\n run;");

	sas_pop_select(sas, "saspopdata");
	sas_find_cross(c1, c2, p1, p2);
	if (func_p=find_func(func, "pop_where")) {
		data_where(sas, func_p, "poptmp");
	}
	fprintf(sas, "\n data poptmp;");
	fprintf(sas, "\n set poptmp;");
	if ((func_p=find_func(func, "pop_group"))) {
		fprintf(sas, "\n agepop=%s;", func_p->value);
	}
	else if ((func_p=find_func(func, "pop_variable"))) {
		fprintf(sas, "\n agepop=int((%s+5)/10)+1;", func_p->value);
		fprintf(sas, "\n if (agepop > 10) then agepop=10;");
	}
	else hbase_error(47, "pop_group or pop_variable");
	fprintf(sas, "\n run;");

	fprintf(sas, "\n proc summary data=poptmp;");
	if (!(func_p=find_func(func, "pop_count"))) hbase_error(47, "pop_count");
	fprintf(sas, "\n var %s;", func_p->value);
	fprintf(sas, "\n class agepop ");
	if (p1[0]) fprintf(sas, " %s", p1);
	if (p2[0]) fprintf(sas, " %s", p2);
	fprintf(sas, ";\n output out=pop sum=popnum;");
	fprintf(sas, "\n run;");

	sas_stdpop(sas);

/*
	fprintf(sas, "\n proc sort data=pop;");
	fprintf(sas, "\n by agepop;");
	fprintf(sas, "\n run;");
	fprintf(sas, "\n proc sort data=tmp;");
	fprintf(sas, "\n by agepop;");
	fprintf(sas, "\n run;");
	fprintf(sas, "\n data number;");
	fprintf(sas, "\n merge tmp pop stdpop;");
	fprintf(sas, "\n by agepop;");
	if (c1[0]) fprintf(sas, "\n if (%s=.) then %s=-1;", c1, c1);
	if (c2[0]) fprintf(sas, "\n if (%s=.) then %s=-1;", c2, c2);
	fprintf(sas, "\n rate=number/popnum;");
	fprintf(sas, "\n run;");
*/
	
	
	fprintf(sas, "\n proc sql;");
	fprintf(sas, "\n create table number as");
	fprintf(sas, "\n select tmp.*, pop.*, stdpop.*");
	fprintf(sas, "\n from tmp, pop, stdpop");
	fprintf(sas, "\n where tmp.agepop=pop.agepop");
	fprintf(sas, "\n and tmp.agepop=stdpop.agepop");
	if (c1[0] && p1[0]) {
		fprintf(sas, "\n and tmp.%s=pop.%s", c1, p1);
		if (c2[0] && p2[0]) fprintf(sas, " and tmp.%s=pop.%s", c2, p2);
	}
	else {
		if (c2[0] && p2[0]) fprintf(sas, "\n and tmp.%s=pop.%s", c2, p2);
	}
	fprintf(sas, ";");
	fprintf(sas, "\n quit;");

	fprintf(sas, "\n data number;");
	fprintf(sas, "\n set number;");
	fprintf(sas, "\n stdpop=stdpop/100;");
	fprintf(sas, "\n rate=number/popnum*stdpop;");
	fprintf(sas, "\n ajrate=number/popnum;");
	fprintf(sas, "\n wtvar=(stdpop*stdpop)*((agerate*(1-agerate))/popnum);");
	if (c1[0]) fprintf(sas, "\n if (%s=.) then %s=-1;", c1, c1);
	if (c2[0]) fprintf(sas, "\n if (%s=.) then %s=-1;", c2, c2);
	fprintf(sas, "\n run;");
	
	
	fprintf(sas, "\n proc summary data=number;");
	fprintf(sas, "\n var rate number popnum;");
	if (c1[0]) {
		fprintf(sas, "\n class %s", c1);
		if (c2[0]) fprintf(sas, " %s;", c2);
		else fprintf(sas, ";");
	}
	else {
		if (c2[0]) fprintf(sas, "\n class %s;", c2);
	}
	//fprintf(sas, "\n weight stdpop;");
	fprintf(sas, "\n output out=number sum(rate number wtvar popnum)=rate number wtvar popnum;");
	fprintf(sas, "\n run;");

/*
	fprintf(sas, "\n proc summary data=number;");
	fprintf(sas, "\n var number popnum;");
	if (c1[0]) {
		fprintf(sas, "\n class %s", c1);
		if (c2[0]) fprintf(sas, " %s;", c2);
		else fprintf(sas, ";");
	}
	else {
		if (c2[0]) fprintf(sas, "\n class %s;", c2);
	}
	fprintf(sas, "\n output out=number sum(number popnum)=;");
	fprintf(sas, "\n run;");
*/

	fprintf(sas, "\n proc sql;");
	fprintf(sas, "\n create table tmp as");
	fprintf(sas, "\n select number.*, pop.*");
	fprintf(sas, "\n from number, rate");
	if (c1[0]) {
		fprintf(sas, "\n where number.%s=pop.%s", c1, p1);
		//if (p1[0]) fprintf(sas, "\n and number.%s=pop.%s" , c1, p1);
		if (c2[0]) fprintf(sas, "\n and number.%s=pop.%s", c2, p2);
		//if (c2[0] && p2[0]) 
		//	fprintf(sas, "\n and number.%s=pop.%s" , c2, p2);
		fprintf(sas, "\n and pop.agepop=-1;");
	}
	else {
		if (c2[0]) fprintf(sas, "\n where number.%s=pop.%s", c2, p2);
		//if (c2[0] && p2[0]) 
		//	fprintf(sas, "\n and number.%s=pop.%s" , c2, p2);
		//fprintf(sas, "\n and pop.agepop=.;");
	}
	fprintf(sas, "; \n quit;");

	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n set tmp (where=(");
	if (c1[0]) {
		fprintf(sas, "(%s^=.)", c1);
		if (c2[0]) fprintf(sas, " and (%s^=.)));", c2);
		else fprintf(sas, "));");
	}
	else {
		if (c2[0]) fprintf(sas, "(%s^=.)));", c2);
	}
	fprintf(sas, "\n rate=rate*100000;");
	if (!(func_p=find_func(func, "multiple"))) hbase_error(47, "multiple");
	fprintf(sas, "\n stdev=sqrt(wtvar)*100000;");
	fprintf(sas, "\n se=1.96*stdev;");
	fprintf(sas, "\n r1=rate-se;");
	fprintf(sas, "\n r2=rate+se;");
	fprintf(sas, "\n n=number;");
	fprintf(sas, "\n r1=compress(r1);");
	fprintf(sas, "\n r2=compress(r2);");
	fprintf(sas, "\n ci=r1 || ' - ' || r2;");
	if (c1[0]) fprintf(sas, "\n if (%s=-1) then %s=.;", c1, c1);
	if (c2[0]) fprintf(sas, "\n if (%s=-1) then %s=.;", c2, c2);
	fprintf(sas, "\n keep %s %s rate number popnum ci r1 r2;", c1[0]? c1 : "", c2[0]? c2 : "");
	fprintf(sas, "\n run;");

	sas_ci_ajrate(sas);

	if (form==22 || form==23 || form==30) {
	  dx[0]=" rate   15.2";
	  dx[1]=" number 10. ";
	  dx[2]=" popnum 10. ";
	  dx[3]=" r1 $15.";
	  dx[4]=" r2 $15.";
	  dx[5]=0;

	}
	else {
	  dx[0]=" number 10. ";
	  dx[1]=" popnum 10. ";
	  dx[2]=" rate   15.2";
	  dx[3]=" ci $15.";
	}
	_out_variable=3;

	if (form==21) 
	  //xml_sas_out(sas, dx, 4);
	  sas_lbl_out3(sas, "rate", "15.2", dx, func_p->value, 4, "number", "popnum");
	else if (form==22 || form==23 || form==30)  
	  sas_lbl_out2(sas, dx[0], " ", dx, func_p->value, 5, "number", "popnum");
	else {

	  if (!(func_p=find_func(func, "out_detail"))) 
		sas_out(sas, "rate", "15.2", 0);
	  if (atoi(find_path("form"))==2) sas_out(sas, "rate", "15.2", 0);
	  else sas_lbl_out(sas, "rate", "15.2", dx, func_p->value, 4, "number", "popnum");
	}
}

void sas_ajrate2(FILE *sas, FUNC **func) {
	char c1[STRING_N], c2[STRING_N], p1[STRING_N], p2[STRING_N]; 
	char *dx[6];
	FUNC * func_p;

	fprintf(sas, "\n\n/* Following codes from sas_ajrate2() */");
	sas_find_cross(c1, c2, p1, p2);

	if (func_p=find_func(func, "data_where")) {
		data_where(sas, func_p, "tmp");
	}
	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n set tmp;");
	if ((func_p=find_func(func, "age_group"))) {
		fprintf(sas, "\n agepop=%s;", func_p->value);
	}
	else if ((func_p=find_func(func, "age_variable"))) {
		fprintf(sas, "\n agepop=int((%s+5)/10)+1;", func_p->value);
		fprintf(sas, "\n if (agepop > 10) then agepop=10;");
	}
	else hbase_error(47, "age_group or age_variable");
	fprintf(sas, "\n run;");

	fprintf(sas, "\n proc summary data=tmp;");
	if (!(func_p=find_func(func, "count"))) fprintf(sas, "\n var x;");
	else fprintf(sas, "\n var %s;", func_p->value);
	if (c1[0]) {
		fprintf(sas, "\n class agepop %s", c1);
		if (c2[0]) fprintf(sas, " %s;", c2);
		else fprintf(sas, ";");
	}
	else {
		if (c2[0]) fprintf(sas, "\n class agepop %s;", c2);
	}
	fprintf(sas, "\n output out=tmp sum=number;");
	fprintf(sas, "\n run;");

	sas_pop_select(sas, "saspopdata");
	sas_find_cross(c1, c2, p1, p2);
	fprintf(sas, "\n /* c1--*%s c2--*%s p1--*%s p2--*%s */", c1, c2, p1, p2);
	if (func_p=find_func(func, "pop_where")) {
		data_where(sas, func_p, "poptmp");
	}
	fprintf(sas, "\n data poptmp;");
	fprintf(sas, "\n set poptmp;");
	if ((func_p=find_func(func, "pop_group"))) {
		fprintf(sas, "\n agepop=%s;", func_p->value);
	}
	else if ((func_p=find_func(func, "pop_variable"))) {
		fprintf(sas, "\n agepop=int((%s+5)/10)+1;", func_p->value);
		fprintf(sas, "\n if (agepop > 10) then agepop=10;");
	}
	else hbase_error(47, "pop_group or pop_variable");
	fprintf(sas, "\n run;");

	fprintf(sas, "\n proc summary data=poptmp;");
	if (!(func_p=find_func(func, "pop_count"))) hbase_error(47, "pop_count");
	fprintf(sas, "\n var %s;", func_p->value);
	fprintf(sas, "\n class agepop ");
	if (p1[0]) fprintf(sas, " %s", p1);
	if (p2[0]) fprintf(sas, " %s", p2);
	fprintf(sas, ";\n output out=pop sum=popnum;");
	fprintf(sas, "\n run;");

	sas_stdpop(sas);

/*
	fprintf(sas, "\n proc sort data=pop;");
	fprintf(sas, "\n by agepop;");
	fprintf(sas, "\n run;");
	fprintf(sas, "\n proc sort data=tmp;");
	fprintf(sas, "\n by agepop;");
	fprintf(sas, "\n run;");
	fprintf(sas, "\n data number;");
	fprintf(sas, "\n merge tmp pop stdpop;");
	fprintf(sas, "\n by agepop;");
	if (c1[0]) fprintf(sas, "\n if (%s=.) then %s=-1;", c1, c1);
	if (c2[0]) fprintf(sas, "\n if (%s=.) then %s=-1;", c2, c2);
	fprintf(sas, "\n rate=number/popnum;");
	fprintf(sas, "\n run;");
*/
	
	
	fprintf(sas, "\n proc sql;");
	fprintf(sas, "\n create table number as");
	fprintf(sas, "\n select tmp.*, pop.*, stdpop.*");
	fprintf(sas, "\n from tmp, pop, stdpop");
	fprintf(sas, "\n where tmp.agepop=pop.agepop");
	fprintf(sas, "\n and tmp.agepop=stdpop.agepop");
	if (c1[0] && p1[0]) {
		fprintf(sas, "\n and tmp.%s=pop.%s", c1, p1);
		if (c2[0] && p2[0]) fprintf(sas, " and tmp.%s=pop.%s", c2, p2);
	}
	else {
		if (c2[0] && p2[0]) fprintf(sas, "\n and tmp.%s=pop.%s", c2, p2);
	}
	fprintf(sas, ";");
	fprintf(sas, "\n quit;");

	fprintf(sas, "\n data number;");
	fprintf(sas, "\n set number;");
	fprintf(sas, "\n stdpop=stdpop/100);");
	fprintf(sas, "\n rate=number/popnum*stdpop;");
	fprintf(sas, "\n agerate=number/popnum;");
	fprintf(sas, "\n wtvar=(stdpop*stdpop)*((agerate*(1-agerate))//popnum);");
	if (c1[0]) fprintf(sas, "\n if (%s=.) then %s=-1;", c1, c1);
	if (c2[0]) fprintf(sas, "\n if (%s=.) then %s=-1;", c2, c2);
	fprintf(sas, "\n run;");
	
	fprintf(sas, "\n proc summary data=number;");
	fprintf(sas, "\n var rate number popnum;");
	if (c1[0]) {
		fprintf(sas, "\n class %s", c1);
		if (c2[0]) fprintf(sas, " %s;", c2);
		else fprintf(sas, ";");
	}
	else {
		if (c2[0]) fprintf(sas, "\n class %s;", c2);
	}
	//fprintf(sas, "\n weight stdpop;");
	fprintf(sas, "\n output out=rate sum(rate number wtvar popnum)=rate number wtvar popnum1;");
	fprintf(sas, "\n run;");

/*
	fprintf(sas, "\n proc summary data=number;");
	fprintf(sas, "\n var number popnum;");
	if (c1[0]) {
		fprintf(sas, "\n class %s", c1);
		if (c2[0]) fprintf(sas, " %s;", c2);
		else fprintf(sas, ";");
	}
	else {
		if (c2[0]) fprintf(sas, "\n class %s;", c2);
	}
	fprintf(sas, "\n output out=number sum(number popnum)=;");
	fprintf(sas, "\n run;");

	fprintf(sas, "\n data pop;");
	fprintf(sas, "\n set pop;");
	if (c1[0]) fprintf(sas, "\n if (%s=.) then %s=-1;", c1, c1);
	if (c2[0]) fprintf(sas, "\n if (%s=.) then %s=-1;", c2, c2);
	fprintf(sas, "\n run;");
*/

	fprintf(sas, "\n proc sql;");
	fprintf(sas, "\n create table tmp as");
	fprintf(sas, "\n select number.*, pop.*");
	fprintf(sas, "\n from number, pop");
	if (c1[0]) {
		fprintf(sas, "\n where number.%s=rate.%s", c1, c1);
		fprintf(sas, "\n and rate.%s^=.", c1);
		if (p1[0]) fprintf(sas, "\n and number.%s=pop.%s" , c1, p1);
		if (c2[0]) {
			fprintf(sas, "\n and number.%s=rate.%s", c2, c2);
			fprintf(sas, "\n and rate.%s^=.", c2);
		}
		if (c2[0] && p2[0]) 
			fprintf(sas, "\n and number.%s=pop.%s" , c2, p2);
		fprintf(sas, "\n and pop.agepop=-1;");
	}
	else {
		if (c2[0]) {
			fprintf(sas, "\n where number.%s=rate.%s", c2, c2);
			fprintf(sas, "\n and rate.%s^=.", c2);
		}
		if (c2[0] && p2[0]) 
			fprintf(sas, "\n and number.%s=pop.%s" , c2, p2);
		fprintf(sas, "\n and pop.agepop=-1;");
	}
	fprintf(sas, " \n quit;");


	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n set tmp (where=(");
	if (c1[0]) {
		fprintf(sas, "(%s^=.)", c1);
		if (c2[0]) fprintf(sas, " and (%s^=.)));", c2);
		else fprintf(sas, "));");
	}
	else {
		if (c2[0]) fprintf(sas, "(%s^=.)));", c2);
	}
	fprintf(sas, "\n rate=rate*100000;");
	if (!(func_p=find_func(func, "multiple"))) hbase_error(47, "multiple");
	fprintf(sas, "\n stdev=sqrt(wtvar)*100000;");
	fprintf(sas, "\n se=1.96*stdev;");
	fprintf(sas, "\n r1=rate-se;");
	fprintf(sas, "\n r2=rate+se;");
	fprintf(sas, "\n n=number;");
	fprintf(sas, "\n r1=compress(r1);");
	fprintf(sas, "\n r2=compress(r2);");
	fprintf(sas, "\n ci=r1 || ' - ' || r2;");
	if (c1[0]) fprintf(sas, "\n if (%s=-1) then %s=.;", c1, c1);
	if (c2[0]) fprintf(sas, "\n if (%s=-1) then %s=.;", c2, c2);
	fprintf(sas, "\n keep %s %s rate number popnum ci r1 r2;", c1[0]? c1 : "", c2[0]? c2 : "");
	fprintf(sas, "\n run;");

        sas_ci_ajrate(sas);

	if (form==22 || form==23 || form==30) {
	  dx[0]=" rate   15.2";
	  dx[1]=" number 10. ";
	  dx[2]=" popnum 10. ";
	  dx[3]=" r1 $15.";
	  dx[4]=" r2 $15.";
	  dx[5]=0;

	}
	else {
	  dx[0]=" number 10. ";
	  dx[1]=" popnum 10. ";
	  dx[2]=" rate   15.2";
	  dx[3]=" ci $15.";
	}
	_out_variable=3;

	if (form==21) 
	  //xml_sas_out(sas, dx, 4);
	  sas_lbl_out3(sas, "rate", "15.2", dx, func_p->value, 4, "number", "popnum");
	else if (form==22 || form==23 || form==30)  
	  sas_lbl_out2(sas, dx[0], " ", dx, func_p->value, 5, "number", "popnum");
	else {

	  if (!(func_p=find_func(func, "out_detail"))) 
		sas_out(sas, "rate", "15.2", 0);
	  if (atoi(find_path("form"))==2) sas_out(sas, "rate", "15.2", 0);
	  else sas_lbl_out(sas, "rate", "15.2", dx, func_p->value, 4, "number", "popnum");
	}
}

void sas_percentage(FILE *sas, FUNC **func) {
	char c1[STRING_N], c2[STRING_N], p1[STRING_N], p2[STRING_N]; 
	char * dx[6], *tmp;
	FUNC * func_p;

	fprintf(sas, "\n\n/* Following codes from sas_percentage() */");
	sas_find_cross(c1, c2, p1, p2);

	if (func_p=find_func(func, "data_where")) {
		data_where(sas, func_p, "tmp");
	}
	fprintf(sas, "\n data tmp1 tmp2;");
	fprintf(sas, "\n set tmp;");
	if (!(tmp=find_path("percent_cond"))) {
	if (!(func_p=find_func(func, "percent_cond"))) hbase_error(47, "percent_cond");
	  fprintf(sas, "\n if (%s) then output tmp1;", func_p->value);
	  fprintf(sas, "\n else output tmp2;");
	}
	else {
	  fprintf(sas, "\n if (%s) then output tmp1;", tmp);
	  fprintf(sas, "\n else output tmp2;");
	}
	fprintf(sas, "\n run;");

	fprintf(sas, "\n proc summary data=tmp1 n;");
	if (!(func_p=find_func(func, "variable"))) 
		fprintf(sas, "\n var x;");
	else fprintf(sas, "\n var %s;", func_p->value);
/*
	fprintf(sas, "\n var x;");
*/

	if (c1[0]) {
		fprintf(sas, "\n class %s", c1);
		if (c2[0]) fprintf(sas, " %s;", c2);
		else fprintf(sas, ";");
	}
	else {
		if (c2[0]) fprintf(sas, "\n class %s;", c2);
	}
	fprintf(sas, "\n output out=tmp1 sum=number1;");
	fprintf(sas, "\n run;");

	fprintf(sas, "\n proc sort data=tmp1;");
	if (c1[0]) {
		fprintf(sas, "\n by %s", c1);
		if (c2[0]) fprintf(sas, " %s;", c2);
		else fprintf(sas, ";");
	}
	else {
		if (c2[0]) fprintf(sas, "\n by %s;", c2);
	}
	fprintf(sas, "\n run;");

	fprintf(sas, "\n proc summary data=tmp2 n;");
	if (!(func_p=find_func(func, "variable"))) 
		fprintf(sas, "\n var x;");
	else fprintf(sas, "\n var %s;", func_p->value);
/*
	fprintf(sas, "\n var x;");
*/
	if (c1[0]) {
		fprintf(sas, "\n class %s", c1);
		if (c2[0]) fprintf(sas, " %s;", c2);
		else fprintf(sas, ";");
	}
	else {
		if (c2[0]) fprintf(sas, "\n class %s;", c2);
	} 
	fprintf(sas, "\n output out=tmp2 sum=number2;");
	fprintf(sas, "\n run;");

	fprintf(sas, "\n proc sort data=tmp2;");
	if (c1[0]) {
		fprintf(sas, "\n by %s", c1);
		if (c2[0]) fprintf(sas, " %s;", c2);
		else fprintf(sas, ";");
	}
	else {
		if (c2[0]) fprintf(sas, "\n by %s;", c2);
	}
	fprintf(sas, "\n run;");

	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n merge tmp1 tmp2;");
	if (c1[0]) {
		fprintf(sas, "\n by %s", c1);
		if (c2[0]) fprintf(sas, " %s;", c2);
		else fprintf(sas, ";");
	}
	else {
		if (c2[0]) fprintf(sas, "\n by %s;", c2);
	} 
	fprintf(sas, "\n if (number1=.) then number1=0;");
	fprintf(sas, "\n if (number2=.) then number2=0;");
	fprintf(sas, "\n number0=number1+number2;");
	fprintf(sas, "\n if (number0=0) then number0=.;");
	fprintf(sas, "\n rate=number1/number0;");
	sas_ci_95(sas);
        fprintf(sas, "\n rate=rate*100;");
	fprintf(sas, "\n run;");

        if (form==22 || form==23 || form==30) {
          dx[0]=" rate   15.2";
          dx[1]=" number1 10. ";
          dx[2]=" number0 10. ";
          dx[3]=" r1 $15.";
          dx[4]=" r2 $15.";
          dx[5]=0;
        }
        else {
          dx[0]=" number1 10. ";
          dx[1]=" number0 10. ";
          dx[2]=" rate   15.2";
          dx[3]=" ci $15.";
        }
	_out_variable=3;

	if (form==21) 
	  //xml_sas_out(sas, dx, 4);
	  sas_lbl_out3(sas, "rate", "15.2", dx, func_p->value, 4, "number1", "number0");
	else if (form==22 || form==23 || form==30)  
          sas_lbl_out2(sas, dx[0], " ", dx, func_p->value, 5, "number1", "number0");
	  //sas_lbl_out2(sas, "rate", "15.2", dx, func_p->value, 4, "number1", "number0");
	else {

	  if (!(func_p=find_func(func, "out_detail"))) 
		sas_out(sas, "rate", "15.2", 0);
	  if (atoi(find_path("form"))==2) sas_out(sas, "rate", "15.2", 0);
	  else sas_lbl_out(sas, "rate", "15.2", dx, func_p->value, 4, "number1", "number0");
	}
}

void sas_percentage2(FILE *sas, FUNC **func) {
	char c1[STRING_N], c2[STRING_N], p1[STRING_N], p2[STRING_N]; 
	char * dx[6], *tmp;
	FUNC * func_p;

	fprintf(sas, "\n\n/* Following codes from sas_percentage2() */");
	sas_find_cross(c1, c2, p1, p2);

	if (func_p=find_func(func, "data_where")) {
		data_where(sas, func_p, "tmp");
	}
	fprintf(sas, "\n data tmp1 tmp2;");
	fprintf(sas, "\n set tmp;");
	if (!(tmp=find_path("percent_cond"))) {
	if (!(func_p=find_func(func, "percent_cond"))) hbase_error(47, "percent_cond");
	  fprintf(sas, "\n if (%s) then output tmp1;", func_p->value);
	  fprintf(sas, "\n else output tmp2;");
	}
	else {
	  fprintf(sas, "\n if (%s) then output tmp1;", tmp);
	  fprintf(sas, "\n else output tmp2;");
	}
	fprintf(sas, "\n run;");

	fprintf(sas, "\n proc summary data=tmp1 n;");
	if (!(func_p=find_func(func, "variable"))) 
		fprintf(sas, "\n var x;");
	else fprintf(sas, "\n var %s;", func_p->value);
/*
	fprintf(sas, "\n var x;");
*/

	if (c1[0]) {
		fprintf(sas, "\n class %s", c1);
		if (c2[0]) fprintf(sas, " %s;", c2);
		else fprintf(sas, ";");
	}
	else {
		if (c2[0]) fprintf(sas, "\n class %s;", c2);
	}
	fprintf(sas, "\n output out=tmp1 sum=number1;");
	fprintf(sas, "\n run;");

	fprintf(sas, "\n proc sort data=tmp1;");
	if (c1[0]) {
		fprintf(sas, "\n by %s", c1);
		if (c2[0]) fprintf(sas, " %s;", c2);
		else fprintf(sas, ";");
	}
	else {
		if (c2[0]) fprintf(sas, "\n by %s;", c2);
	}
	fprintf(sas, "\n run;");

	fprintf(sas, "\n proc summary data=tmp2 n;");
	if (!(func_p=find_func(func, "variable"))) 
		fprintf(sas, "\n var x;");
	else fprintf(sas, "\n var %s;", func_p->value);
/*
	fprintf(sas, "\n var x;");
*/
	if (c1[0]) {
		fprintf(sas, "\n class %s", c1);
		if (c2[0]) fprintf(sas, " %s;", c2);
		else fprintf(sas, ";");
	}
	else {
		if (c2[0]) fprintf(sas, "\n class %s;", c2);
	} 
	fprintf(sas, "\n output out=tmp2 sum=number2;");
	fprintf(sas, "\n run;");

	fprintf(sas, "\n proc sort data=tmp2;");
	if (c1[0]) {
		fprintf(sas, "\n by %s", c1);
		if (c2[0]) fprintf(sas, " %s;", c2);
		else fprintf(sas, ";");
	}
	else {
		if (c2[0]) fprintf(sas, "\n by %s;", c2);
	}
	fprintf(sas, "\n run;");

	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n merge tmp1 tmp2;");
	if (c1[0]) {
		fprintf(sas, "\n by %s", c1);
		if (c2[0]) fprintf(sas, " %s;", c2);
		else fprintf(sas, ";");
	}
	else {
		if (c2[0]) fprintf(sas, "\n by %s;", c2);
	} 
	fprintf(sas, "\n if (number1=.) then number1=0;");
	fprintf(sas, "\n if (number2=.) then number2=0;");
	fprintf(sas, "\n number0=number1+number2;");
	fprintf(sas, "\n if (number0=0) then number0=.;");
	fprintf(sas, "\n rate=number1/number0;");
	sas_ci_95(sas);
	fprintf(sas, "\n rate=rate*100;");
	fprintf(sas, "\n run;");

        if (form==22 || form==23 || form==30) {
          dx[0]=" rate   15.4";
          dx[1]=" number1 10. ";
          dx[2]=" number0 10. ";
          dx[3]=" r1 15.4";
          dx[4]=" r2 15.4";
          dx[5]=0;

        }
        else {
          dx[0]=" number1 10. ";
          dx[1]=" number0 10. ";
          dx[2]=" rate   15.2";
          dx[3]=" ci $15.";
          dx[4]=0;
        }
	_out_variable=3;

	if (form==21) 
	  //xml_sas_out(sas, dx, 4);
	  sas_lbl_out3(sas, "rate", "15.2", dx, func_p->value, 4, "number1", "number0");
	else if (form==22 || form==23 || form==30) { 
 	  sas_lbl_out2(sas, dx[0], " ", dx, NULL, 5, "number1", "number0");
	  //sas_lbl_out2(sas, "rate", "15.2", dx, func_p->value, 4, "number1", "number0");
	}
	else {

	  if (!(func_p=find_func(func, "out_detail"))) 
		sas_out(sas, "rate", "15.4", 0);
	  if (atoi(find_path("form"))==2) sas_out(sas, "rate", "15.4", 0);
	  else sas_lbl_out(sas, "rate", "15.4", dx, func_p->value, 4, "number1", "number0");
	}
}


void sas_percent(FILE *sas, FUNC **func) {
	char c1[STRING_N], c2[STRING_N], p1[STRING_N], p2[STRING_N]; 
	char * dx[4];
	FUNC * func_p;

	fprintf(sas, "\n\n/* Following codes from sas_percent() */");
	sas_find_cross(c1, c2, p1, p2);

	if (func_p=find_func(func, "data_where")) {
		data_where(sas, func_p, "tmp");
	}

	fprintf(sas, "\n proc freq noprint data=tmp;");
	if ((func_p=find_func(func, "variable"))) 
	  fprintf(sas, "\n weight %s;", func_p->value);

	if (c1[0]) {
		fprintf(sas, "\n table %s", c1);
		if (c2[0]) fprintf(sas, "*%s / out=tmp;", c2);
		else fprintf(sas, " / out=tmp;");
	}
	else {
		if (c2[0]) fprintf(sas, "\n table %s / out=tmp;", c2);
	}
	fprintf(sas, "\n run;");

	fprintf(sas, "\n proc summary data=tmp;");
	fprintf(sas, "\n var count percent;");
	if (c1[0]) {
		fprintf(sas, "\n class %s", c1);
		if (c2[0]) fprintf(sas, " %s;", c2);
		else fprintf(sas, ";");
	}
	else {
		if (c2[0]) fprintf(sas, "\n class %s;", c2);
	} 
	fprintf(sas, "\n output out=tmp sum(count percent)=;");
	fprintf(sas, "\n run;");

	
	if (form==22 || form==23 || form==30) {
	dx[0]=" percent 15.2";
	dx[1]=" count 15.2";
	dx[2]=0;
	}
	else {
	dx[0]=" count 15.2";
	dx[1]=" percent 15.2";
	}
	_out_variable=1;

	if (form==21) 
	  //xml_sas_out(sas, dx, 4);
	  sas_lbl_out3(sas, "percent", "15.2", dx, func_p->value, 2, "count", NULL);
	else if (form==22 || form==23 || form==30)  
          sas_lbl_out2(sas, dx[0], " ", dx, func_p->value, 5, "count", NULL);
	  //sas_lbl_out2(sas, "percent", "15.2", dx, func_p->value, 2, "count", NULL);
	else {

	  if (!(func_p=find_func(func, "out_detail"))) 
		sas_out(sas, "rate", "15.2", 0);
	  if (atoi(find_path("form"))==2) sas_out(sas, "percent", "15.2", 0);
	  else sas_lbl_out(sas, "percent", "15.2", dx, func_p->value, 2, "count", "999");
	}
}

void sas_percent2(FILE *sas, FUNC **func) {
	char c1[STRING_N], c2[STRING_N], p1[STRING_N], p2[STRING_N]; 
	char * dx[4];
	FUNC * func_p;

	fprintf(sas, "\n\n/* Following codes from sas_percent2() */");
	sas_find_cross(c1, c2, p1, p2);

	if (func_p=find_func(func, "data_where")) {
		data_where(sas, func_p, "tmp");
	}

	fprintf(sas, "\n proc freq noprint data=tmp;");
	if ((func_p=find_func(func, "variable"))) 
	  fprintf(sas, "\n weight %s;", func_p->value);

	if (c1[0]) {
		fprintf(sas, "\n table %s", c1);
		if (c2[0]) fprintf(sas, "*%s / out=tmp;", c2);
		else fprintf(sas, " / out=tmp;");
	}
	else {
		if (c2[0]) fprintf(sas, "\n table %s / out=tmp;", c2);
	}
	fprintf(sas, "\n run;");

	fprintf(sas, "\n proc summary data=tmp;");
	fprintf(sas, "\n var count percent;");
	if (c1[0]) {
		fprintf(sas, "\n class %s", c1);
		if (c2[0]) fprintf(sas, " %s;", c2);
		else fprintf(sas, ";");
	}
	else {
		if (c2[0]) fprintf(sas, "\n class %s;", c2);
	} 
	fprintf(sas, "\n output out=tmp sum(count percent)=;");
	fprintf(sas, "\n run;");

	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n set tmp;");
	fprintf(sas, "\n percent=percent/100;");
	fprintf(sas, "\n run;");

	if (form==22 || form==23 || form==30) {
	dx[0]=" percent 15.2";
	dx[1]=" count 15.2";
	dx[2]=0;
	}
	else {
	dx[0]=" count 15.2";
	dx[1]=" percent 15.2";
	}
	_out_variable=1;

	if (form==21) 
	  //xml_sas_out(sas, dx, 4);
	  sas_lbl_out3(sas, "percent", "15.2", dx, func_p->value, 2, "count", NULL);
	else if (form==22 || form==23 || form==30)  
          sas_lbl_out2(sas, dx[0], " ", dx, func_p->value, 5, "count", NULL);
	  //sas_lbl_out2(sas, "percent", "15.2", dx, func_p->value, 2, "count", NULL);
	else {

	  if (!(func_p=find_func(func, "out_detail"))) 
		sas_out(sas, "rate", "15.4", 0);
	  if (atoi(find_path("form"))==2) sas_out(sas, "percent", "15.4", 0);
	  else sas_lbl_out(sas, "percent", "15.4", dx, func_p->value, 2, "count", "999");
	}
}

void sas_percent2_cv(FILE *sas, FUNC **func) {
	char c1[STRING_N], c2[STRING_N], p1[STRING_N], p2[STRING_N]; 
	char * dx[4];
	FUNC * func_p;

	fprintf(sas, "\n\n/* Following codes from sas_percent2_cv() */");
	sas_find_cross(c1, c2, p1, p2);

	if (func_p=find_func(func, "data_where")) {
		data_where(sas, func_p, "tmp");
	}

	fprintf(sas, "\n proc freq noprint data=tmp;");
	if ((func_p=find_func(func, "variable"))) 
	  fprintf(sas, "\n weight %s;", func_p->value);

	if (c1[0]) {
		fprintf(sas, "\n table %s", c1);
		if (c2[0]) fprintf(sas, "*%s / out=tmp;", c2);
		else fprintf(sas, " / out=tmp;");
	}
	else {
		if (c2[0]) fprintf(sas, "\n table %s / out=tmp;", c2);
	}
	fprintf(sas, "\n run;");

	fprintf(sas, "\n proc summary data=tmp;");
	fprintf(sas, "\n var count percent;");
	if (c1[0]) {
		fprintf(sas, "\n class %s", c1);
		if (c2[0]) fprintf(sas, " %s;", c2);
		else fprintf(sas, ";");
	}
	else {
		if (c2[0]) fprintf(sas, "\n class %s;", c2);
	} 
	fprintf(sas, "\n output out=tmp sum(count percent)=;");
	fprintf(sas, "\n run;");

	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n set tmp;");
	fprintf(sas, "\n percent=percent/100;");
	fprintf(sas, "\n run;");

	if (form==22  || form==23 || form==30) {
	dx[0]=" percent 15.2";
	dx[1]=" count 15.2";
	dx[2]=" cv 10.2";
	dx[3]=0;
	}
	else {
	dx[0]=" count 15.2";
	dx[1]=" percent 15.2";
	dx[2]=" cv 10.2";
	}
	_out_variable=1;

	if (form==21) 
	  //xml_sas_out(sas, dx, 4);
	  sas_lbl_out3(sas, "percent", "15.2", dx, func_p->value, 2, "count", NULL);
	else if (form==22 || form==23 || form==30)  
          sas_lbl_out2(sas, dx[0], " ", dx, func_p->value, 5, "count", NULL);
	  //sas_lbl_out2(sas, "percent", "15.2", dx, func_p->value, 2, "count", NULL);
	else {

	  if (!(func_p=find_func(func, "out_detail"))) 
		sas_out(sas, "rate", "15.4", 0);
	  if (atoi(find_path("form"))==2) sas_out(sas, "percent", "15.4", 0);
	  else sas_lbl_out(sas, "percent", "15.4", dx, func_p->value, 2, "count", "999");
	}
}

char * replace_line(char * line, char * buf, REPLACE ** rep) {
	int i, j;
	char *tmp, kbufa[STRING_N], kbufb[STRING_N], buf2[BUFFER_N];
	NAME * n_ptr;

	strcpy(buf, line);
	for (i=0; rep[i]; i++) {
		kbufa[0]='?'; kbufb[0]='%';
		for (j=0; rep[i]->key[j] && j<STRING_N; j++) {
			kbufa[j+1]=rep[i]->key[j];
			kbufb[j+1]=rep[i]->key[j];
		}
		kbufa[j+1]='?'; kbufb[j+1]='%';
		kbufa[j+2]=0;   kbufb[j+2]=0;

		if ((tmp=strstr(line, kbufa))) {
			if (rep[i]->rep) {
				return replace_line(tmp+j+2, buf, rep);
			}
			else {
				buf[0]=' '; 
				buf[1]=0; 
				return buf;
			}
		}

		if ((tmp=strstr(buf, kbufb))) {
			tmp[0]=0;
			strcpy(buf2, buf);

			if (rep[i]->rep) {
				strcat(buf2, rep[i]->rep);
				if ((n_ptr=find_name(rep[i]->rep, 2)) 
					&& !strcmp(n_ptr->type1, "char")) {
					if (!strncmp(tmp+j+2, "=.", 2)) {
						strcat(buf2, "=''");
						strcat(buf2, tmp+j+4);
					}
					else if (!strncmp(tmp+j+2, "=-99", 4)) {
						strcat(buf2, "='-99'");
						strcat(buf2, tmp+j+6);
					}
					else strcat(buf2, tmp+j+2);
				}
				else {
					strcat(buf2, tmp+j+2);
				}
			}
			else {
				strcat(buf2, tmp+j+2);
			}
			strcpy(buf, buf2);
			buf2[0]=0;
			i--;
		}
	}
	return buf;
}

char ** passThrough( int * c) {
	int i;
	char *tmp, *pt,  str[BUFFER_N];
	char **ptArray;

	pt=find_path("pass_through");
	if (!pt) {
		*c=0;
		return NULL;
	}

	strcpy(str, pt);
	tmp=str;
	i=2;	
	while (tmp) {
		if (!(tmp=strchr(tmp, ' '))) break;;
		tmp++;
		i++;
	}

	if (!(ptArray=(char **) malloc(i*sizeof(char *)))) hbase_error(3, "passThrough");
	strcpy(str, pt);
	tmp=str;
	i=0;
	while (tmp) {
		pt=strchr(tmp, ' ');
		if (pt) pt[0]=0;
		if (!(ptArray[i]=(char *) malloc((strlen(tmp)+1)*sizeof(char)))) hbase_error(3, "passThrough");
		strcpy(ptArray[i], tmp);
		i++;
		if (!pt) break;
		tmp=pt+1;
	}
	ptArray[i]=0;
	*c=i;
	
	return ptArray;
}

char ** filterExclude( int * c) {
	int i;
	char *tmp, *pt,  str[BUFFER_N];
	char **ptArray;

	pt=find_path("filter_exclude");
	if (!pt) {
		*c=0;
		return NULL;
	}

	strcpy(str, pt);
	tmp=str;
	i=2;	
	while (tmp) {
		if (!(tmp=strchr(tmp, ' '))) break;;
		tmp++;
		i++;
	}

	if (!(ptArray=(char **) malloc(i*sizeof(char *)))) hbase_error(3, "filterExclude");
	strcpy(str, pt);
	tmp=str;
	i=0;
	while (tmp) {
		pt=strchr(tmp, ' ');
		if (pt) pt[0]=0;
		if (!(ptArray[i]=(char *) malloc((strlen(tmp)+1)*sizeof(char)))) hbase_error(3, "filterExclude");
		strcpy(ptArray[i], tmp);
		i++;
		if (!pt) break;
		tmp=pt+1;
	}
	ptArray[i]=0;
	*c=i;
	
	return ptArray;
}

char * getVariValues(char * namehtml) {
	VARI ** vpr;
	int i, c;
	char *str;

	vpr=find_vari(namehtml, 1, 0, &c);
	if (vpr==NULL || c<=0) return NULL;
	
	if (!(str=(char *) malloc(BUFFER_N*sizeof(char)))) hbase_error(3, "getVariValues");
	str[0]=0;
	for (i=0; i<c; i++) {
		strcat(str, vpr[i]->value);
		if (i<c-1) strcat(str, ", ");
	}

	return str;
}

void sas_special(FILE *sas, FUNC **func) {
	char c1[STRING_N], c2[STRING_N], p1[STRING_N], p2[STRING_N];
	char *tmp, buf[BUFFER_N], *dx[1], **ptA, **feA;
	int i, j, crosses_cnt, cnt2;
	FUNC * func_p, * func_p2;
	FUNC *func_n, *func_pop;
	char *n_v=NULL, *pop_v=NULL;
	REPLACE ** cross;
	//REPLACE ** cross;
	CROSS ** crosses;

	fprintf(sas, "\n\n/* Following codes from sas_special() */\n");
	//sas_include(func, &cross);

	ptA=passThrough(&crosses_cnt);
	feA=filterExclude(&cnt2);
	if (!(cross=(REPLACE**) malloc((crosses_cnt+cnt2+15)*sizeof(REPLACE*)))) hbase_error(3, "func-4");

	//crosses=find_crosses(&crosses_cnt);
	sas_find_cross(c1, c2, p1, p2);
	for (i=0; i<crosses_cnt+cnt2+14; i++) 
		if (!(cross[i]=(REPLACE*) malloc(sizeof(REPLACE)))) hbase_error(3, "func-4");
	cross[0]->key="cross1";
	if (c1[0]) cross[0]->rep=c1;
	else cross[0]->rep=NULL;
	cross[1]->key="cross2";
	if (c2[0]) cross[1]->rep=c2;
	else cross[1]->rep=NULL;
	cross[2]->key="popcross1";
	if (p1[0]) cross[2]->rep=p1;
	else cross[2]->rep=NULL;
	cross[3]->key="popcross2";
	if (p2[0]) cross[3]->rep=p2;
	else cross[3]->rep=NULL;
	for (i=4; i<14; i++) {
		cross[i]->key=malloc(8);
		sprintf(cross[i]->key, "spvar%d", i-3);
		cross[i]->rep=find_path(cross[i]->key);
	}
	for (i=i, j=0; j<crosses_cnt; i++, j++) {
		cross[i]->key=ptA[j];
		cross[i]->rep=find_path(cross[i]->key);
	}
	for (i=i, j=0; j<cnt2; i++, j++) {
		cross[i]->key=feA[j];
		cross[i]->rep=getVariValues(cross[i]->key);
	}
	cross[crosses_cnt+cnt2+14]=NULL;

	if (func_p=find_func(func, "data_where")) {
		data_where(sas, func_p, "tmp");
	}

        tmp=find_path("saspopdata");
	if (tmp && strcmp(tmp, "none")) {
		sas_pop_select(sas, "saspopdata");
		sas_find_cross(c1, c2, p1, p2);
		if (func_p=find_func(func, "pop_where")) {
			data_where(sas, func_p, "poptmp");
		}
	}


	if (!(func_p=find_func(func, "script"))) hbase_error(47, "script");
	for (i=0; func_p->script[i]; i++) {
		tmp=replace_line(func_p->script[i], buf, cross);
		fprintf(sas, "%s", tmp);
	}

	if (!(func_p2=find_func(func, "out_variable"))) hbase_error(47, "out_variable");
	if (!(func_p=find_func(func, "out_detail"))) {
/*
	  if (form==21 || form==22 || form==23 || form==30) {
	    dx[0]=func_p2->value;
	    xml_sas_out(sas, dx, 1);
	  }
	  else {
*/
	    sas_out(sas, func_p2->value, " ", 0);
	  //}
	}
	else {
		for (i=0; func_p->script[i]; i++) {
			if (strstr(func_p->script[i], func_p2->value))
				_out_variable=i+1;
		}

	if ((func_n=find_func(func, "n_variable"))) n_v=func_n->value;
	if (n_v==NULL) n_v="n";
	if ((func_pop=find_func(func, "pop_variable"))) pop_v=func_pop->value;
	if (form==21) {
	  //xml_sas_out(sas, dx, 4);
	  sas_lbl_out3(sas, func_p2->value, " ", func_p->script, func_p->value, i, n_v, pop_v);
	}
	else if (form==22 || form==23 || form==30)  {
	  sas_lbl_out2(sas, func_p2->value, " ", func_p->script, func_p->value, i, n_v, pop_v);
	}
	else {

		j=atoi(find_path("form"));
		if (j==2) sas_out(sas, func_p2->value, " ", 0);
		else if (j==5 || j==6 || j==22 || j==23 || j==30) sas_lbl_out2(sas, func_p2->value, " ", func_p->script, func_p->value, i, n_v, pop_v);
		else sas_lbl_out(sas, func_p2->value, " ", func_p->script, func_p->value, i, n_v, pop_v);
	  }
	}
}

void sas_bld_include(REPLACE ** cross, char * src, char * tgt) {
	char * tmp, buf1[BUFFER_N], buf2[BUFFER_N];
	FILE * src_inc, *tgt_inc;

	if ((!(tgt_inc=fopen(tgt, "w")))) hbase_error(44, tgt);
	
	if (!(src_inc=file_open(src, 0))) return;

	while (!feof(src_inc)) {
	    if (!(tmp=fgets(buf1, BUFFER_N, src_inc))) break;
		tmp=replace_line(buf1, buf2, cross);
		fprintf(tgt_inc, "%s", tmp);
	}
	fclose(src_inc);
	fclose(tgt_inc);
}

void sas_include(FUNC ** func, REPLACE *** cross_p) {
	char c1[STRING_N], c2[STRING_N], p1[STRING_N], p2[STRING_N];
	char *tmp, buf[BUFFER_N], *dx[1];
	int i, j, crosses_cnt;
	FUNC * func_p, * func_p2;
	REPLACE * cross[35];
	CROSS ** crosses;

	crosses=find_crosses(&crosses_cnt);
	//sas_find_cross(c1, c2, p1, p2);
	for (i=0; i<34; i++) 
		if (!(cross[i]=(REPLACE*) malloc(sizeof(REPLACE)))) hbase_error(3, "func-4");
	for (i=0, j=0; i<crosses_cnt; i++) {
//fprintf(sas, "\n /* --*%d corss %d name -- *%s --*%s  */", crosses_cnt, i, crosses[i]->name, crosses[i]->name_ptr->name_sas);
	    cross[j]->key=malloc(7);
	    //sprintf(cross[j]->key, "cross%d", i+1);
	    sprintf(cross[j]->key, "%s", crosses[i]->name);
	    cross[j]->rep=crosses[i]->name_ptr->name_sas;
	//    fprintf(sas, "\n\n/* cross%d -- %s  --- %s*/\n", i+1, cross[j]->key, cross[j]->rep);
	    j++;

	    cross[j]->key=malloc(10);
	    sprintf(cross[j]->key, "popcross%d", i+1);
	    cross[j]->rep=crosses[i]->name_ptr->name_pop;
	   // fprintf(sas, "\n\n/* popcross%d -- %s */\n", i+1, cross[j]->rep);
	    j++;
	}
	if (i<2) {
	    cross[j]->key="cross2";
	    cross[j]->rep=NULL;
	    //fprintf(sas, "\n\n/* cross2 -- %s */\n", cross[j]->rep);
	    j++;
	    cross[j]->key="popcross2";
	    cross[j]->rep=NULL;
	    //fprintf(sas, "\n\n/* cross2 -- %s */\n", cross[j]->rep);
	    j++;
	}
	if (i<3) {
	    cross[j]->key="cross3";
	    cross[j]->rep=NULL;
	    //fprintf(sas, "\n\n/* cross3 -- %s */\n", cross[j]->rep);
	    j++;
	    cross[j]->key="popcross3";
	    cross[j]->rep=NULL;
	    //fprintf(sas, "\n\n/* cross3 -- %s */\n", cross[j]->rep);
	    j++;
	}
	if (func_p=find_func(func, "include")) {
	    cross[j]->key="include";
	    tmp = get_sasname(buf);
	    strcat(buf, "_include.sas");
	    if ((!(cross[j]->rep=malloc(strlen(buf)+3)))) hbase_error(3, buf);
	    sprintf(cross[j]->rep, "'%s'", buf);
	    j++;
	}

	for (i=j; i<14; i++) {
		cross[i]->key=malloc(8);
		sprintf(cross[i]->key, "spvar%d", i-j+1);
		cross[i]->rep=find_path(cross[i]->key);
	}
	cross[14]=NULL;
	if (func_p=find_func(func, "include")) {
	     sas_bld_include(cross, func_p->value, buf);
	}

	*cross_p=cross;
}

void sas_special2(FILE *sas, FUNC **func) {
	char c1[STRING_N], c2[STRING_N], p1[STRING_N], p2[STRING_N];
	char *tmp, buf[BUFFER_N], *dx[1];
	int i, j, crosses_cnt;
	FUNC * func_p, * func_p2;
	FUNC *func_n, *func_pop;
	char *n_v=NULL, *pop_v=NULL;
	REPLACE ** cross;
	CROSS ** crosses;

	fprintf(sas, "\n\n/* Following codes from sas_special2() */\n");


	if (func_p=find_func(func, "data_where")) {
		data_where(sas, func_p, "tmp");
	}

	tmp=find_path("saspopdata");
	if (tmp && strcmp(tmp, "none")) {
		sas_pop_select(sas, "saspopdata");
		if (func_p=find_func(func, "pop_where")) {
			data_where(sas, func_p, "poptmp");
		}
	}

	sas_include(func, &cross);
fprintf(sas, "\n /* ");
for (i=0; cross[i]; i++) {
fprintf(sas, "\n<br> key--*%s value--*%s", cross[i]->key, cross[i]->rep);
}
fprintf(sas, "\n */ ");

	if (!(func_p=find_func(func, "script"))) hbase_error(47, "script");
	for (i=0; func_p->script[i]; i++) {
		tmp=replace_line(func_p->script[i], buf, cross);
		fprintf(sas, "%s", tmp);
	}

	if (!(func_p2=find_func(func, "out_variable"))) hbase_error(47, "out_variable");
	if (!(func_p=find_func(func, "out_detail"))) {
	if ((func_n=find_func(func, "n_variable"))) n_v=func_n->value;
	if (n_v==NULL) n_v="n";
	if ((func_pop=find_func(func, "pop_variable"))) pop_v=func_pop->value;
/*
	  if (form==21 || form==22 || form==23 || form==30) {
	    dx[0]=func_p2->value;
	    xml_sas_out(sas, dx, 1);
	  }
	  else {
*/
	    sas_out(sas, func_p2->value, " ", 0);
	  //}
	}
	else {
		for (i=0; func_p->script[i]; i++) {
			if (strstr(func_p->script[i], func_p2->value))
				_out_variable=i+1;
		}

	if (form==21) 
	  //xml_sas_out(sas, dx, 4);
	  sas_lbl_out3(sas, func_p2->value, " ", func_p->script, func_p->value, i, n_v, pop_v);
	else if (form==22 || form==23 || form==30)  
	  sas_lbl_out2(sas, func_p2->value, " ", func_p->script, func_p->value, i, n_v, pop_v);
	  else {

		j=atoi(find_path("form"));
		if (j==2) sas_out(sas, func_p2->value, " ", 0);
		else if (j==5 || j==6 || j==22 || j==23 || j==30) sas_lbl_out2(sas, func_p2->value, " ", func_p->script, func_p->value, i, n_v, pop_v);
		else sas_lbl_out(sas, func_p2->value, " ", func_p->script, func_p->value, i, n_v, pop_v);
	  }
	}
}

void sas_macro(FILE *sas, FUNC **func) {
	char c1[STRING_N], c2[STRING_N], p1[STRING_N], p2[STRING_N];
	char *tmp, buf[BUFFER_N], *dx[1];
	int i, j;
	FUNC * func_p, * func_p2;
	FUNC *func_n, *func_pop;
	char *n_v=NULL, *pop_v=NULL;
	REPLACE * cross[15];

	fprintf(sas, "\n\n/* Following codes from sas_macro() */\n");
	sas_find_cross(c1, c2, p1, p2);
	for (i=0; i<14; i++) 
		if (!(cross[i]=(REPLACE*) malloc(sizeof(REPLACE)))) hbase_error(3, "func-4");
	cross[0]->key="cross1";
	if (c1[0]) cross[0]->rep=c1;
	else cross[0]->rep=NULL;
	cross[1]->key="cross2";
	if (c2[0]) cross[1]->rep=c2;
	else cross[1]->rep=NULL;
	cross[2]->key="popcross1";
	if (p1[0]) cross[2]->rep=p1;
	else cross[2]->rep=NULL;
	cross[3]->key="popcross2";
	if (p2[0]) cross[3]->rep=p2;
	else cross[3]->rep=NULL;
	for (i=4; i<14; i++) {
		cross[i]->key=malloc(8);
		sprintf(cross[i]->key, "spvar%d", i-3);
		cross[i]->rep=find_path(cross[i]->key);
	}
	cross[14]=NULL;

	if (func_p=find_func(func, "data_where")) {
		data_where(sas, func_p, "tmp");
	}

	if (strcmp(find_path("saspopdata"), "none")) {
		sas_pop_select(sas, "saspopdata");
		if (func_p=find_func(func, "pop_where")) {
			data_where(sas, func_p, "poptmp");
		}
	}

	if (!(func_p=find_func(func, "script"))) hbase_error(47, "script");
	for (i=0; func_p->script[i]; i++) {
		tmp=replace_line(func_p->script[i], buf, cross);
		fprintf(sas, "%s", tmp);
	}

	if (!(func_p2=find_func(func, "out_variable"))) hbase_error(47, "out_variable");
	if (!(func_p=find_func(func, "out_detail"))) {
	if ((func_n=find_func(func, "n_variable"))) n_v=func_n->value;
	if (n_v==NULL) n_v="n";
	if ((func_pop=find_func(func, "pop_variable"))) pop_v=func_pop->value;
/*
	  if (form==21 || form==22 || form==23 || form==30) {
	    dx[0]=func_p2->value;
	    xml_sas_out(sas, dx, 1);
	  }
	  else {
*/
	    sas_out(sas, func_p2->value, " ", 0);
	  //}
	}
	else {
		for (i=0; func_p->script[i]; i++) {
			if (strstr(func_p->script[i], func_p2->value))
				_out_variable=i+1;
		}

	if (form==21) 
	  //xml_sas_out(sas, dx, 4);
	  sas_lbl_out3(sas, func_p2->value, " ", func_p->script, func_p->value, i, n_v, pop_v);
	else if (form==22 || form==23 || form==30)  
	  sas_lbl_out2(sas, func_p2->value, " ", func_p->script, func_p->value, i, n_v, pop_v);
	  else {

		j=atoi(find_path("form"));
		if (j==2) sas_out(sas, func_p2->value, " ", 0);
		else if (j==5 || j==6) sas_lbl_out2(sas, func_p2->value, " ", func_p->script, func_p->value, i, n_v, pop_v);
		else sas_lbl_out(sas, func_p2->value, " ", func_p->script, func_p->value, i, n_v, pop_v);
	  }
	}
}

void sas_func_bld(FILE *sas, FUNC **func) {
	FUNC * func_p;

	fprintf(sas, "\n /* sas_func_bld */"); fflush(sas);
	if (!(func_p=find_func(func, "type"))) hbase_error(47, "type");
	fprintf(sas, "\n /* sas_func_bld  --- %s*/", func_p->value); fflush(sas);
	if (!strcmp(func_p->value, "count")) sas_count(sas, func);
	else if (!strcmp(func_p->value, "average")) sas_average(sas, func);
	else if (!strcmp(func_p->value, "average_cv")) sas_average_cv(sas, func);
	else if (!strcmp(func_p->value, "sum")) sas_sum(sas, func);
	else if (!strcmp(func_p->value, "rate")) sas_rate(sas, func);
	else if (!strcmp(func_p->value, "rate_cv")) sas_rate_cv(sas, func);
	else if (!strcmp(func_p->value, "ajrate")) sas_ajrate(sas, func);
	else if (!strcmp(func_p->value, "ajrate2")) sas_ajrate2(sas, func);
	else if (!strcmp(func_p->value, "ajrate_cv")) sas_ajrate_cv(sas, func);
	else if (!strcmp(func_p->value, "percentage")) sas_percentage(sas, func);
	else if (!strcmp(func_p->value, "percentage2")) sas_percentage2(sas, func);
	else if (!strcmp(func_p->value, "percent")) sas_percent(sas, func);
	else if (!strcmp(func_p->value, "percent2")) sas_percent2(sas, func);
	else if (!strcmp(func_p->value, "percent2_cv")) sas_percent2_cv(sas, func);
	else if (!strcmp(func_p->value, "median")) sas_median(sas, func);
	else if (!strcmp(func_p->value, "special")) sas_special(sas, func);
	else if (!strcmp(func_p->value, "special2")) sas_special2(sas, func);
	else if (!strcmp(func_p->value, "special_survey")) sas_special_survey(sas, func);
	else if (!strcmp(func_p->value, "special_survey2")) sas_special_survey2(sas, func);
	else if (!strcmp(func_p->value, "macro")) sas_macro(sas, func);
	else hbase_error(27, "func_p->value");
}

FUNC * h_script_bld(FILE * fdef) {
	char *tmp, *tmp2, buf[BUFFER_N];
	int i;
	long offset;
	FUNC * func;

	offset=ftell(fdef);
	for (i=0; !feof(fdef); i++) {
		if (!fgets(buf, BUFFER_N, fdef)) break;
		if (strstr(buf, BONDARY)) break;
	}
	fseek(fdef, offset, SEEK_SET);

	if (!(func=(FUNC *) malloc(sizeof(FUNC)))) hbase_error(3, "func-5");
	if (!(func->script=(char **) malloc((i+1)*sizeof(char *)))) hbase_error(3, "func-6");
	func->script[i]=NULL;
	if (!i || !(fgets(buf, BUFFER_N, fdef))) return func;
	tmp=de_space(buf);
	i=strlen(buf);
	if (buf[i-1]=='\n') buf[i-1]=0;
	i=strlen(buf);
	if (buf[i-1]=='\a') buf[i-1]=0;
	if (!(func->type=malloc(i+1))) hbase_error(3, "func-6");
	strcpy(func->type, buf);
	if ((tmp2=strchr(func->type, ' '))) {
		tmp2[0]=0;
		func->key=tmp2+1;
		if ((tmp2=strchr(func->key, ' '))) {
			tmp2[0]=0;
			func->value=tmp2+1;
		}
		else func->value=NULL;
	}
	else {
		func->type="1";
		func->key="script";
		func->value=NULL;
	}

	for (i=0; !feof(fdef); i++) {
		if (!(fgets(buf, BUFFER_N, fdef))) break;
		if (strstr(buf, BONDARY)) break;
		if (!(func->script[i]=malloc(strlen(buf)+1))) hbase_error(3, "func-7");
		if (buf[strlen(buf)-1]=='\r') buf[strlen(buf)-1]=0;
		strcpy(func->script[i], buf);
	}
	func->script[i]=NULL;
	return func;
}

void sas_func_def(FILE * sas) {
	char *tmp, *tmp2, str[BUFFER_N];
	int i, j, flag;
	FILE * fdef;

	fprintf(sas, "\n /* sas_func_def */"); fflush(sas);
	if (!(tmp2=find_path("func"))) hbase_error(27, NULL);
	if (!(fdef=file_open(tmp2, 0))) {
	  sprintf(str, "func%s.def", tmp2);
	  if (!(fdef=file_open(str, 0))) hbase_error(44, str);
	}

	for (i=0, j=0, flag=0; !feof(fdef); ) {
		if (!(tmp=fgets(str, BUFFER_N, fdef))) break;;
		if (strstr(str, BONDARY)) {
			flag=!flag;
			if (flag) j++;
		}
		if (!flag && isalnum(tmp[0])) i++;
	}

	if (!(h_func=(FUNC **) malloc ((i+j+1)*sizeof(FUNC *)))) hbase_error(3, "func-8");

	rewind(fdef);
	for (i=0; !feof(fdef); ) {
		if (!(tmp=fgets(str, BUFFER_N, fdef))) break;;
		if (strstr(str, BONDARY)) {
			h_func[i]=h_script_bld(fdef);
			i++;
			continue;
		}
		if (!(isalnum(tmp[0]))) continue;
		if (!(tmp2=strchr(tmp, ' '))) continue;
		//if (strlen(de_space(tmp2)) <1) continue;
		h_func[i]=h_func_bld(tmp);
		i++;
	}
	h_func[i]=NULL;
	fclose(fdef);
        func_test_out();
}

void sas_minus1(FILE * sas) {
	char *dx[4];
	char c1[STRING_N], c2[STRING_N], p1[STRING_N], p2[STRING_N]; 

	fprintf(sas, "\n\n/* Following codes from sas_minus1() */");
	sas_find_cross(c1, c2, p1, p2);

	fprintf(sas, "\n data tmp1 tmp2 tmp3 tmp4 tmp0 ;");
	fprintf(sas, "\n set tmp;");
	fprintf(sas, "\n if (.<bwgtnum<2500) then output tmp1;");
	fprintf(sas, "\n if (.<bwgtnum>=2500) then output tmp4;");
	fprintf(sas, "\n if (.<bwgtnum<1500) then output tmp2;");
	fprintf(sas, "\n if (.<bwgtnum<1000) then output tmp3;");
	fprintf(sas, "\n output tmp0;");
	fprintf(sas, "\n run;");

	fprintf(sas, "\n proc summary data=tmp1 n;");
	fprintf(sas, "\n var x;");
	if (c1[0]) {
		fprintf(sas, "\n class %s;", c1);
	}
	fprintf(sas, "\n output out=tmp1 n=number1;");
	fprintf(sas, "\n run;");

	fprintf(sas, "\n proc sort data=tmp1;");
	if (c1[0]) {
		fprintf(sas, "\n by %s;", c1);
	}
	fprintf(sas, "\n run;");

	fprintf(sas, "\n proc summary data=tmp2 n;");
	fprintf(sas, "\n var x;");
	if (c1[0]) {
		fprintf(sas, "\n class %s;", c1);
	}
	fprintf(sas, "\n output out=tmp2 n=number2;");
	fprintf(sas, "\n run;");

	fprintf(sas, "\n proc sort data=tmp2;");
	if (c1[0]) {
		fprintf(sas, "\n by %s;", c1);
	}
	fprintf(sas, "\n run;");

	fprintf(sas, "\n proc summary data=tmp3 n;");
	fprintf(sas, "\n var x;");
	if (c1[0]) {
		fprintf(sas, "\n class %s;", c1);
	}
	fprintf(sas, "\n output out=tmp3 n=number3;");
	fprintf(sas, "\n run;");

	fprintf(sas, "\n proc sort data=tmp3;");
	if (c1[0]) {
		fprintf(sas, "\n by %s;", c1);
	}
	fprintf(sas, "\n run;");

	fprintf(sas, "\n proc summary data=tmp4 n;");
	fprintf(sas, "\n var x;");
	if (c1[0]) {
		fprintf(sas, "\n class %s;", c1);
	}
	fprintf(sas, "\n output out=tmp4 n=number4;");
	fprintf(sas, "\n run;");

	fprintf(sas, "\n proc sort data=tmp4;");
	if (c1[0]) {
		fprintf(sas, "\n by %s;", c1);
	}
	fprintf(sas, "\n run;");

	fprintf(sas, "\n proc summary data=tmp0 n;");
	fprintf(sas, "\n var x;");
	if (c1[0]) {
		fprintf(sas, "\n class %s;", c1);
	}
	fprintf(sas, "\n output out=tmp0 n=number0;");
	fprintf(sas, "\n run;");

	fprintf(sas, "\n proc sort data=tmp0;");
	if (c1[0]) {
		fprintf(sas, "\n by %s;", c1);
	}
	fprintf(sas, "\n run;");

	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n merge tmp1 tmp2 tmp3 tmp4 tmp0;");
	if (c1[0]) {
		fprintf(sas, "\n by %s;", c1);
	}
	fprintf(sas, "\n rate1=number1/number0*100;");
	fprintf(sas, "\n rate2=number2/number0*100;");
	fprintf(sas, "\n rate3=number3/number0*100;");
	fprintf(sas, "\n rate4=number4/number0*100;");
	fprintf(sas, "\n run;");

	dx[0]=" rate1 15.2";
	dx[1]=" rate2 15.2";
	dx[2]=" rate3 15.2";
	dx[3]=" rate4 15.2";
	sas_out_3(sas, dx, "out_minus", 4, NULL, NULL);
}

void sas_ci_95(FILE * sas) {
	fprintf(sas, "\n\n/* Following codes from sas_ci_95() */");

	fprintf(sas, "\n length ci $20.;");
	fprintf(sas, "\n if (number1=0 and number0 in (1, 2, 3, 4, 5)) then do;");
	fprintf(sas, "\n\t select(number0);");
	fprintf(sas, "\n\t when (1) ci='0.00 - 97.5';");
	fprintf(sas, "\n\t when (2) ci='0.00 - 84.2';");
	fprintf(sas, "\n\t when (3) ci='0.00 - 70.8';");
	fprintf(sas, "\n\t when (4) ci='0.00 - 60.2';");
	fprintf(sas, "\n\t when (5) ci='0.00 - 52.2';");
	fprintf(sas, "\n\t end; \n end;");

	fprintf(sas, "\n else if (number1=1 and number0 in (2, 3, 4, 5)) then do;");
	fprintf(sas, "\n\t select(number0);");
	fprintf(sas, "\n\t when (2) ci='1.3 - 98.7';");
	fprintf(sas, "\n\t when (3) ci='0.8 - 90.6';");
	fprintf(sas, "\n\t when (4) ci='0.6 - 80.6';");
	fprintf(sas, "\n\t when (5) ci='0.5 - 71.6';");
	fprintf(sas, "\n\t end; \n end;");

	fprintf(sas, "\n else if (number1=2 and number0 in (4, 5)) then do;");
	fprintf(sas, "\n\t select(number0);");
	fprintf(sas, "\n\t when (4) ci='6.8 - 93.2';");
	fprintf(sas, "\n\t when (5) ci='5.3 - 85.3';");
	fprintf(sas, "\n\t end; \n end;");

	fprintf(sas, "\n else if (0.3 < rate < 0.7) then do;");
	fprintf(sas, "\n stdev=1.96*sqrt(rate*(1-rate)/number0);");
        fprintf(sas, "\n t1=(rate-stdev);");
	fprintf(sas, "\n if (t1<0) then t1=0;");
	if (form==22 || form==23 || form==30) fprintf(sas, "\n r1=put(t1*100, 8.2);");
	else fprintf(sas, "\n r1=put(t1*100, 8.2);");
        fprintf(sas, "\n t2=(rate+stdev);");
        if (form==22 || form==23 || form==30) fprintf(sas, "\n r2=put(t2*100, 8.2);");
        else fprintf(sas, "\n r2=put(t2*100, 8.2);");
        fprintf(sas, "\n ci=compress(r1) || ' - ' || compress(r2);");
        fprintf(sas, "\n if (compress(r1)='.') then ci=r1;");
	fprintf(sas, "\n end; \n else do; ");

	fprintf(sas, "\n t1=(2*number1+2.8416-1.96*sqrt(1.8416-1/number0+4*rate*(number2-1)))/2/(number0+3.8416);");
	fprintf(sas, "\n t2=(2*number1+4.8416+1.96*sqrt(5.8416-1/number0+4*rate*(number2+1)))/2/(number0+3.8416);");
	fprintf(sas, "\n if (t1<0) then t1=0;");
	if (form==22 || form==23 || form==30) {
		fprintf(sas, "\n r1=put(t1*100, 8.2);");
        	fprintf(sas, "\n r2=put(t2*100, 8.2);");
	}
	else {
		fprintf(sas, "\n r1=put(t1*100, 8.2);");
        	fprintf(sas, "\n r2=put(t2*100, 8.2);");
	}
        fprintf(sas, "\n ci=compress(r1) || ' - ' || compress(r2);");
        fprintf(sas, "\n if (compress(r1)='.') then ci=r1;");
	fprintf(sas, "\n end;");
}

void sas_ci_crude_rate(FILE * sas) {
	FUNC * func_p;
	char * mul="100000";

	fprintf(sas, "\n\n/* Following codes from sas_ci_crude_rate() */");

	func_p=find_func(h_func, "multiple");
	if (func_p && func_p->value) mul=func_p->value;

	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n set rate;");
	fprintf(sas, "\n length ci $20.;");

	fprintf(sas, "\n rate=number/popnum;");
	fprintf(sas, "\n stdev=1.96*sqrt(rate*(1-rate)/popnum);");
	fprintf(sas, "\n t1=(rate-stdev)*%s;", mul);
	fprintf(sas, "\n if (t1<0) then t1=0;");
	fprintf(sas, "\n r1=put(t1, 8.2);");
	fprintf(sas, "\n r2=put((rate+stdev)*%s, 8.2);", mul);
	fprintf(sas, "\n rate=rate*%s;", mul);
	fprintf(sas, "\n r1=compress(r1);");
	fprintf(sas, "\n r2=compress(r2);");
	fprintf(sas, "\n ci=r1 || ' - ' || r2;");
	fprintf(sas, "\n n=number;");
	fprintf(sas, "\n run;");

	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n   set tmp;");
	fprintf(sas, "\n if n<=20 then do;");
	fprintf(sas, "\n if n=0 then do;");
	fprintf(sas, "\n   lower=0;");
	fprintf(sas, "\n upper=3.7;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=1 then do; ");
	fprintf(sas, "\n  lower=0.0253;");
	fprintf(sas, "\n upper=5.5716;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=2 then do;");
	fprintf(sas, "\n   lower=0.1211;");
	fprintf(sas, "\n   upper=3.6123;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=3 then do;");
	fprintf(sas, "\n lower=0.2062;");
	fprintf(sas, "\n upper=2.9224;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=4 then do;");
	fprintf(sas, "\n  lower=0.2062;");
	fprintf(sas, "\n upper=2.9224;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=5 then do;");
	fprintf(sas, "\n   lower=0.3247;");
	fprintf(sas, "\n upper=2.3337;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=6 then do;");
	fprintf(sas, "\n lower=0.367;");
	fprintf(sas, "\n upper=2.1766;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=7 then do;");
	fprintf(sas, "\n lower=0.4021;");
	fprintf(sas, "\n upper=2.0604;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=8 then do;");
	fprintf(sas, "\n lower=0.4317;");
	fprintf(sas, "\n upper=1.9704;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=9 then do;");
	fprintf(sas, "\n  lower=0.4573;");
	fprintf(sas, "\n upper=1.8983;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=10 then do;");
	fprintf(sas, "\n  lower=0.4795;");
	fprintf(sas, "\n upper=1.839;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=11 then do;");
	fprintf(sas, "\n  lower=0.4992;");
	fprintf(sas, "\n upper=1.7893;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=12 then do;");
	fprintf(sas, "\n  lower=0.4992;");
	fprintf(sas, "\n upper=1.7893;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=13 then do;");
	fprintf(sas, "\n  lower=0.5325;");
	fprintf(sas, "\n upper=1.71;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=14 then do;");
	fprintf(sas, "\n  lower=0.5325;");
	fprintf(sas, "\n upper=1.71;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=15 then do;");
	fprintf(sas, "\n  lower=0.5325;");
	fprintf(sas, "\n upper=1.71;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=16 then do;");
	fprintf(sas, "\n  lower=0.5716;");
	fprintf(sas, "\n upper=1.6239;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=17 then do;");
	fprintf(sas, "\n  lower=0.5825;");
	fprintf(sas, "\n upper=1.6011;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=18 then do;");
	fprintf(sas, "\n lower=0.5927;");
	fprintf(sas, "\n upper=1.5804;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=19 then do;");
	fprintf(sas, "\n lower=0.6021;");
	fprintf(sas, "\n upper=1.5616;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=20 then do;");
	fprintf(sas, "\n  lower=0.6108;");
	fprintf(sas, "\n upper=1.5444;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n r1=lower*rate;");
	fprintf(sas, "\n r2=upper*rate;");

        fprintf(sas, "\n ci=compress(r1) || ' - ' || compress(r2);");
        fprintf(sas, "\n if (compress(r1)='.') then ci=r1;");
	fprintf(sas, "\n end;");
	fprintf(sas, "\n run;");
}

void sas_ci_ajrate(FILE * sas) {
	fprintf(sas, "\n\n/* Following codes from sas_ci_crude_rate() */");

	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n   set tmp;");
	fprintf(sas, "\n if n<=20 then do;");
	fprintf(sas, "\n if n=0 then do;");
	fprintf(sas, "\n   lower=0;");
	fprintf(sas, "\n upper=3.7;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=1 then do; ");
	fprintf(sas, "\n  lower=0.0253;");
	fprintf(sas, "\n upper=5.5716;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=2 then do;");
	fprintf(sas, "\n   lower=0.1211;");
	fprintf(sas, "\n   upper=3.6123;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=3 then do;");
	fprintf(sas, "\n lower=0.2062;");
	fprintf(sas, "\n upper=2.9224;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=4 then do;");
	fprintf(sas, "\n  lower=0.2062;");
	fprintf(sas, "\n upper=2.9224;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=5 then do;");
	fprintf(sas, "\n   lower=0.3247;");
	fprintf(sas, "\n upper=2.3337;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=6 then do;");
	fprintf(sas, "\n lower=0.367;");
	fprintf(sas, "\n upper=2.1766;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=7 then do;");
	fprintf(sas, "\n lower=0.4021;");
	fprintf(sas, "\n upper=2.0604;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=8 then do;");
	fprintf(sas, "\n lower=0.4317;");
	fprintf(sas, "\n upper=1.9704;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=9 then do;");
	fprintf(sas, "\n  lower=0.4573;");
	fprintf(sas, "\n upper=1.8983;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=10 then do;");
	fprintf(sas, "\n  lower=0.4795;");
	fprintf(sas, "\n upper=1.839;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=11 then do;");
	fprintf(sas, "\n  lower=0.4992;");
	fprintf(sas, "\n upper=1.7893;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=12 then do;");
	fprintf(sas, "\n  lower=0.4992;");
	fprintf(sas, "\n upper=1.7893;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=13 then do;");
	fprintf(sas, "\n  lower=0.5325;");
	fprintf(sas, "\n upper=1.71;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=14 then do;");
	fprintf(sas, "\n  lower=0.5325;");
	fprintf(sas, "\n upper=1.71;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=15 then do;");
	fprintf(sas, "\n  lower=0.5325;");
	fprintf(sas, "\n upper=1.71;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=16 then do;");
	fprintf(sas, "\n  lower=0.5716;");
	fprintf(sas, "\n upper=1.6239;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=17 then do;");
	fprintf(sas, "\n  lower=0.5825;");
	fprintf(sas, "\n upper=1.6011;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=18 then do;");
	fprintf(sas, "\n lower=0.5927;");
	fprintf(sas, "\n upper=1.5804;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=19 then do;");
	fprintf(sas, "\n lower=0.6021;");
	fprintf(sas, "\n upper=1.5616;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n if n=20 then do;");
	fprintf(sas, "\n  lower=0.6108;");
	fprintf(sas, "\n upper=1.5444;");
	fprintf(sas, "\n end;");

	fprintf(sas, "\n r1=lower*rate;");
	fprintf(sas, "\n r2=upper*rate;");

        fprintf(sas, "\n ci=compress(r1) || ' - ' || compress(r2);");
        fprintf(sas, "\n if (compress(r1)='.') then ci=r1;");
	fprintf(sas, "\n end;");
	fprintf(sas, "\n run;");
}
