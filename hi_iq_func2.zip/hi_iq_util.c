/* HI-IQ System, the High Information Internet Query System,
	Copyright 1995, 1996, 1997, 1998 Utah Office of Health Data Analysis.

	hi_iq_util.c	11/11/98
	routine function used everywhere of the program.

	We provide the interactive interface to make your data available
	to public through Internet.
*/

#include "hi_iq.h"
#include "hi_iq_var.h"

#ifndef WIN_NT
void mall_print() {
	struct mallinfo mmm;

	mmm=mallinfo();
	printf("\n<br> arena--*%d", mmm.arena); 
	printf("\n<br> ordblks--*%d", mmm.ordblks);
	printf("\n<br> smblks--*%d", mmm.smblks);
	printf("\n<br> hblkhd--*%d", mmm.hblkhd);
	printf("\n<br> hblks--*%d", mmm.hblks);
	printf("\n<br> usmblks--*%d", mmm.usmblks);
	printf("\n<br> fsmblks--*%d", mmm.fsmblks);
	printf("\n<br> uordblks--*%d", mmm.uordblks);
	printf("\n<br> fordblks--*%d", mmm.fordblks); 
	printf("\n<br> keepcost--*%d", mmm.keepcost);
	fflush(stdout);
}
#endif

void test_out(int flag) {
	int i;

/* flag=1 ---- Paths List
   flag=2 ---- Namees List
   flag=4 ---- Variables List
   flag=8 ---- Malloc Info 
   flag=16 --- XML Map List
*/

    if ((flag & 0x00000001) == 1) {
        if (flag>0 && xml) {
		printf("\n<DEBUG>", flag);
		printf("\n\t<TYPE>test</TYPE>");
		printf("\n\t<VALUE>%d</VALUE>", flag);
	 	printf("\n\t<TITLE>Paths List</TITLE>\n\t<TEXT count=%d>", h_path_i);
	}
	else printf("\n<br><b>Paths List:</b>");
	for (i=0; i<h_path_i; i++) {
		if (!h_path[i]) {
			printf("\n%sh_path[%d] is null", xml? "":"<br>", i); 
			continue;
		}
		printf("\n%sid -- %d\t name -- %s\t",  xml? "":"<br>", i, h_path[i]->name? h_path[i]->name : "null");	
		printf("type -- %s\t", h_path[i]->type? h_path[i]->type : "null");	
		printf("path -- %s\t", h_path[i]->path? escape_special(h_path[i]->path) : "null");	
		fflush(stdout);
	}
	if (flag>0 && xml) printf("\n\t</TEXT>\n</DEBUG>");
    }

    if ((flag & 0x00000002) == 2) {
        if (flag>0 && xml) {
		printf("\n<DEBUG>", flag);
		printf("\n\t<TYPE>test</TYPE>");
		printf("\n\t<VALUE>%d</VALUE>", flag);
	 	printf("\n\t<TITLE>Names List</TITLE>\n\t<TEXT>");
	}
	else printf("\n<br><b>Names List:</b>");
	for (i=0; i<h_name_i; i++) {
		if (!h_name[i]) {
			printf("\n%sh_name[%d] is null", xml? "":"<br>", i); 
			continue;
		}
		printf("\n%svalue-- %s \t", xml? "":"<br>", h_name[i]->value? h_name[i]->value : "null");
		printf("name_sas -- %s\t", h_name[i]->name_sas? h_name[i]->name_sas : "null");	
		printf("name_html -- %s\t", h_name[i]->name_html? h_name[i]->name_html : "null");	
		printf("name_pop -- %s\t", h_name[i]->name_pop? h_name[i]->name_pop : "null");	
		printf("type1-- %s \t", h_name[i]->type1? h_name[i]->type1 : "null");
		printf("type2-- %s \t", h_name[i]->type2? h_name[i]->type2 : "null");
		printf("note-- %s \t", h_name[i]->note? h_name[i]->note : "null");
		printf("prompt-- %s \t", h_name[i]->prompt? escape_special(h_name[i]->prompt) : "null");
		fflush(stdout);
		
	}
	if (flag>0 && xml) printf("\n\t</TEXT>\n</DEBUG>");
    }

    if ((flag & 0x00000004) == 4) {
        if (flag>0 && xml) {
		printf("\n<DEBUG>", flag);
		printf("\n\t<TYPE>test</TYPE>");
		printf("\n\t<VALUE>%d</VALUE>", flag);
	 	printf("\n\t<TITLE>Variables List</TITLE>\n\t<TEXT>");
	}
	else printf("\n<br><b>Variables List:</b>");
	for (i=0; i<h_vari_i; i++) {
		if (!h_vari[i]) {
			printf("\n%sh_vari[%d] is null", xml? "":"<br>", i); 
			continue;
		}
  		if (!h_vari[i]->name_ptr) {
			printf("\n%sh_vari[%d]->name_ptr is null", xml? "":"<br>", i); 
			continue;
		}
		printf("\n%sname_sas -- %s\t", xml? "":"<br>", h_vari[i]->name_ptr->name_sas? h_vari[i]->name_ptr->name_sas : "null");
		printf("name_html -- %s \t", h_vari[i]->name_ptr->name_html? h_vari[i]->name_ptr->name_html : "null");
		printf("type1-- %s \t", h_vari[i]->name_ptr->type1? h_vari[i]->name_ptr->type1 : "null");
		printf("type2-- %s \t", h_vari[i]->name_ptr->type2? h_vari[i]->name_ptr->type2 : "null");
		printf("value-- %s \t", h_vari[i]->value? escape_special(h_vari[i]->value) : "null");
		printf("label-- %s \t", h_vari[i]->label? escape_special(h_vari[i]->label) : "null");
		fflush(stdout);
	}
	if (flag>0 && xml) printf("\n\t</TEXT>\n</DEBUG>");
    }

#ifndef WIN_NT
    if ((flag & 0x00000008) == 8) {
		mall_print();
    }
#endif

    if ((flag & 0x00000016) == 16) {
        if (flag>0 && xml) {
		printf("\n<DEBUG>", flag);
		printf("\n\t<TYPE>test</TYPE>");
		printf("\n\t<VALUE>%d</VALUE>", flag);
	 	printf("\n\t<TITLE>XML Map List</TITLE>\n\t<TEXT>");
	}
	else printf("\n<br><b>XML Map List:</b>");
	for (i=0; i<h_map_i; i++) {
		if (!h_map[i]) {
			printf("\n%sh_map[%d] is null", xml? "":"<br>", i); 
			continue;
		}
		printf("\nid -- %d \t", h_map[i]->id);
		printf("\nsas_data_column-- %s \t", h_map[i]->sas_data_column? h_map[i]->sas_data_column : "null");
		printf("\nxml_element_name-- %s \t", h_map[i]->xml_element_name? h_map[i]->xml_element_name : "null");
		printf("\nvalue_of_name_element-- %s \t", h_map[i]->value_of_name_element? h_map[i]->value_of_name_element : "null");
		printf("\nplural_flag-- %s \t", h_map[i]->plural_flag? h_map[i]->plural_flag : "null");

		fflush(stdout);
	}
	if (flag>0 && xml) printf("\n\t</TEXT>\n</DEBUG>");
    }
}


/*	function:	file_open
			flag=0	----	file name
			flag=1	----	key to file name
*/
FILE * file_open(char * key, int flag) {
	FILE * fp;
	char * tmp, *path, buf[BUFFER_N];
	int len;

	if (flag) {
		if (!(tmp=find_path(key))) return NULL;
	}
	else tmp=key;
	if ((fp=fopen(tmp, "r"))) return fp;
	
	if (!(path=de_space(find_path("homepath")))) hbase_error(41, "homepath");
	len=strlen(path);
#ifdef WIN_NT
	sprintf(buf, "%s%s%s", path, path[len-1]=='\\'? "" : "\\", tmp);
#else
	sprintf(buf, "%s%s%s", path, path[len-1]=='/'? "" : "/", tmp);
#endif


	if ((fp=fopen(buf, "r"))) return fp;

	if (!(path=find_path("sharepath"))) return NULL;
	len=strlen(path);
#ifdef WIN_NT
	sprintf(buf, "%s%s%s", path, path[len-1]=='\\'? "" : "\\", tmp);
#else
	sprintf(buf, "%s%s%s", path, path[len-1]=='/'? "" : "/", tmp);
#endif
	if ((fp=fopen(buf, "r"))) return fp;

	return NULL;
}

long getUnixEpochSecond(time_t * t) {
	long s=0;
	struct tm * tmt=gmtime(t);
	long d=(tmt->tm_year-70)*365;
	int i;
	for (i=70; i<tmt->tm_year; i++)
	  if (i%4==0) d++;
	d=d+tmt->tm_yday;
	//printf("\ntm_year: %d tm_yday: %d days: %ld", tmt->tm_year, tmt->tm_yday, d);
	s=d*86400+tmt->tm_hour*3600+tmt->tm_min*60+tmt->tm_sec;
	return s;
}

time_t  *get_last_modified(char * key) {
	int flag=1;
	static struct stat fst;
	char * tmp, *path;
	static char buf[BUFFER_N];
	int len;

 	//bzero(&fst,sizeof(fst));

	tmp=key;
	flag=stat(tmp, &fst);
        if (flag == 0) {
		return &fst.st_mtime;
	}
	
	if (!(path=de_space(find_path("saspath")))) hbase_error(41, "saspath");
	len=strlen(path);
#ifdef WIN_NT
	sprintf(buf, "%s%s%s", path, path[len-1]=='\\'? "" : "\\", tmp);
#else
	sprintf(buf, "%s%s%s", path, path[len-1]=='/'? "" : "/", tmp);
#endif

//return NULL;
	flag=stat(buf, &fst);
        if (flag == 0) {
		sprintf(buf, "%s",  ctime(&fst.st_mtime));
		return &fst.st_mtime;
	}

	if (!(path=find_path("sharepath"))) return NULL;
	len=strlen(path);
#ifdef WIN_NT
	sprintf(buf, "%s%s%s", path, path[len-1]=='\\'? "" : "\\", tmp);
#else
	sprintf(buf, "%s%s%s", path, path[len-1]=='/'? "" : "/", tmp);
#endif
        if (stat(buf,&fst) == 0) {return &fst.st_mtime;}

	return NULL;
}

void query_save(char * qt) {
	FILE * out;
	char buf[BUFFER_N];

	get_sasname(buf);
	strcat(buf, ".qry");
	if (!(out=fopen(buf, "w"))) return;
	fputs(qt, out);
	fclose(out);
}

void query_vari(char *qt) {
	char * tmp, *tmp2;
	int i;

	tmp = qt;
	for (i=0;;i++) {
		if (!(long)(tmp2=strchr(tmp, '&'))) break;
		tmp = tmp2+1;
	}
	if (!(h_vari=(VARI **) malloc((i+1)*sizeof(VARI *)))) hbase_error(3, "util-1");

	tmp = qt;
	for (;;) {
		if (!tmp) break;
		h_vari_bld(&tmp);
	}
}

void h_vari_bld(char ** qt) {
	char * tmp, * tmp2;
	int vari_f, i;

	if (!(h_vari[h_vari_i]=(VARI *) malloc(sizeof(VARI)))) hbase_error(3, "util-2");
	tmp = *qt;

	if (!(tmp2=strchr(tmp, '='))) {
		vari_f=0;
		h_vari[h_vari_i]->value=NULL;
		*qt=NULL;
	}
	else {
		vari_f=1;
		tmp2[0]=0;
	}

	h_vari[h_vari_i]->name_ptr=find_name(tmp, 1);
	if (!h_vari[h_vari_i]->name_ptr) {
		for (i=0; i<h_path_i; i++) {
			if (!strcmp(h_path[i]->name, tmp)) break;
		}
		if (i<h_path_i && vari_f) {
			tmp=tmp2+1;
			h_path[i]->path=tmp;
			if (tmp2=strchr(tmp, '&')) {
				*qt=tmp2+1;
				tmp2[0]=0;
				if (strstr(tmp, "ALL")) {
					free(h_vari[h_vari_i]);
					return;
				}
			}
			else *qt=NULL;
			free(h_vari[h_vari_i]);
			return;
		}
		else {
			if (!(h_vari[h_vari_i]->name_ptr = 
				(NAME *) malloc(sizeof(NAME)))) hbase_error(3, "util-3");
			h_vari[h_vari_i]->name_ptr->name_html=tmp;
			h_vari[h_vari_i]->name_ptr->name_sas=NULL;
			h_vari[h_vari_i]->name_ptr->value=NULL;
			h_vari[h_vari_i]->name_ptr->prompt=NULL;
			h_vari[h_vari_i]->name_ptr->type1=NULL;
			h_vari[h_vari_i]->name_ptr->type2="9999";
			h_vari[h_vari_i]->name_ptr->note=NULL;
		}
	}

	if (vari_f) {
		tmp=tmp2+1;
		h_vari[h_vari_i]->value=tmp;
		if (tmp2=strchr(tmp, '&')) {
			*qt=tmp2+1;
			tmp2[0]=0;
			if (strstr(tmp, "ALL")) {
				free(h_vari[h_vari_i]);
				return;
			}
		}
		else *qt=NULL;
		if (!h_vari[h_vari_i]->value[0]) {
			free(h_vari[h_vari_i]);
			return;
		}
	}

	if (!vari_f) h_vari[h_vari_i]->label=NULL;
	else h_vari[h_vari_i]->label=find_label(
			h_vari[h_vari_i]->name_ptr->name_html, 
			h_vari[h_vari_i]->value);

	h_vari_i++;
}

char * find_stdpop(int f) {
	VARI ** v_ptr;
	int c;
	char *tmp1, *tmp2;

	if (!(v_ptr=find_vari("stdyr", 2, 7, &c))) {
		tmp1 = "2000"; 
		tmp2 = "2000 US population";
	}
	else {
		tmp1 = v_ptr[0]->value;
		tmp2 = v_ptr[0]->label;
		free(v_ptr);
	}

	if (!f) return(tmp1);
	return (tmp2? tmp2 : tmp1);
}

char * find_label(char * name, char * value) {
	char * tmp, * tmp2, buf[BUFFER_N], buf2[BUFFER_N], *str;
	int flag=0, dynamic=0;
	FILE * format;

	tmp2=get_sasname(buf);
	sprintf(buf2, "%s%s.lbl", tmp2, name);
	if (!(format=fopen(buf2, "r"))) {
		sprintf(buf2, "%s.lbl", name);
		if (!(format=file_open(buf2, 0)))	return value;
	}
	else dynamic=1;

	while (!feof(format)) {
		if (!(tmp=fgets(buf, BUFFER_N, format))) break;
		if (!(tmp2=strchr(tmp, '~'))) 
			if (!(tmp2=strchr(tmp, ' ' ))) continue;
		tmp2[0]=0;
		tmp2++;
		if (tmp2[strlen(tmp2)-1]=='\n') tmp2[strlen(tmp2)-1]=0;
		if (!strcmp(tmp, value)) {
			if (!(str=(char *) malloc((strlen(tmp2)+1)*sizeof(char)))) hbase_error(3, "util-4");
			strcpy(str, tmp2); 
			fclose(format);
			return str;
		}
	}
	fclose(format);
	return value;
}

char * find_label_dynamic(char * name, char * value, int *dynamic) {
	char * tmp, * tmp2, buf[BUFFER_N], buf2[BUFFER_N], *str;
	int flag=0;
	FILE * format;


	tmp2=get_sasname(buf);
	sprintf(buf2, "%s%s.lbl", tmp2, name);
	if (!(format=fopen(buf2, "r"))) {
		*dynamic=0;
		sprintf(buf2, "%s.lbl", name);
		if (!(format=file_open(buf2, 0))) {
		  strcpy(buf2, name);
		  if (!(format=file_open(buf2, 0)))	return value;
		}
	}
	else *dynamic=1;

	while (!feof(format)) {
		if (!(tmp=fgets(buf, BUFFER_N, format))) break;
		if (!(tmp2=strchr(tmp, '~'))) 
			if (!(tmp2=strchr(tmp, ' ' ))) continue;
		tmp2[0]=0;
		tmp2++;
		if (tmp2[strlen(tmp2)-1]=='\n') tmp2[strlen(tmp2)-1]=0;
		if (!strcmp(tmp, value)) {
			if (!(str=(char *) malloc((strlen(tmp2)+1)*sizeof(char)))) hbase_error(3, "util-4");
			strcpy(str, tmp2); 
			fclose(format);
			return str;
		}
	}
	fclose(format);
	return value;
}

void reset_path(char * key, char *newvalue) {
	int i;

	for (i=0; i<h_path_i; i++) {
		if (!strcmp(h_path[i]->name, key)) {
		  if (newvalue) {
		    h_path[i]->path=(char *) malloc(strlen(newvalue)+1);
		    strcpy(h_path[i]->path, newvalue);
		  }
		  else h_path[i]->path=0;
		}
	}
}

char * find_path(char * key) {
	int i;

	for (i=0; i<h_path_i; i++) {
		if (!strcmp(h_path[i]->name, key)) break;
	}
	return(i>=h_path_i ? NULL : h_path[i]->path);
}

NAME * find_name(char * key, int flag) {
	int i;

	for (i=0; i<h_name_i; i++) {
		if (flag==1) {
			if (!h_name[i]->name_html) continue; 
			if (!strcmp(h_name[i]->name_html, key)) break;
		}
		if (flag==2) { 
			if (!h_name[i]->name_sas) continue; 
		 	if (!strcmp(h_name[i]->name_sas, key)) break;
		}
		if (flag==3) {
			if (!h_name[i]->name_pop) continue; 
		 	if (!strcmp(h_name[i]->name_pop, key)) break;
		}
	}
	return(i>=h_name_i ? NULL : h_name[i]);
}

NAME ** find_name_group(char * key, int flag, int* c) {
	int i, j;
	NAME ** n_ptr;

	for (i=0, j=0; i<h_name_i; i++) {
		if (flag==1) {
			if (!h_name[i]->name_html) continue; 
			if (!strcmp(h_name[i]->name_html, key)) j++;
		}
		if (flag==2) { 
			if (!h_name[i]->name_sas) continue; 
		 	if (!strcmp(h_name[i]->name_sas, key)) j++;
		}
		if (flag==3) {
			if (!h_name[i]->name_pop) continue; 
		 	if (!strcmp(h_name[i]->name_pop, key)) j++;
		}
	}
	if (!j) return NULL;

	if (!(n_ptr=(NAME **) malloc(sizeof (NAME *)*(j+1)))) 
		hbase_error(3, "find_name_group");
	for (i=0, j=0; i<h_name_i; i++) {
		if (flag==1) {
			if (!h_name[i]->name_html) continue; 
			if (!strcmp(h_name[i]->name_html, key)) {
				n_ptr[j]=h_name[i];
				j++;
			}
		}
		if (flag==2) { 
			if (!h_name[i]->name_sas) continue; 
		 	if (!strcmp(h_name[i]->name_sas, key)) {
				n_ptr[j]=h_name[i];
				j++;
			}
		}
		if (flag==3) {
			if (!h_name[i]->name_pop) continue; 
		 	if (!strcmp(h_name[i]->name_pop, key)) {
				n_ptr[j]=h_name[i];
				j++;
			}
		}
	}
	n_ptr[j]=NULL;
	*c=j;
	return n_ptr;
}

NAME * find_name_type(char * key, int flag, int type) {
	int i;

	for (i=0; i<h_name_i; i++) {
		if (flag==1 && atoi(h_name[i]->type2)==type) {
			if (!h_name[i]->name_html) continue; 
			if (!strcmp(h_name[i]->name_html, key)) break;
		}
		if (flag==2 && atoi(h_name[i]->type2)==type) {
			if (!h_name[i]->name_sas) continue; 
		 	if (!strcmp(h_name[i]->name_sas, key)) break;
		}
		if (flag==3 && atoi(h_name[i]->type2)==type) {
			if (!h_name[i]->name_pop) continue; 
		 	if (!strcmp(h_name[i]->name_pop, key)) break;
		}
	}
	return(i>=h_name_i ? NULL : h_name[i]);
}

void de_amp(char * qt) {
	char *str;
	unsigned short  flag=0, i, j=0;
	
	if (!(str=(char *)malloc(strlen(qt)+2))) hbase_error(3, "de_amp");
 
	for (i=0; i<strlen(qt); i++) {
		if (qt[i]<' ') qt[i]=' ';
		if (qt[i]=='&' && flag==1) continue;
		if (qt[i]=='&') flag=1;
		else flag=0;
		str[j]=qt[i];
		j++;
	}
	str[j]=0;
	strcpy(qt, str);
}
char x2c(char *what) {
    register char digit;

    digit = (what[0] >= 'A' ? ((what[0] & 0xdf) - 'A')+10 : (what[0] - '0'));
    digit *= 16;
    digit += (what[1] >= 'A' ? ((what[1] & 0xdf) - 'A')+10 : (what[1] - '0'));
    return(digit);
}

int numberValue(char * str) {
    int i, l=strlen(str);
    for (i=0; i<l; i++) {
      if (!isdigit(str[i])) return 0;
    }
    return 1;
}

char * escape_special(char * str) {
    char *buf;
    int i, j;
    VARI **v_ptr;
    NAME * n_ptr;

    if (!str) return str;

    buf=malloc(BUFFER_N);
    for (i=0, j=0; str[i]; i++) {
	if (str[i]=='<') {
	  buf[j++]='&';
	  buf[j++]='l';
	  buf[j++]='t';
	  buf[j++]=';';
	}
	else if (str[i]=='>') {
	  buf[j++]='&';
	  buf[j++]='g';
	  buf[j++]='t';
	  buf[j++]=';';
	}
	else if (str[i]=='&') {
	  buf[j++]='&';
	  buf[j++]='a';
	  buf[j++]='m';
	  buf[j++]='p';
	  buf[j++]=';';
	}
	else if (str[i]<0x20 || str[i]==0xA || str[i]==0xD
	  	|| str[i]==0x9) {
	}
	else buf[j++]=str[i];
    }

    buf[j]=0;
    if (buf[j-1]==' ' || buf[j-1]=='\n' || buf[j-1]=='\a') buf[j-1]=0;
    if (j>2 && buf[j-2]=='_' && buf[j-1]=='f') {
      v_ptr=find_vari(buf, 1, 8, &i);
      if (v_ptr!=NULL && i>0) {
	n_ptr=find_name(v_ptr[0]->value, 1);
	if (n_ptr>0) return n_ptr->name_html;
	//if (n_ptr>0 && atoi(n_ptr->type2)==0) return n_ptr->name_html;

      if (v_ptr && numberValue(v_ptr[0]->value)) {
      	if (v_ptr && i>0) {
      	  buf[j-2]=0;
      	  strcat(buf, v_ptr[0]->value);
      	}
      }
      else return v_ptr[0]->value;
      }

    }
    
    return buf;
}

void unescape_url(char *url) {
    register int x,y;

    for(x=0,y=0;url[y];++x,++y) {
        if((url[x] = url[y]) == '%') {
            url[x] = x2c(&url[y+1]);
            y+=2;
        }
    }
    url[x] = '\0';
}

void plustospace(char *str) {
    register int x;

    for(x=0;str[x];x++) if(str[x] == '+') str[x] = ' ';
}

void query_clean(char * qt, int flag) {
	
	if (flag<2) plustospace(qt);
	unescape_url(qt);
	de_amp(qt);
}

char * find_config(char * qt) {
	char * tmp, *tmp2, *buf;

	if (!(tmp=strstr(qt, "config="))) return(NULL);
	if (!(tmp2=strchr(tmp+7, '&'))) tmp2=qt+strlen(qt);
	if (!(buf=malloc((tmp2-tmp-6)*sizeof(char)))) hbase_error(3, "util-5");
	strncpy(buf, tmp+7, tmp2-tmp-7);
	buf[tmp2-tmp-7]='\0';
	return(buf);
}

void query_conf(char ** qt) {
	char * tmp,  *str;
	FILE * conf;
	int l;

	l=strlen(*qt);

	if (!(str=(char *)malloc(l+2))) hbase_error(3, "query_conf");

	tmp = *qt;
	if (!(tmp=find_config(*qt))) hbase_error(2, *qt);
	if (!(conf=fopen(tmp, "r"))) hbase_error(56, tmp);

	while (!feof(conf)) {
		if (!(tmp=fgets(str, l, conf))) break;
		if (isalpha(tmp[0])) h_path_i++;
		if (isdigit(tmp[0])) h_name_i++;	
	}
	if (!(h_path=(PATH **) malloc(h_path_i*sizeof(PATH *))))
		hbase_error(3, "util-6");
	if (!(h_name=(NAME **) malloc(h_name_i*sizeof(NAME *))))
		hbase_error(3, "util-7");

	rewind(conf); 
	h_path_i=0;
	h_name_i=0;
	while (!feof(conf)) {
		if (!(tmp=fgets(str, l, conf))) break;
		if (tmp[strlen(tmp)-1]=='\n') tmp[strlen(tmp)-1]=0;
		if (tmp[strlen(tmp)-1]=='\r') tmp[strlen(tmp)-1]=0;
		if (isalpha(tmp[0])) h_path_bld(tmp);
		if (isdigit(tmp[0])) h_name_bld(tmp);
	}
	fclose(conf);
}

void h_path_bld(char * tmp) {
	char *tmp2;

	if (!(h_path[h_path_i]=(PATH *) malloc(sizeof(PATH)))) hbase_error(3, "util-8");
	if (!(tmp2=strchr(tmp, ' '))) hbase_error(4, tmp);
	tmp2[0]=0;
	if (!(h_path[h_path_i]->type=malloc(strlen(tmp)+1))) hbase_error(3, "util-9");
	strcpy(h_path[h_path_i]->type, tmp);
	tmp=tmp2+1;
	if (!(tmp2=strchr(tmp, ' '))) hbase_error(4, tmp);
	tmp2[0]=0;
	if (!(h_path[h_path_i]->name=malloc(strlen(tmp)+1))) hbase_error(3, "util-10");
	strcpy(h_path[h_path_i]->name, tmp);
	tmp=tmp2+1;
	if (tmp2=strchr(tmp, ' ')) tmp2[0]=0;
	cl_amp(tmp);
	if (!(h_path[h_path_i]->path=malloc(strlen(tmp)+1))) hbase_error(3, "util-11");
	strcpy(h_path[h_path_i]->path, tmp);
	h_path_i++;
}

void cl_amp(char * tmp) {
	unsigned short  i;

	for (i=0; i<strlen(tmp); i++) {
		if (tmp[i]=='&') tmp[i]=' ';
	}
}

void h_name_bld(char * tmp) {
	char * tmp1, * tmp2;
	int i, flag=0;

	if (!(h_name[h_name_i]=(NAME *) malloc(sizeof(NAME)))) hbase_error(3, "util-12");
	tmp1=tmp;
	for (i=0; i<8; i++) {
		if (!(tmp2=strchr(tmp1, ' '))) {tmp=tmp1; flag=1;}
		else {
			tmp=tmp1;
			tmp1=tmp2+1;
			tmp2[0]=0;
		}
	switch(i) {
	case 0: if (!(h_name[h_name_i]->value=(char *) malloc((strlen(tmp)+1)*sizeof(char)))) hbase_error(3, "util-13");
		strcpy(h_name[h_name_i]->value, tmp);
		break;
	case 1: if (!strcmp(tmp, "null")) {
			h_name[h_name_i]->name_sas=NULL;
			break;
		}
		if (!(h_name[h_name_i]->name_sas=(char *) malloc((strlen(tmp)+1)*sizeof(char)))) hbase_error(3, "util-14");
		strcpy(h_name[h_name_i]->name_sas, tmp);
		break;
	case 2: if (!strcmp(tmp, "null")) {
			h_name[h_name_i]->name_html=NULL;
			break;
		}
		if (!(h_name[h_name_i]->name_html=(char *) malloc((strlen(tmp)+1)*sizeof(char)))) hbase_error(3, "util-15");
		strcpy(h_name[h_name_i]->name_html, tmp);
		break;
	case 3: if (!strcmp(tmp, "null")) {
			h_name[h_name_i]->name_pop=NULL;
			break;
		}
		if (!(h_name[h_name_i]->name_pop=(char *) malloc((strlen(tmp)+1)*sizeof(char)))) hbase_error(3, "util-16");
		strcpy(h_name[h_name_i]->name_pop, tmp);
		break;
	case 4: if (!(h_name[h_name_i]->prompt=(char *) malloc((strlen(tmp)+1)*sizeof(char)))) hbase_error(3, "util-17");
		cl_amp(tmp);
		strcpy(h_name[h_name_i]->prompt, tmp);
		break;
	case 5: if (!(h_name[h_name_i]->type1=(char *) malloc((strlen(tmp)+1)*sizeof(char)))) hbase_error(3, "util-18");
		strcpy(h_name[h_name_i]->type1, tmp);
		break;
	case 6: if (!(h_name[h_name_i]->type2=(char *) malloc((strlen(tmp)+1)*sizeof(char)))) hbase_error(3, "util-19");
		strcpy(h_name[h_name_i]->type2, tmp);
		break;
	case 7: if (!(h_name[h_name_i]->note=(char *) malloc((strlen(tmp)+1)*sizeof(char)))) hbase_error(3, "util-20");
		cl_amp(tmp);
		strcpy(h_name[h_name_i]->note, tmp);
		break;
	}
	if (flag) break;
	}
	h_name_i++;
}

void conf_bld(char ** path) {
	char * tmp, * tmp2;

	tmp = *path;
	for (;;) {
		if (!(tmp2 = strchr(tmp, '%'))) break;
		if (!strncmp(tmp2, "%2F", 3)) {
			tmp2[0]='/';
			strcpy(tmp2+1, tmp2+3);
		}
	}
}
		
VARI ** find_vari(char * key, int flag, int t, int * c) {
/*	flag == 1	name_html
	flag == 2	name_sas
	t		type2
*/
	VARI ** tmp;
	int i, j;

	if (flag != 1 && flag != 2) return (NULL);
	j=0;
	for (i=0; i<h_vari_i; i++) {
		if (flag==1  && atoi(h_vari[i]->name_ptr->type2)==t
			&& !strcmp(h_vari[i]->name_ptr->name_html,key)) j++;
		if (flag==2  && atoi(h_vari[i]->name_ptr->type2)==t
			&& !strcmp(h_vari[i]->name_ptr->name_sas, key)) j++;
	}
	if (j==0) { *c=-1; return(NULL);}
	if (!(tmp=(VARI **) malloc(j*sizeof(VARI *)))) hbase_error(3, "util-21");
	j=0;
	for (i=0; i<h_vari_i; i++) {
		if (flag==1 && atoi(h_vari[i]->name_ptr->type2)==t  
			&& !strcmp(h_vari[i]->name_ptr->name_html,key))  {
			tmp[j] = h_vari[i];
			j++;
		}
	if (flag==2 && atoi(h_vari[i]->name_ptr->type2)==t 
			&& !strcmp(h_vari[i]->name_ptr->name_sas, key)) {
			tmp[j] = h_vari[i];
			j++;
		}
	}
	*c = j;
	return(tmp);
}

char * find_format(char * name, char * value, char * str) {
	char * tmp;

	if (!(tmp=find_label(name, value))) return(NULL);
	strcpy(str, tmp);
	free(tmp);
	return(str);
}


char * de_space(char * tmp) {
	int i;

	for (i=strlen(tmp)-1; i>=0; i--) {
		if (tmp[i]==' ' || tmp[i]=='\n' || tmp[i]==13) tmp[i]=0;
		else break;
	}
	for (i=0; i<(signed) strlen(tmp); i++) {
		if (tmp[i]!=' ' && tmp[i]!='\n' && tmp[i]!=13)
			return(tmp+i);
	}
	return(tmp);
}

void hbase_clear() {
	char str[STRING_N], str2[STRING_N], *tmp;

	tmp=get_sasname(str);
	str2[0]=0;

	strcat(str, ".sas");
	unlink(str);
	tmp=strstr(str, ".sas");
	strcpy(tmp, ".log");
	unlink(str);
	tmp=strstr(str, ".log");
	strcpy(tmp, ".lst");
	unlink(str);
	tmp=strstr(str, ".lst");
	strcpy(tmp, ".dat");
	unlink(str);
	tmp=strstr(str, ".dat");
	tmp[0]=0;

	if (_label) {
		}

#ifdef WIN_NT
		sprintf(str2+strlen(str2), "\ndel %s*.lbl 1>null1 2>null2", str);
		system(str2);
#else
		sprintf(str2, "\nrm %s*.lbl 1>/dev/null 2>/dev/null", str);
		system(str2);
#endif
}

void hbase_warning(int i) {
	char *tmp, str[BUFFER_N];

	if (form==21 || form==22 || form==23 || form==30) {
	  printf("\n<ERROR ID=\'%d\'>", i);
	  printf("\nWARNING: ");
	}
	else printf("\n<font size=+1><b>WARNING: </b></font>");

	switch(i) {
	case 1: 
		printf("\n Cross variable 1 and cross variable 2 can not use the ");
		printf("\n same data element, the first cross variable was used.");
		break;
	case 2:
		sprintf(str, "func%s", find_path("func"));
		tmp=find_path(str);
		printf("\nWhen you use the function <b>%s</b>, you have to ", tmp? tmp : str);
		printf("\nuse the table output or graph output. Table output was used.");
		break; 
	case 3:
		sprintf(str, "func%s", find_path("func"));
		tmp=find_path(str);
		printf("\nWhen you use the function <b>%s</b>, you have to ", tmp? tmp : str);
		printf("\nuse the browsing output.");
		break;
	case 4:
		sprintf(str, "func%s", find_path("func"));
		tmp=find_path(str);
		printf("\nWhen you use the function <b>%s</b>, you have to ", tmp? tmp : str);
		printf("\nuse the editing output.");
		break;
	case 5:
		sprintf(str, "func%s", find_path("func"));
		tmp=find_path(str);
		printf("\nWhen you use the function <b>%s</b>, you can not ", tmp? tmp : str);
		printf("\nuse the patient's age group as cross variable. ");
		break;
	case 6:
		printf("\nWhen you select the <b>MAP</b> to present your result, ");
		printf("\nyou have to use the patient's residential county as cross variable 1, ");
		printf("\nand set cross variable 2 to none.");
		break;
	case 7: printf("\nNo standard population was selected, 2000 US population is used.");
		break;
	case 8:
		sprintf(str, "func%s", find_path("func"));
		tmp=find_path(str);
		printf("\nWhen you use the function <b>%s</b>, you only can ", tmp? tmp : str);
		printf("\nuse the Causes as cross variable. ");
		break;
	default:
		break;
	}
	if (form==21 || form==22 || form==23 || form==30) {
	  printf("\n</ERROR>");
	  printf("\n</IBISQ_DATA>");
	}
	else printf("\n<hr>");
}

void hbase_error(int i, char * str) {
	if (!content_type) printf("Content-type: text/html%c%c",10,10); 
	if (form==21 || form==22 || form==23 || form==30) {
	  printf("\n</DEBUGS>");
	  printf("\n<ERROR ID=\'%d\'>", i);
	  printf("\n<CODE>%d</CODE>", i);
	  printf("\n<DESCRIPTION>");
	}
	else printf("\nERROR--%d: ", i);
	switch(i) {
	case 1:
        	printf("\n No query information to decode.");
		break;
	case 2:
        	printf("\n Can not open configure file.");
		break;
	case 3:
        	printf("\n Not enough memory.");
		break;
	case 4:
        	printf("\n Configure file error.");
		break;
	case 5:
        	printf("\n Can not open temprorary file.");
		break;
	case 6:
        	printf("\n Can not find SAS library.");
		break;
	case 7:
        	printf("\n Can not find SAS dataset.");
		break;
	case 8:
        	printf("\n No outcome vairable was choosen.");
		break;
	case 9:
        	printf("\n Unknown outcome type.");
		break;
	case 10:
        	printf("\n Can not find cross variable.");
		break;
	case 11:
        	printf("\n Can not find outcome variable.");
		break;
	case 12:
        	printf("\n Can not find outcome data file.");
		break;
	case 13:
        	printf("\n Can not open output file.");
		break;
	case 14:
        	printf("\n No graph type was selected.");
		break;
	case 15:
        	printf("\n Too many categories, can not put into graph.");
		break;
	case 16:
        	printf("\n Too manay categories in second cross variable.");
		break;
	case 17:
        	printf("\n Unknown data type.");
		break;
	case 18:
        	printf("\n Query is too long.");
		break;
	case 19:
        	printf("\n Can not use second cross variable in pie graph.");
		break;
	case 20:
        	printf("\n The summation is zero.");
		break;
	case 21:
        	printf("\n No proper outcome variable was seleced.");
		break;
	case 22:
        	printf("\n Can not open map file.");
		break;
	case 23:
        	printf("\n \'COUNTY\' must by used as first cross variable,");
		printf("\n and the second cross variable is none if you want");
		printf("\n to use map presentation.");
		break;
	case 24:
        	printf("\n Can not find action function.");
		break;
	case 25:
        	printf("\n Can not find configuration function.");
		break;
	case 26: 
		printf("\n The map base file is corrupted.");
		break;
	case 27:
		printf("\n The requested function was not found.");
		break;
	case 28:
		printf("\n Can not find mail program.");
		break;
	case 29: 
		printf("\n Can not find recipient.");
		break;
	case 30:
		printf("\n Mail pipe is broken.");
		break;
	case 31:
		printf("\n Invalid data type for cross variable.");
		break;
	case 32:
		printf("\n Can not open group file.");
		break;
	case 33:
		printf("\n Can not find cross variable for grouping.");
		break;
	case 34:
		printf("\n Can not write label file.");
		break;
	case 35:
		printf("\n Can not fork new process.");
		break;
	case 36:
		printf("\n Can not define age groups.");
		break;
	case 37:
		printf("\n Can not open tail file.");
		break;
	case 38:
		printf("\n Can not open testing file.");
		break;
	case 39:
		printf("\n Testing file is empty.");
		break;
	case 40:
		printf("\n Can not find specified function property.");
		break;
	case 41:
		printf("\n Can not find home directory.");
		break;
	case 42:
		printf("\n Can not open label file.");
		break;
	case 43:
		printf("\n Can not find working directory.");
		break;
	case 44:
		printf("\n Can not open specified file.");
		break;
	case 45:
		printf("\n Can not get SAS file name.");
		break;
	case 46:
		printf("\n Function definition file error.");
		break;
	case 47:
		printf("\n Can not find specified function property.");
		break;
	case 48:
		printf("\n Can not find population dataset.");
		break;
	case 49:
		printf("\n Can not find standard population dataset.");
		break;
	case 50:
		printf("\n Can not find user dataset.");
		break;
	case 51:
		printf("\n Can not find the specified file.");
		break;
	case 52:
		printf("\n Can not find share directory.");
		break;
	case 53:
		printf("\n Filename is null.");
		break;
	case 54:
		printf("\n Can not find parameter in configuration file.");
		break;
	case 55:
		printf("\n SAS error.");
		break;
	case 56:
		printf("\n Config file error.");
		break;
	case 57:
		printf("\n Func def file error.");
		break;
	case 58:
		printf("\n No valid cross variable found.");
		break;
	case 59:
		printf("\n Cannot find variable in .cfg file.");
		break;
	default:
		printf("\n HI-IQ System error.");
		break;
	}
	if (str) printf("\n %s", str);
	if (form==21 || form==22 || form==23 || form==30) {
	  printf("\n</DESCRIPTION>");
	  printf("\n</ERROR>");
	  printf("\n</IBISQ_QUERY_RESULT>");
	}
/*
	hbase_clear();
*/
	exit(0);
}

