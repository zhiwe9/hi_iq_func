#ifndef HI_IQ_VAR_H
#define HI_IQ_VAR_H
/* HI-IQ System, the High Information Internet Query System,
	Copyright 1995, 1996 Utah Office of Health Data Analysis.

	hi_iq_var.h	01/29/97

	We provide the interactive interface to make your data available
	to public through Internet.

	gd library written by Thomas Boutell, 5/94.
	Copyright 1994, Cold Spring Harbor Labs.
*/

extern PATH ** h_path;
extern NAME ** h_name;
extern VARI ** h_vari;
extern USER ** h_user;
extern FUNC ** h_func;
extern MAP **  h_map;

extern int     content_type;
extern int	   form;
extern int	   xml;
extern int	   _label;
extern int	   _out_variable;
extern int     h_path_i;
extern int     h_name_i;
extern int     h_vari_i;
extern int     h_user_i;
extern int     h_map_i;

extern char *  h_sasname;
extern char *_cross_1;
extern char *_cross_2;
extern char *_cross_3;
#endif
