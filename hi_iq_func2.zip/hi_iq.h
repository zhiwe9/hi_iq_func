/* HI-IQ System, the High Information Internet Query System,

	Copyright 1995, 1996, 1997, 1998 Utah Office of Health Data Analysis.

	hi_iq.h	11/11/98
	define header files, data structures, and functions.

	We provide the interactive interface to make your data available
	to public through Internet.

*/
#define WIN_NT
/* WIN_NT is for Windows NT platform only, when compiling on Un*x plat, this
	macro variable should be undefined by commenting the above line out */

#ifndef HI_IQ_H
#define HI_IQ_H

#ifdef WIN_NT
#define WIN_NT_TRUE 100
/* WIN_NT_TRUE is used in program to control the mail output, it will be used in
	combination with output format indicated by form variable */

#include <direct.h>
#include <process.h>
#else
#define WIN_NT_TRUE 0
#include <unistd.h>
#include <sys/mman.h>
#endif

#define _XOPEN_SOURCE
#include <unistd.h>
#include <ctype.h>
#include <fcntl.h>
#include <malloc.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "gd.h"

#define RESULT_N	32
#define BUFFER_N	4096
#define STRING_N	1024
#define COLOR_N		128
#define LIMIT_N		5
#define BONDARY         "--------BoNdArY--------"

typedef struct {
	char * name;
	char * type;
	char * path;
} PATH;
/* PATH for path type configuration */

typedef struct {
	char * value;
	char * name_sas;
	char * name_html;
	char * name_pop;
	char * prompt;
	char * type1;
	char * type2;
	char * note;
} NAME;
/* NAME for variable type configuration */

typedef struct {
	NAME * name_ptr;
	char * label;
	char * value;
} VARI;
/* VARI for variables passed from user */

typedef struct {
        char * number;
        char * username;
        char * password;
        char * prompt;
        char * status;
        char * group;
} USER;
/* USER for user information */

typedef struct {
        char * key;
        char * rep;
        char ** replist;
        int    type;
/* type=0 -- regular replace,
   type=1 -- list replace */
} REPLACE;
/* REPLACE for replacement in return files */

typedef struct {
        char * type;
        char * key;
        char * value;
        char ** script;
} FUNC;
/* FUNC for funtion definition */

typedef struct CROS {
	int    number;
	char * value;
	struct CROS * cros_ptr;
} CROS;
/* CROS for calculate categories of cross variable */

typedef struct CROSS {
	int 	id;
	char	* name;
	char 	* value;
        char ** script;
	NAME * name_ptr;
} CROSS;

/* MAP for xml out element tag */
typedef struct {
	int 	id;
	char 	* sas_data_column;
	char 	* xml_element_name;
	char 	* value_of_name_element;
	char 	* plural_flag;
} MAP;

#define HTML_HEAD       1
#define HTML_TAIL       2
#define SAS_LST         3
#define SAS_PROG        4
#define SAS_LOG         5
#define SAS_DAT         6
#define SAS_INCLUDE     7

/* hi_iq.c 
	main entry of the program */

/* hi_iq_util.c */
void   test_out(int i);
FILE * file_open(char *key, int flag);
void   query_save(char *qt);
void   query_vari(char *qt);
void   h_vari_bld(char **qt);
char * find_label(char *name, char *value);
char * find_label_dynamic(char *name, char *value, int *dynamic);
char * find_path(char *key);
void   reset_path(char *key, char *newvalue);
NAME * find_name(char *key, int flag);
NAME ** find_name_group(char *key, int flag, int * c);
NAME * find_name_type(char *key, int flag, int type);
void   de_amp(char *qt);
char   x2c(char *what);
char * escape_special(char *);
void   unescape_url(char *url);
void   plustospace(char *str);
void   query_clean(char *qt, int flag);
char * find_config(char *qt);
void   query_conf(char **qt);
void   h_path_bld(char *tmp);
void   cl_amp(char *tmp);
void   h_name_bld(char *tmp);
void   conf_bld(char **path);
char * find_stdpop(int f);
VARI **find_vari(char *key, int flag, int t, int *c);
char * find_format(char *name, char *value, char *str);
char * de_space(char *tmp);
void   hbase_clear();
void   hbase_warning(int i);
void   hbase_error(int i, char * str);
void   mall_print();
time_t * get_last_modified(char * key);

/* hi_iq_sas.c */
char * get_sasname(char *str);
void   avoid_conflict();
void   sas_avoid_conflict();
int filterExcluded(NAME *name);
void   sas_bld();
void   sas_no_obs(FILE * sas);
void   sas_func_def(FILE *sas);
void   sas_minus1(FILE *sas);
void   sas_out(FILE *sas, char *dy, char *dl, int small);
void   sas_out_l(FILE *sas, char *dy, char *dl);
void   sas_out_3(FILE *sas, char **dx, char *l_name, int length, char* snum, char * spop);
char * data_where_cr(char * dw);
void   sas_select(FILE *sas);
void   sas_vari_bld(VARI **v_ptr, FILE *sas, int c, int flag);
char * sas_type2_cut(char *buf, char *back);
char * sas_type2_label(char *value, char *name, char *buf);
void   sas_type2(VARI **v_ptr, FILE *sas, int c, int out);
void   sas_type5(VARI **v_ptr, FILE *sas, int c, int out);
void   sas_type1(VARI **v_ptr, FILE *sas, int c, int out);
void   sas_cross(char *cross1, char *cross2);
void   sas_find_cross(char *cross1, char *cross2, char* p1, char* p2);
void   sas_group_bld(VARI *v_ptr, FILE *sas);
void   sas_group_type3(VARI *v_ptr, FILE *sas, int i);
void   sas_pop_type3(VARI *v_ptr, FILE *sas, int i);
void   sas_pop_select(FILE *sas, char *name);
void   sas_lbl_out(FILE *, char *, char *, char **, char *, int, char*, char*);
void   sas_lbl_out2(FILE *, char *, char *, char **, char *, int, char*, char*);
CROSS ** find_crosses(int *);
CROSS ** find_crosses_xml(int *);
void   sas_group(FILE * sas);
void   sas_cross_bld(FILE * sas, char *cross, char *pop);
void   sas_stdpop(FILE * sas);
NAME * get_crossVar_f(char *);

/* hi_iq_table.c */
void   enc_note();
int    dat_get(char ***dx1t, char ***dx2t, char ***dyct, char *value);
int    dat_get2(char ***dx1t, char ***dyct, char *value);
char ***    dat_get3(int *, int *);
void   cross_in(CROS **root, char *value);
void   cross_list(char ***cxt, CROS *root);
void   dat_cross(char **dx1, char **dx2, char ***cx1t, char ***cx2t, int *c1, int *c2, int n);
int    dat_find(char **dx1, char **dx2, char *key1, char *key2, int n, int flag);
char * cross_back(char *cross, char*buf);
void   tb_sub(char **dx1, char **dx2, char **dyc, char **cx1, char **cx2, char *lbl, int pb, int lb, int ps, int ls, int pc, int lc, int n);
void   tb_out();
void   tb_out2();
void   tb_lbl_out(char *value, char *lbl);
void   std_html(int flag, int pre);
char * tb8_space(char *str);
void   tb8_out(int func);
char * to_lower(char *str);
void   tb8_body(char *rec);
void   tb9_body(char *rec);

/* hi_iq_gif.c */
double dyc_to_dy(char *dy);
void   gif_out();
int   gif_graph(FILE *gif, char **dx1, char **dx2, double *dy, int j, int n);
gdImagePtr gif_get_map();
void gif_map(gdImagePtr im, char **dx1, char **dx2, double *dy, int j, int n, int s);
int  gif_map_county(char *str, char **dx1, double *dy, int *x, int *y, int s, int n, char *name);
void gif_map_legend(gdImagePtr im, int *color, int n);
void gif_bar(gdImagePtr im, char **dx1, char **dx2, double *dy, int j, int n, int s);
void gif_bar2(gdImagePtr im, char **dx1, char **dx2, double *dy, int j, int n, int s);
void gif_dot_line(gdImagePtr im, int x0, int y0, int x1, int y1, int color);
int  gif_exist(char **dxc, char *dx2, int n);
void gif_line2(gdImagePtr im, char **dx1, char **dx2, double *dy, int j, int n, int s);
double gif_line2_find(char *dxb, char *dxc, char **dx1, char **dx2, double *dy, int n, int s);
void gif_line(gdImagePtr im, char **dx1, char **dx2, double *dy, int j, int n, int s);
int gif_line_next(char **dx1, char **dx2, char *dxc, int ptr, int n);
void gif_pie(gdImagePtr im, char **dx1, char **dx2, double *dy, int j, int n, int s);
void gif_box(gdImagePtr im, int x0, int y0, int xl, int yl, int border, int color);
void gif_color(gdImagePtr im, int *color, int n);
void gif_fill(gdImagePtr im, int x, int y, int border, int color);
void gif_legend(gdImagePtr im, char **dx, int *color, int n, int flag, int x0);
void gif_title(gdImagePtr im, int j, int p);
void gif_label(gdImagePtr im, double ma, double mi);

/* hi_iq_mail.c */
void mail_sub(FILE * mail, char ** dx1, char ** dx2, char **dyc, char ** cx1, char ** cx2, int c1, int c2, int n);
void mail_tb(FILE *mail, char *value, char *lbl);
void mail_lbl_out(char *value, char *lbl);
void mail_out();
void mail_out_std();
void detach();
void mail_select(FILE *mail);
void mail_vari_bld(VARI **v_ptr, FILE *mail, int c, int flag);
void mail_type2(VARI ** v_ptr, FILE *mail, int c);
void mail_type1(VARI ** v_ptr, FILE *mail, int c);
void mail_group_typ3(VARI ** v_ptr, FILE *mail, int l);
void mail_group_bld(VARI * v_ptr, FILE *mail);
void mail_group(FILE *mail);

/* hi_iq_comma.c */
void comma_sub(FILE * mail, char ** dx1, char ** dx2, char **dyc, char ** cx1, char ** cx2, int c1, int c2, int n);
void comma_tb(FILE *mail, char *value, char *lbl);
void comma_out();
void comma_select(FILE *mail);
void comma_vari_bld(VARI **v_ptr, FILE *mail, int c, int flag);
void comma_type2(VARI ** v_ptr, FILE *mail, int c);
void comma_type1(VARI ** v_ptr, FILE *mail, int c);
void comma_group_typ3(VARI ** v_ptr, FILE *mail, int l);
void comma_group_bld(VARI * v_ptr, FILE *mail);
void comma_group(FILE *mail);
void comma_cross_bld(FILE *mail, char *name);

/* hi_iq_excel.c */
void excel_sub(FILE * mail, char ** dx1, char ** dx2, char **dyc, char ** cx1, char ** cx2, int c1, int c2, int n);
void excel_tb(FILE *mail, char *value, char *lbl);
void excel_out();
void excel_select(FILE *mail);
void excel_vari_bld(VARI **v_ptr, FILE *mail, int c, int flag);
void excel_type2(VARI ** v_ptr, FILE *mail, int c);
void excel_type1(VARI ** v_ptr, FILE *mail, int c);
void excel_group_typ3(VARI ** v_ptr, FILE *mail, int l);
void excel_group_bld(VARI * v_ptr, FILE *mail);
void excel_group(FILE *mail);
void excel_cross_bld(FILE *mail, char *name);

/* hi_iq_group.c */
void group_tb_bld();
void group_conf(char * qt);
void h_group_bld(char * tmp);

/* hi_iq_drill.c */
char * query_drill(char * qt);
void    std_htmltail(char *name);
void   sequence_erase(char *key);
void   sequence_bld();
void   sequence_compress();
void   sequence_select();
char * bld_pre_query();

/* hi_iq_user.c */
USER * find_user(char * key);
void   query_user();
void   put_file(char *name, int flag, char ** key, char ** rep);
void   save_user();
int	user_check(int pass);
int	role_check();
void   deny_access();

/* hi_iq_file.c */
void   put_file_rep(char *name, int flag, REPLACE **repla);
void   put_file_norep(char *name);

/* hi_iq_func.c */
void   func_test_out();
FUNC * find_func(FUNC ** func, char * key);
void   sas_ci_95(FILE *sas);
char * replace_line(char *, char *, REPLACE **);
char ** passThrough( int * c) ;
char ** filterExclude( int * c) ;

/* hi_iq_virtual.c */
void   plain_out();

/* hi_iq_xml.c */
void   xml_out();
void   xml_out2();
void   xml_error_out();
void   xml_parameters();
void   xml_dataset();
void   xml_measure();
void   xml_query();

void   xml_lbl_out(char * value, char * lbl);
void   xml_label(char **dx1, char **dx2, char **cx1, char **cx2, char *lbl, int c1, int c2, int n);
void   xml_enc_note();
void   xml_label2();
void   xml_celldata2();
void   xml_sequence_select();

/* hi_iq_survey.c */
void   sas_bld_survey();
void   sas_special_survey(FILE *sas, FUNC **func);
void   sas_select_survey(FILE *);
void   sas_vari_flag(VARI ** vari_p, FILE *sas, int c, int flag);
void sas_select_after_survey(FILE * sas);
char*  sas_ageAdjustedFilter();
#endif
