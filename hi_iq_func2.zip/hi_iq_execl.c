/* HI-IQ System, the High Information Internet Query System,
	Copyright 1995, 1996, 1997, 1998 Utah Office of Health Data Analysis.

	hi_iq_excel.c 05/15/03
	Support tab output format for loading into Excel.

	We provide the interactive interface to make your data available
	to public through Internet.
*/

#include "hi_iq.h"
#include "hi_iq_var.h"

extern int _flag_ ;

/*	function:	excel_sub
	form the sub table for excel delimited output.

	input:	FILE * excel:	output stream file.
	  char ** dx1:	  cross variable 1 (row variable)  values.
	  char ** dx2:	  cross variable 2 (column variable)  values (may be NULL).
	  char ** dyc:	  output values conrresponding to dx1 and dx2 values.
	  char ** cx1:	  unique cross variable 1 category values.
	  char ** cx2:	  unique cross variable 2 category values.
	  int c1:	  # of cross variable 1 categories.
	  int c2:	  # of cross variable 2 categories.
	  int n:	  # of values in dyc.
		actually dx1, dx2, and dyc have the same length.
	output:	the sub table will be sent to FILE * excel.
	no return value.
*/
 void excel_sub(FILE * excel, char **dx1, char **dx2, char **dyc, char **cx1, char **cx2, 
	int c1, int c2, int n) {
	int i, o;
	char *tmp, *cross1, *cross2;
	NAME *n_ptr1=NULL, *n_ptr2=NULL;

	if (cross1=find_path("cross1")) {
		if (!(n_ptr1=find_name(cross1, 1))) cross1=NULL;
		else cross1=n_ptr1->name_html;
	}
	if (cross2=find_path("cross2")) {
		if (!strcmp(cross2, "none")) cross2=NULL;
		else if (!(n_ptr2=find_name(cross2, 1))) cross2=NULL;
			else cross2=n_ptr2->name_html;
	}

	tmp=find_label(cross1, cx1[c1]);
	tmp=tmp? tmp : cx1[c1];
	fprintf(excel, "\n%s", tmp);
	if (cross2) {
		for(i=0; i<c2; i++) {
			o=dat_find(dx1, dx2, cx1[c1], cx2[i], n, 1);
			fprintf(excel, ",%s", o==-1? "." : dyc[o]);
		}
	} /* if (cross2) */
	else {
		i=dat_find(dx1, dx2, cx1[c1], NULL, n, 0);
		fprintf(excel, ",%s", i==-1? "." : dyc[i]);
	} /* else */
}

/*	function:	excel_tb
		form the table for excel delimited output.
	input:	FILE * excel:	output stream file.
	char * value:	cross variable 3 categorical value.
	char *lbl:  cross variable 3 label name.
	output: sent to FILE * excel.
		no return value.
*/
void excel_tb(FILE *excel, char *value, char *lbl) {
	int  c1, c2, i, j, n;
	char **dx1, **dx2, **cx1, **cx2, **dyc;
	char *tmp, *tmp2, *cross1, *cross2;
	char str[BUFFER_N];
 	NAME *n_ptr1=NULL, *n_ptr2=NULL;

	if (cross1=find_path("cross1")) {
		if (!(n_ptr1=find_name(cross1, 1))) cross1=NULL;
		else cross1=n_ptr1->name_html;
	}
	if (cross2=find_path("cross2")) {
		if (!strcmp(cross2, "none")) cross2=NULL;
		else if (!(n_ptr2=find_name(cross2, 1))) cross2=NULL;
			else cross2=n_ptr2->name_html;
	}

	if (!(n=dat_get(&dx1, &dx2, &dyc, value))) return;
	dat_cross(dx1, dx2, &cx1, &cx2, &c1, &c2, n);

	tmp=find_path("func");
	sprintf(str, "func%s", tmp);
	if ((tmp=find_path(str))) 
		fprintf(excel, "\n%s", tmp);
	fprintf(excel, "\n\t %s", lbl);
	if ((strstr(tmp, "Age-adjusted"))) {
		tmp2=find_stdpop(1);
		fprintf(excel, "\n(Standard population is %s.)", tmp2);
	}
	fprintf(excel, "\n");

	if (n_ptr2) fprintf(excel, "\n\t%s", n_ptr2->prompt);
	
	if (n_ptr1) {
		fprintf(excel, "\n%s", n_ptr1->prompt);

		for(i=0; i<c2; i++) {
			tmp=find_label(cross2, cx2[i]);
			tmp=tmp? tmp : cx2[i];
			fprintf(excel, "\t%s", tmp);
		}
	}
	
	for (i=0; i<c1; i++) {
		excel_sub(excel, dx1, dx2, dyc, cx1, cx2, i, c2, n);
	}

        for (j=0; j<n; j++) {
                if (dx1[j]) free(dx1[j]);
                if (dyc[j]) free(dyc[j]);
        }
        free(dx1); free(dyc);; 
        if (dx2) {
                for (j=0; j<n; j++) if (dx2[j]) free(dx2[j]);
        }
        free(dx2);
}

/*	function:	excel_out
		entry point for excel delimited output.
	input:	none
	output:	for Windows NT, send to standard output, 
		for Unix, send through email by 'sendmail'
	no return value.
*/
void excel_out() {
	char * tmp, *tmp1, *tmp2, *cross2, buf[BUFFER_N], buf2[BUFFER_N];
	int flag=0;
	FILE * format, * excel;
    	NAME *  n_ptr;

#ifdef WIN_NT
	excel=stdout;
#else
/* form the email header */
	if (!(tmp=find_path("email_bin"))) hbase_error(28, "email_bin");
	if (!(tmp2=find_path("recipient"))) hbase_error(29, "recipient");
	sprintf(buf, "%s %s ", tmp, tmp2);
	if (!(excel=popen(buf, "w"))) hbase_error(30, buf);
	tmp=find_path("subject");
	fprintf(excel, "Subject: %s\n", tmp? tmp :  "none");
	tmp=find_path("reply_to");
	fprintf(excel, "Reply-To: %s\n", tmp? tmp : "none");
	tmp=getenv("REMOTE_USER");
	tmp2=getenv("REMOTE_HOST");
	fprintf(excel, "Supposedly-From: %s%s%s\n\n", tmp? tmp : "",
			tmp? "@" : "", tmp2? tmp2 : "");
	fprintf(excel, "[This message was sent through IBISQ.]\n--\n");
#endif
	
	excel_select(excel);
	excel_group(excel);
	fprintf(excel, "\n--\n");

        if (tmp2=find_path("cross2")) {
                if (!strcmp(tmp2, "none")) cross2=NULL;
                else {
                        if (!(n_ptr=find_name(tmp2, 1))) cross2=NULL;
                        else {
                                cross2=n_ptr->name_sas;
                        }
                }
        }

	if (!_cross_3 || !cross2 || !strcmp(cross2, "detail")) {
		excel_tb(excel, "", "");
		return;
	}
		
	if ((tmp=find_path("workpath"))) {
		tmp1=get_sasname(buf);
		sprintf(buf2, "%s/%s%s.lbl", tmp, tmp1, n_ptr->name_html);
		if ((format=fopen(buf2, "r"))) flag=1;
	}

	if (!flag) {
		sprintf(buf2, "%s.lbl", n_ptr->name_html);
		if (!(format=file_open(buf2, 0))) hbase_error(42, buf2);
	}

	flag=1;
	while (!feof(format)) {
		if (!(tmp=fgets(buf, BUFFER_N, format))) break;
		if (!(tmp1=strchr(tmp, '~'))) 
			if (!(tmp1=strchr(tmp, ' ' ))) continue;
		tmp1[0]=0;
		tmp1++;
		if (tmp[0]=='.' || tmp[0]=='~' || tmp[0]==' ') tmp[0]='\0';
		else if (flag) {
                	_cross_2=malloc(strlen(tmp2)+1);
                	strcpy(_cross_2, tmp2);
                	strcpy(tmp2, _cross_3);
			flag=0;
		}
		sprintf(buf2, " for %s=%s", n_ptr->prompt, tmp1);
		excel_tb(excel, tmp, buf2);
	}
	fclose(format);
#ifndef WIN_NT
	pclose(excel);
#endif
	return;
}

/*	funciton: excel_select
		put the query condition before the output result, so user can know what they were querying.
	input: FILE * excel:	output stream file.
	output:	write the query condition to output file.
	no return value.
*/
void excel_select(FILE * excel) {
	char * tmp;
	int i, j, c, flag=0;
	VARI ** vari_ptr;

	tmp=find_path("dataset");
	fprintf(excel, "\nQuery: %s", tmp? tmp : "no dataset name");

	_flag_ = 0;
	for (i=0; i<h_name_i; i++) {
		j = atoi(h_name[i]->type2);
		if (j==0 || j==1) {
			if ((vari_ptr=find_vari(h_name[i]->name_html,1,j,&c))) {
				if (c<=0 || !strlen(de_space(vari_ptr[0]->value))) continue;
				excel_vari_bld(vari_ptr, excel, c, flag);
				free(vari_ptr);
				vari_ptr=NULL;
				flag = 1;
				_flag_ = flag;
			}
		}
	}
	fflush(excel);
}

/*	function:	excel_vari_bld
		form the query condition at variable level.
	input:	VARI ** v_ptr:	values for a specific variable.
				FILE * excel: output stream file.
				int c:		# of values.
				int flag:	indicate whether this variable is the first in queyr condition or not
					flag=0:	first
					flag=1: not first.
	output:	sent to FILE * excel .
	no return value.
*/
void excel_vari_bld(VARI ** v_ptr, FILE * excel, int c, int flag) {
	int j;
	char str[BUFFER_N];
	
	j = atoi(v_ptr[0]->name_ptr->type2);
	if (j==2) {
		strcpy(str, v_ptr[0]->value);
		if (strlen(de_space(str))==0) return;
	}
	fprintf(excel, "\n%s ( ", flag ? "and " : "");
	switch(j) {
		case 0: excel_type1(v_ptr, excel, c);
			break;
		case 1: excel_type2(v_ptr, excel, c);
			break;
		case 9: break;
		default: hbase_error(17, v_ptr[0]->name_ptr->type2);
			break;
	}
	fprintf(excel, " )");
}

/*	function: excel_type2
		form query condition for non-categorical variable.
	input:	VARI ** v_ptr:	values for a specific variable.
				FILE * excel:	output stream file.
				int c:		# of values.
	output: sent to FILE * excel output file.
	no return value.
*/
void excel_type2(VARI ** v_ptr, FILE * excel, int c) {
	char * name, *name2, * tmp, *tmp2, *tmp3, str[BUFFER_N];
	int i, j=1, k, l=0;

	if (!strcmp(v_ptr[0]->name_ptr->type1, "char")) l=1;
	name=v_ptr[0]->name_ptr->prompt;
	name2=v_ptr[0]->name_ptr->name_sas;
   for (k=0; k<c; k++) {
	if (k>0) fprintf(excel, "");
	tmp=v_ptr[k]->value;
	if (strlen(tmp)>BUFFER_N) hbase_error(18, tmp);
	tmp2=v_ptr[k]->label;
	if (tmp2) {
		if (l) fprintf(excel, "%s%s = '%s'", k ? "\n or " : "", name, tmp2);
		else fprintf(excel, "%s%s = %s", k ? "\n or " : "", name, tmp2);
		j=0;
	}
	else {
		fprintf(excel, "%s", k ? "\n or " : "");
		j=1;
	}
	for (i=0; ; i++) {
		if (!(tmp=sas_type2_cut(tmp, str))) break;
		if (i>0) fprintf(excel, "");
		if (!(tmp2=strchr(str, '-'))) {
			tmp2=de_space(str);
			if (j) {
				if (l) fprintf(excel, "%s(%s=:'%s')", i ? "\n or " : "", 
				name, tmp2);
				else fprintf(excel, "%s(%s=%s)", i ? "\n or " : "", 
				name, tmp2);
			}
		}
		else {
			tmp2[0]=0;
			tmp3=de_space(tmp2+1);
			tmp2=de_space(str);
			if (j) { 
				if (l) fprintf(excel, "%s('%s'<=:(%s)<=:'%s')", i ? "\n or " : "", 
				tmp2, name, tmp3);
				else fprintf(excel, "%s(%s<=(%s)<=%s)", i ? "\n or " : "", 
				tmp2, name, tmp3);
			}
		}
	}
   }
}

/*	function: excel_type1
		form query condition for categorical variable.
	input:	VARI ** v_ptr:	values for a specific variable.
				FILE * excel:	output stream file.
				int c:		# of values.
	output: sent to FILE * excel output file.
	no return value.
*/
void excel_type1(VARI ** v_ptr, FILE * excel, int c) {
	char * tmp;
	int i, j=0;

	if (!strcmp(v_ptr[0]->name_ptr->type1, "char")) j=1;
	tmp=v_ptr[0]->name_ptr->prompt;
	if (j) {
		for (i=0; i<c; i++) {
			if (i>0) fprintf(excel, "");
			fprintf(excel, "%s(%s = '%s')", i ? "\n or " : "", tmp, 
				v_ptr[i]->label ? v_ptr[i]->label : v_ptr[i]->value);
		}
	}
	else {
		for (i=0; i<c; i++) {
			if (i>0) fprintf(excel, "");
			fprintf(excel, "%s(%s = %s)", i ? "\n or " : "", tmp, 
				v_ptr[i]->label ? v_ptr[i]->label : v_ptr[i]->value);
		}
	}
}

/*	function:	excel_group_type3
		build the group for groupable variables (type=3)
	input:		VARI * vari_p:		variable need grouping.
					FILE * excel:	output stream file.
					int l:						char or num variable indicator
						l=1:	char variable
						l=0:	num variable
	output:	sent to FILE * excel.
	no return value.
*/
void excel_group_type3(VARI * vari_p, FILE * excel, int l) {
	int i;
	char *tmp, *tmp2, *tmp3, *name, *prompt, str[BUFFER_N];

	tmp=strcpy(str, vari_p->value);
	name=vari_p->name_ptr->name_sas;
	prompt=vari_p->name_ptr->prompt;
	for (i=0; ; i++) {
		if (!(tmp=sas_type2_cut(tmp, str))) break;
		if (i>0) fprintf(excel, "");
		if (!(tmp2=strchr(str, '-'))) {
			if (!(tmp2=strchr(str, '+'))) {
				tmp2=de_space(str);
				if (_flag_ > 1) {
					if (l) fprintf(excel, "%s(%s=:'%s')", i ? " \n or " : "", prompt, tmp2);
					else fprintf(excel, "%s(%s=%s)", i ? "\n or " : "", prompt, tmp2);
				}
			}
			else {
				tmp2[0]=0;
				tmp2=de_space(str);
				if (_flag_ > 1) {
					if (l) fprintf(excel, "%s(%s>=:'%s')", i ? "\n or " : "", prompt, tmp2);
					else fprintf(excel, "%s(%s>=%s)", i ? "\n or " : "", prompt, tmp2);
				}
			}
		}
		else {
			tmp2[0]=0;
			tmp3=de_space(tmp2+1);
			tmp2=de_space(str);
			if (_flag_ > 1) {
				if (l) fprintf(excel, "%s('%s' <=: %s <=: '%s')", i? "\n or " : "", tmp2, prompt, tmp3);
				else fprintf(excel, "%s(%s <= %s <= %s)", i ? "\n or " : "", tmp2, prompt, tmp3);
			}
		}
	} /* for i */
}

/*	function:	excel_group_bld
		build group for a specific groupable variable.
	input:	VARI * vari_p:		variable need grouping.
				FILE * excel:	output stream file.
	output:	sent to output file.
	no return value.
*/
void excel_group_bld(VARI * vari_p, FILE * excel) {
	char buf1[BUFFER_N], buf2[BUFFER_N], *tmp;
	int i, j, d;
	VARI ** v_ptr;

	strcpy(buf1, vari_p->value);
	strcpy(buf2, vari_p->name_ptr->name_html);
	if (tmp=strstr(buf2, "_f")) {
		tmp[0]=0;
		strcat(buf2, buf1);
		v_ptr=find_vari(buf2, 1, 3, &d);
		if (v_ptr && d>0) {
			j= (!(strcmp(v_ptr[0]->name_ptr->type1, "char")));
			fprintf(excel, "\n%s (", _flag_ ? "and " : "");
			_flag_+=2;

			for (i=0; i<d; i++) {
				fprintf(excel, "%s", i ? "\n or " : "");
				excel_group_type3(v_ptr[i], excel, j);
			}
			_flag_-=2;
			if (!_flag_) _flag_=1;
			fprintf(excel, " )");
		}
		free(v_ptr);
	}
}

/*	function:	excel_group
		build group for all groupable variables.
	input:	FILE * excel:	output stream file.
	output:	sent to output file.
	no return value.
*/
void excel_group (FILE *excel) {
	int i, j, c;
	VARI ** vari_p;

	for (i=0; i<h_name_i; i++) {
		j=atoi(h_name[i]->type2);
		if (j==8) {
			vari_p=find_vari(h_name[i]->name_html, 1, j, &c);
			if (c<=0 || !vari_p) continue;
			excel_group_bld(vari_p[0], excel);
			free(vari_p);
		}
	}
	fflush(excel);
}
		
