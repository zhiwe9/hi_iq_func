/* HI-IQ System, the High Information Internet Query System,

	Copyright 1995, 1996, 1997, 1998 Utah Office of Health Data Analysis.

	hi_iq_xml.c	12/11/03
	Format the query results into XML tables.

	We provide the interactive interface to make your data available
	to public through Internet.
*/

#include "hi_iq.h"
#include "hi_iq_var.h"

char ** detail;
int detail_i=0;

void xml_sas_out(FILE *sas, char ** dx, int length) {
	char * tmp, buf[BUFFER_N];
	int i, crosses_cnt;
	CROSS ** crosses;

        crosses=find_crosses(&crosses_cnt);
	fprintf(sas, "\n\n/* Following codes from xml_sas_out() */");
	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n set tmp;");
	fprintf(sas, "\n keep ");
	for (i=0; i<crosses_cnt; i++) {
	  fprintf(sas, " %s ", crosses[i]->name_ptr->name_sas);
	}
	for (i=0; i<length; i++) {
	  strcpy(buf, dx[i]);
	  if (tmp=strchr(de_space(buf), ' ')) tmp[0]=0;
	  fprintf(sas, " %s ", buf);
	}
	fprintf(sas, ";");
	fprintf(sas, "\n run;");

	tmp=get_sasname(buf);
	fprintf(sas, "\n\n libname xmlout xml '%s.xml';", tmp);
	fprintf(sas, "\n proc copy in=work out=xmlout;");
	fprintf(sas, "\n select tmp;");
	fprintf(sas, "\n run;");

	detail=dx;
	detail_i=length;
}

void xml_sas_label() {
	CROSS ** crosses;
	int i, j, crosses_cnt, rows, cols;
	char buf[BUFFER_N], buf2[BUFFER_N], *tmp, *tmp2;
	FILE * format;
	FUNC * func_p;

        crosses=find_crosses_xml(&crosses_cnt);

	for (i=0; i<crosses_cnt; i++) {
	  if (crosses[i] && crosses[i]->name_ptr) {
	    printf("\n<CROSS_VARIABLE ID=\"%d\">%s", i+1, crosses[i]->name_ptr->name_sas);
	    printf("\n<TITLE row=\"0\" column=\"%d\">%s</TITLE>", i, escape_special(crosses[i]->name_ptr->prompt));
	  }

  	  tmp2=get_sasname(buf);
	  sprintf(buf2, "%s%s.lbl", tmp2, crosses[i]->name_ptr->name_sas);
	  if (!(format=fopen(buf2, "r"))) {
		sprintf(buf2, "%s.lbl", crosses[i]->name_ptr->name_sas);
		if (!(format=file_open(buf2, 0))) continue;
	  }

	  while (!feof(format)) {
		if (!(tmp=fgets(buf, BUFFER_N, format))) break;
		if (!(tmp2=strchr(tmp, '~'))) 
			if (!(tmp2=strchr(tmp, ' ' ))) continue;
		tmp2[0]=0;
		tmp2++;
		if (tmp2[strlen(tmp2)-1]=='\n') tmp2[strlen(tmp2)-1]=0;
		printf("\n<LABEL name=\"%s\" id=\"%d\" value=\"%s\">", 
	            crosses[i]->name_ptr->name_sas, i+1, tmp);
		printf("\n%s\n</LABEL>", tmp2);
	  }
	  fclose(format);
	  printf("\n</CROSS_VARIABLE>");
	}

	func_p=(FUNC *) find_func(h_func, "out_detail");
	sprintf(buf2, "xml%s.lbl", func_p->value);
	if (!(format=file_open(buf2, 0))) {
	  func_p=(FUNC *) find_func(h_func, "xml_out_map_file");
	  if (!(format=file_open(buf2, 0))) {
	    return;
	  }
	}
	for (i=0; i<detail_i; i++) {
	  strcpy(buf, detail[i]);
	  if (tmp=strchr(de_space(buf), ' ')) tmp[0]=0;
 	  printf("\n<STAT_RESULT ID=\"%d\" name=\"%s\">", i+1, buf);

	  if (!(tmp=fgets(buf, BUFFER_N, format))) break;
	  tmp=strchr(buf, ' '); 
	  printf("\n %s", tmp? tmp++ : buf);
	  printf("</STAT_RESULT>\n");
	}
}

void xml_parameters() {
	int i;

	printf("\n<PARAMETERS>"); fflush(stdout);
	for (i=0; i<h_path_i; i++) {
	  if (!strcmp(h_path[i]->type, "r")) {
	    printf("\n\t<PARAMETER>"); fflush(stdout);
	    printf("\n\t\t<NAME>%s</NAME>", escape_special(h_path[i]->name));
	    printf("\n\t\t<VALUE>%s</VALUE>", escape_special(h_path[i]->path));
	    printf("\n\t</PARAMETER>"); fflush(stdout);
	  }
	}
	for (i=0; i<h_vari_i; i++) {
	    printf("\n\t<PARAMETER>"); fflush(stdout);
	    printf("\n\t\t<NAME>%s</NAME>", escape_special(h_vari[i]->name_ptr->name_html));
	    printf("\n\t\t<VALUE>%s</VALUE>", escape_special(h_vari[i]->value));
	    printf("\n\t</PARAMETER>"); fflush(stdout);
	}
	//printf("\n%s", bld_pre_query());
	printf("\n</PARAMETERS>");
}

void xml_filter_used() {
	int i;
	printf("\n<FILTER_USED>");
	printf("\n<URL_QUERY_STRING>");
	printf("\n%s", escape_special(bld_pre_query()));
	printf("\n</URL_QUERY_STRING>");

	printf("\n<VARIABLES>");
	for (i=0; i<h_vari_i; i++) {
	  printf("\n<VARIABLE>");
	  printf("\n<NAME_HTML>");
	  printf("\n%s", escape_special(h_vari[i]->name_ptr->name_html));
	  printf("\n</NAME_HTML>");
	  printf("\n<NAME_SAS>");
	  printf("\n%s", h_vari[i]->name_ptr->name_sas);
	  printf("\n</NAME_SAS>");
	  printf("\n<TITLE>");
	  printf("\n%s", escape_special(h_vari[i]->name_ptr->prompt));
	  printf("\n</TITLE>");
	  printf("\n<VALUE>");
	  printf("\n%s", escape_special(h_vari[i]->value));
	  printf("\n</VALUE>");
	  printf("\n</VARIABLE>");
	}
	printf("\n</VARIABLES>");
	printf("\n</FILTER_USED>");
}

void xml_dataset() {
	char * dst=find_path("sasdata");
	char buf[BUFFER_N];
	char * mtime=NULL;
	time_t * lm ;

	printf("\n<DATASET>");
	printf("\n<NAME>");
	printf("%s", escape_special(dst));
	printf("</NAME>");
	printf("\n<TITLE>");
	printf("%s", escape_special(find_path("dataset")));
	printf("</TITLE>");

	strcpy(buf, dst);
	strcat(buf, ".sas7bdat");
	lm=get_last_modified(escape_special(buf));
	mtime=ctime(lm);
	printf("\n<MODIFIED_DATE>");
	printf("%s", mtime? de_space(mtime):"");
	printf("</MODIFIED_DATE>");
	printf("\n<LAST_MODIFIED>");
	printf("%ld", getUnixEpochSecond(lm));
	printf("</LAST_MODIFIED>");

	printf("\n</DATASET>");
}
void xml_measure() {
	char buf[BUFFER_N];
	char * tmp=find_path("func");

	sprintf(buf, "func%s", tmp);
	tmp=find_path(buf);

	printf("\n<MEASURE>");
	printf("\n%s", escape_special(tmp));
	printf("\n</MEASURE>");
}
void xml_query() {
	//printf("\n<QUERY>");
	xml_parameters();
	xml_dataset();
/*
	xml_measure();
	xml_sequence_select();
*/
}

void xml_out() {
	char * tmp, *tmp1, *tmp2, *cross2, buf[BUFFER_N], buf2[BUFFER_N];
	int flag=0, dynamic, i;
	FILE * format;
    	NAME *  n_ptr, *n_ptr2;

	//printf("\n</QUERY>");

	printf("\n<RECORDS>");
    if (tmp2=find_path("cross2")) {
         if (!strcmp(tmp2, "none")) cross2=NULL;
         else {
              if (!(n_ptr=find_name(tmp2, 1))) cross2=NULL;
              else {
		  i=atoi(n_ptr->type2);
		  if (i==8 || i==10) n_ptr2=get_crossVar_f(tmp2);
		  if (n_ptr2) n_ptr=n_ptr2;
                  cross2=n_ptr->name_sas;
              }
         }
    }

	if (!_cross_3 || !cross2 || !strcmp(cross2, "detail")) {
		//xml_sas_label();
		//std_html(7, 0);
		xml_lbl_out("", "");
		printf("\n</RECORDS>\n");
		return;
	}
		
	tmp1=get_sasname(buf);
	sprintf(buf2, "%s%s.lbl", tmp1, n_ptr->name_html);
	if ((format=file_open(buf2, 0))) {
	  flag=1;
	  dynamic=1;
	}
	else dynamic=0;

	if (!flag) {
		sprintf(buf2, "%s.lbl",  n_ptr->name_html);
		if (!(format=file_open(buf2, 0))) hbase_error(42, buf2);
	}

	flag=1;
	while (!feof(format)) {
		if (!(tmp=fgets(buf, BUFFER_N, format))) break;
		if (!(tmp1=strchr(tmp, '~'))) 
			if (!(tmp1=strchr(tmp, ' ' ))) continue;
		tmp1[0]=0;
		tmp1++;
		if (tmp[0]=='~' || tmp[0]==' ') tmp[0]='\0';
		else if (flag) {
                	_cross_2=malloc(strlen(tmp2)+1);
                	strcpy(_cross_2, tmp2);
                	strcpy(tmp2, _cross_3);
			flag=0;
		}
		sprintf(buf2, "<DIMENSION><NAME>%s</NAME><TITLE>%s</TITLE><VALUE>%s<TITLE>%s</TITLE></VALUE></DIMENSION>", 
			escape_special(n_ptr->name_html), 
			escape_special(n_ptr->prompt), 
			(dynamic && tmp[0]!='.')? escape_special(tmp1):escape_special(tmp), 
			escape_special(tmp1));
		xml_lbl_out(tmp, buf2);
	}
	fclose(format);

	printf("\n</RECORDS>\n");
	fflush(stdout);
	//xml_enc_note();
	return;
}

void xml_out2() {
	CROSS ** crosses, ** crosses_xml;
	char *** dat;
	int i, j, crosses_cnt, rows, cols, dynamic, new_m_i;
	FUNC * func_p;
        char *bgcolor, *tabcolor[2];
	char buf[BUFFER_N], buf2[BUFFER_N], *tmp, *tmp2, new_m[BUFFER_N];
	FILE * format;


	printf("\n<RECORDS>"); fflush(stdout);
        crosses=find_crosses(&crosses_cnt);
        crosses_xml=find_crosses_xml(&crosses_cnt);
	if (!(dat=dat_get3(&rows, &cols))) {
		printf("\n</RECORDS>\n");
		return;
	}

	for (j=0; j<rows; j++) {
	  printf("\n<RECORD>"); fflush(stdout);

	  printf("\n<DIMENSIONS>"); fflush(stdout);
	  for (i=0; i<crosses_cnt; i++) {

	    tmp=find_label_dynamic(crosses[i]->name_ptr->name_html, de_space(dat[j][i]), &dynamic);
	    if (!(strcmp(de_space(dat[j][i]), "."))) tmp2=".";
	    else tmp2=tmp;
	    printf("\n\t\t<DIMENSION><NAME>%s</NAME><TITLE>%s</TITLE>", 
		escape_special(crosses_xml[i]->name_ptr->name_html), 
		escape_special(crosses_xml[i]->name_ptr->prompt));
	    printf("\n\t\t<VALUE>%s<TITLE>%s</TITLE></VALUE></DIMENSION>", 
		(dynamic? escape_special(tmp2):escape_special(de_space(dat[j][i]))), escape_special(tmp));

	  }
	  printf("\n</DIMENSIONS>"); fflush(stdout);

	  if (func_p=(FUNC *) find_func(h_func, "xml_out_map_file")) {
	    strcpy(buf, func_p->value);
	  }
	  else {
            func_p=(FUNC *) find_func(h_func, "out_detail");
	    sprintf(buf, "xml%s", func_p->value);
	  }

	  printf("\n\t<MEASURES>"); fflush(stdout);
	  printf("\n\t<MEASURE>");
	  new_m_i=0;
	  strcpy(new_m, "123456789aaaaaaaaaaaa");
	  for (i=i; i<cols; i++) {
	    sprintf(buf2, "%d", i-crosses_cnt+1);
	    tmp=find_label_dynamic(buf, buf2, &dynamic);
	    if (!(strncmp(tmp, new_m, strlen(new_m)))) new_m_i=strlen(new_m)+1;
	    else {
	      new_m_i=0;
	      strcpy(new_m, de_space(tmp));
	      if ((tmp2=strchr(new_m, ' '))) tmp2[0]=0;
	    }

	    if (!new_m_i && i>crosses_cnt) {
	      printf("\n\t</MEASURE>");
	      printf("\n\t<MEASURE>");
  	    }

	    if (!new_m_i) {
	      printf("\n\t\t<NAME>%s</NAME>", new_m);
	      printf("\n\t\t<VALUE>%s</VALUE>", de_space(dat[j][i]));
	    }
	    else {
	      printf("\n\t\t<%s>%s</%s>", tmp+new_m_i, de_space(dat[j][i]), tmp+new_m_i);
	    }
	  }
	  printf("\n\t</MEASURE>");
	  printf("\n\t</MEASURES>");
	  printf("\n</RECORD>");
	}

	printf("\n</RECORDS>");
}

MAP * h_map_bld(char * str) {
	MAP * map_line;
	int i;
	char *tmp, *tmp2, buf[BUFFER_N];
	if(!((map_line = (MAP *) malloc(sizeof(MAP))))) hbase_error(3, "xml_map_bld_2");
	
	tmp=strtok(str, " ");
//printf(" \nh_map_bld ------------111 --%s", tmp); fflush(stdout);
	if (tmp != NULL) {
		strcpy(buf, tmp);
		if(!(map_line->sas_data_column = malloc(strlen(tmp)+1))) hbase_error(3, "h_map_bld_2");
		strcpy(map_line->sas_data_column, de_space(buf));
	}
	else map_line->sas_data_column=NULL;
	if (isdigit(tmp[0])) map_line->id=atoi(tmp);
	tmp=strtok(NULL, " ");
//printf(" \nh_map_bld ------------222 --%s", tmp); fflush(stdout);
	if (tmp != NULL) {
		strcpy(buf, tmp);
		if(!(map_line->xml_element_name = malloc(strlen(tmp)+1))) hbase_error(3, "h_map_bld_2");
		strcpy(map_line->xml_element_name, de_space(buf));
	}
	else map_line->xml_element_name=NULL;
	tmp=strtok(NULL, " ");
//printf(" \nh_map_bld ------------333 --%s", tmp); fflush(stdout);
	if (tmp != NULL) {
		strcpy(buf, tmp);
		if(!(map_line->value_of_name_element = malloc(strlen(tmp)+1))) hbase_error(3, "h_map_bld_2");
		strcpy(map_line->value_of_name_element, de_space(buf));
	}
	else map_line->value_of_name_element=NULL;
	tmp=strtok(NULL, " ");
//printf(" \nh_map_bld ------------444 --%s", tmp); fflush(stdout);
	if (tmp != NULL) {
		strcpy(buf, tmp);
		if(!(map_line->plural_flag = malloc(strlen(tmp)+1))) hbase_error(3, "h_map_bld_2");
		strcpy(map_line->plural_flag, de_space(buf));
	}
	else map_line->plural_flag=NULL;
 
	return map_line;
}

void xml_map_bld (char * map_f) {
	FILE *fmap;
	int i, j, flag;
	char *tmp, *tmp2, str[BUFFER_N];

	if(!(fmap = file_open(map_f, 0))) {
	  hbase_error(44, map_f);
	}

	for (h_map_i=0; !feof(fmap); ) {
		tmp = fgets(str, BUFFER_N, fmap);
		if (tmp!=NULL && strlen(tmp)>4) h_map_i++;
	}

	if (!(h_map = (MAP**) malloc((h_map_i+1)*sizeof(MAP *)))) hbase_error(3, "xml_map_bld_1");
	rewind(fmap);
	for (i=0; !feof(fmap); ) {
		tmp = fgets(str, BUFFER_N, fmap);
		if (tmp==NULL || strlen(tmp)<=4) continue;

		h_map[i] = h_map_bld(tmp);
//printf("\n h_map %s, %s, %s, %s", h_map[i]->sas_data_column, h_map[i]->xml_element_name, h_map[i]->value_of_name_element, h_map[i]->plural_flag); fflush(stdout);
		if (i>0) {
			if (h_map[i]->plural_flag == NULL) {
				if (!strcmp(h_map[i]->xml_element_name, h_map[i-1]->xml_element_name))  {
					if (h_map[i-1]->plural_flag == NULL) {
						h_map[i-1]->plural_flag="1";
					}	
					h_map[i]->plural_flag=h_map[i-1]->plural_flag;;
				}
			}
		}
		i++;
	}	 	
}

void xml_out3() {
	CROSS ** crosses, ** crosses_xml;
	char *** dat;
	int i, j, crosses_cnt, rows, cols, dynamic, new_m_i, plural_flag;
	FUNC * func_p;
        char *bgcolor, *tabcolor[2];
	char buf[BUFFER_N], buf2[BUFFER_N], *tmp, *tmp2, new_m[BUFFER_N];
	FILE * format;


	printf("\n<RECORDS>"); fflush(stdout);
        crosses=find_crosses(&crosses_cnt);
        crosses_xml=find_crosses_xml(&crosses_cnt);
	if (!(dat=dat_get3(&rows, &cols))) {
		printf("\n</RECORDS>\n");
		return;
	}
	if (func_p=(FUNC *) find_func(h_func, "xml_out_map_file")) {
	  strcpy(buf, func_p->value);
	  xml_map_bld(buf);
//test_out(16);
	}

//printf("\n ------------- 111111111111-----%d---%d--", rows, cols); fflush(stdout);
	for (j=0; j<rows; j++) {
	  printf("\n<RECORD>"); fflush(stdout);

	  printf("\n<DIMENSIONS>"); fflush(stdout);
	  for (i=0; i<crosses_cnt; i++) {

	    tmp=find_label_dynamic(crosses[i]->name_ptr->name_html, de_space(dat[j][i]), &dynamic);
	    if (!(strcmp(de_space(dat[j][i]), "."))) tmp2=".";
	    else tmp2=tmp;
	    printf("\n\t\t<DIMENSION><NAME>%s</NAME><TITLE>%s</TITLE>", 
		escape_special(crosses_xml[i]->name_ptr->name_html), 
		escape_special(crosses_xml[i]->name_ptr->prompt));
	    printf("\n\t\t<VALUE>%s<TITLE>%s</TITLE></VALUE></DIMENSION>", 
		(dynamic? escape_special(tmp2):escape_special(de_space(dat[j][i]))), escape_special(tmp));

	  }
	  printf("\n</DIMENSIONS>"); fflush(stdout);

/* for new form=23 or form=30  xml_out format */
	  new_m[0]=0;
	  plural_flag=0;
	  if (h_map_i>0) {
		for (i=0; i<h_map_i; i++) {
			if (h_map[i]->plural_flag != NULL && (h_map[i]->plural_flag[0]=='Y' || h_map[i]->plural_flag[0]=='1')) {
			   if (plural_flag && new_m[0]!=0 && strcmp(new_m, h_map[i]->xml_element_name)) {
			   	new_m[0]=0;
				printf("\n\t</%sS>", h_map[i-1]->xml_element_name);
				plural_flag=0;
			   }
			   if (new_m[0]==0) {
				strcpy(new_m, h_map[i]->xml_element_name);
				printf("\n\t<%sS>", h_map[i]->xml_element_name);
				plural_flag=1;
			    }
			}
			else if (i>0 && plural_flag) {
			   	new_m[0]=0;
				printf("\n\t</%sS>", h_map[i-1]->xml_element_name);
				plural_flag=0;
			}
			printf("\n\t\t<%s>", h_map[i]->xml_element_name);
			if (h_map[i]->value_of_name_element) printf("\n\t\t\t<NAME>%s</NAME>", h_map[i]->value_of_name_element);
			if (dat[j][i+crosses_cnt]) printf("\n\t\t\t<VALUE>%s</VALUE>", de_space(dat[j][i+crosses_cnt]));
			printf("\n\t\t</%s>", h_map[i]->xml_element_name);
		}
		if (new_m[0]!=0) {
			printf("\n\t</%sS>", h_map[i-1]->xml_element_name);
		}
	  }
	  else {
            func_p=(FUNC *) find_func(h_func, "out_detail");
	    sprintf(buf, "xml%s", func_p->value);

	  printf("\n\t<MEASURES>"); fflush(stdout);
	  printf("\n\t<MEASURE>");
	  new_m_i=0;
	  strcpy(new_m, "123456789aaaaaaaaaaaa");
	  for (i=i; i<cols; i++) {
	    sprintf(buf2, "%d", i-crosses_cnt+1);
	    tmp=find_label_dynamic(buf, buf2, &dynamic);
	    if (!(strncmp(tmp, new_m, strlen(new_m)))) new_m_i=strlen(new_m)+1;
	    else {
	      new_m_i=0;
	      strcpy(new_m, de_space(tmp));
	      if ((tmp2=strchr(new_m, ' '))) tmp2[0]=0;
	    }

	    if (!new_m_i && i>crosses_cnt) {
	      printf("\n\t</MEASURE>");
	      printf("\n\t<MEASURE>");
  	    }

	    if (!new_m_i) {
	      printf("\n\t\t<NAME>%s</NAME>", new_m);
	      printf("\n\t\t<VALUE>%s</VALUE>", de_space(dat[j][i]));
	    }
	    else {
	      printf("\n\t\t<%s>%s</%s>", tmp+new_m_i, de_space(dat[j][i]), tmp+new_m_i);
	    }
	  }
	  printf("\n\t</MEASURE>");
	  printf("\n\t</MEASURES>");
	  }

	  printf("\n</RECORD>");
	}

	printf("\n</RECORDS>");
}

void xml_enc_note() {
	FILE * dat;
	char str[BUFFER_N], *tmp;

	if (!(tmp=get_sasname(str))) hbase_error(45, NULL);
	strcat(tmp, ".dat");
	if (!(dat=fopen(tmp, "r"))) hbase_error(12, tmp);
	while (!feof(dat)) {
		if (!(tmp=fgets(str, BUFFER_N, dat))) break;
		if ((form==1 || form==3 || form==4) && str[29]=='X') {
			printf("\n<FOOTNOTE name=\"small_num\"> The result in the cell with small number of observations was encrypted as /FOOTNOTE>.");
			break; 
		}
	}
	fclose(dat);

	tmp=find_path("func");
	sprintf(str, "func%s", tmp);
	if ((tmp=find_path(str)) && strstr(tmp, "Age-adjusted")) {
		printf("\n<FOOTNOTE name=\"standard_pop\">%s", escape_special(tmp));
		tmp=find_stdpop(1);
		printf("\n (Standard population is %s.)", escape_special(tmp));
		printf("\n</FOOTNOTE>");
	}

}

void xml_label(char **dx1, char **dx2, char **cx1, char **cx2, char *lbl,
		int c1, int c2, int n) {
	int i, j, k, tc=0;
	char *tmp, *tmp2, buf[BUFFER_N], *cross1, *cross2;
	NAME *n_ptr1=NULL, *n_ptr2=NULL;

	if (cross1=find_path("cross1")) {
		if (!(n_ptr1=find_name(cross1, 1))) cross1=NULL;
		else cross1=n_ptr1->name_html;
	}
	if (cross2=find_path("cross2")) {
		if (!strcmp(cross2, "none")) cross2=NULL;
		else if (!(n_ptr2=find_name(cross2, 1))) cross2=NULL;
			else cross2=n_ptr2->name_html;
	}

	printf("\n<CROSS_VARIABLE ID=\"1\">%s</CROSS_VARIABLE>", cross1? escape_special(cross1) : "");
	printf("\n<CROSS_VARIABLE ID=\"2\">%s</CROSS_VARIABLE>", cross2? escape_special(cross2) : "");

	printf("\n<LABEL row=\"0\" column=\"0\">%s</LABEL>", n_ptr1? escape_special(n_ptr1->prompt) : " ");
	i=c2>0 ? c2 : 1;
	printf("\n<LABEL row=\"0\" column=\"1-%d\">%s</LABEL>", i, n_ptr2 ? escape_special(n_ptr2->prompt) : " ");

	tmp2=find_path("sequence");
	if (cross2) {
		for(i=0; i<c2; i++) {
			tmp=find_label(cross2, cx2[i]);
			if (cx2[i][0]=='.' ||
			    cx2[i][0]=='-' ||
			    cx2[i][0]==' ' ||
			    cx2[i][0]=='\0' ||
			    !tmp2 ||
			    tmp2[0]==' ' ||
			    tmp2[0]=='\0' ||
			    n_ptr2->type2[0]=='6') 
			    printf("\n<LABEL name=\"%s\" row=\"1\" column=\"%d\">%s</LABEL>", escape_special(cross2), i+1, escape_special(tmp? tmp : cx2[i]));
			else
			    printf("\n<LABEL name=\"%s\" row=\"1\" column=\"%d\" drilldown=\"javascript:drill_down('%s', '%s');\">%s</LABEL>", escape_special(cross2), i+1, 
				cross_back(cross2, buf), 
				escape_special(n_ptr2->type2[0]=='8'? tmp : cx2[i]), 
				escape_special(tmp? tmp : cx2[i]));
		}
	
		for (j=0; j<c1; j++) {
			tmp=find_label(cross1, cx1[j]);
			if (cx1[j][0]=='.' ||
			    cx1[j][0]=='-' ||
			    cx1[j][0]==' ' ||
			    cx1[j][0]=='\0' ||
			    tmp2[0]==' ' ||
			    tmp2[0]=='\0' )
			    printf("\n<LABEL name=\"%s\" row=\"%d\" column=\"0\">%s</LABEL>", escape_special(cross1), j+2, escape_special(tmp? tmp : cx1[j]));
			else
			    printf("\n<LABEL name=\"%s\" row=\"%d\" column=\"0\" drilldown=\"javascript:drill_down('%s', '%s');\">%s</LABEL>", escape_special(cross1), j+2, 
				cross_back(cross1, buf), 
				escape_special(n_ptr1->type2[0]=='8'? tmp : cx1[j]), 
				escape_special(tmp? tmp : cx1[j]));
		}
	}
	else {
		for (j=0; j<c1; j++) {
			tmp=find_label(cross1, cx1[j]);
			if (cx1[j][0]=='.' ||
			    cx1[j][0]=='-' ||
			    cx1[j][0]==' ' ||
			    cx1[j][0]=='\0' ||
			    tmp2[0]==' ' ||
			    tmp2[0]=='\0' )
			    printf("\n<LABEL name=\"%s\" row=\"%d\" column=\"0\">%s</LABEL>", escape_special(cross1), j+1, escape_special(tmp? tmp : cx1[j]));
			else
			    printf("\n<LABEL name=\"%s\" row=\"%d\" column=\"0\" drilldown=\"javascript:drill_down('%s', '%s');\">%s</LABEL>", escape_special(cross1), i+1, 
				cross_back(cross1, buf), 
				escape_special(n_ptr1->type2[0]=='8'? tmp : cx1[j]), 
				escape_special(tmp? tmp : cx1[j]));
		}

	}
}

void xml_records (char **dx1, char **dx2, char **dyc, char **cx1, char **cx2, char *lbl,
		int c1, int c2, int n) {
	int i, j, k, tc=0, dynamic;
	char *tmp, *tmp2, buf[BUFFER_N], *cross1, *cross2;
	NAME *n_ptr1=NULL, *n_ptr2=NULL;

	if (cross1=find_path("cross1")) {
		if (!(n_ptr1=find_name(cross1, 1))) cross1=NULL;
		else cross1=n_ptr1->name_html;
	}
	if (cross2=find_path("cross2")) {
		if (!strcmp(cross2, "none")) cross2=NULL;
		else {
			if (!(n_ptr2=find_name(cross2, 1))) cross2=NULL;
			else cross2=n_ptr2->name_html;
		}
	}

printf("\n cross1--*%s cross2--*%s c1--*%s c2--*%s", cross1, cross2, c1, c2);
	//printf("\n<LABEL row=\"0\" column=\"0\">%s</LABEL>", n_ptr1? escape_special(n_ptr1->prompt) : " ");
	i=c2>0 ? c2 : 1;
	//printf("\n<LABEL row=\"0\" column=\"1-%d\">%s</LABEL>", i, n_ptr2 ? n_ptr2->prompt : " ");

	if (cross2) {
	    for (j=0; j<c1; j++) {
		if (!strncmp(n_ptr2->name_html, "out_", 4)) {
			printf("\n\t<RECORD>");
			printf("\n\t\t%s", lbl);
			tmp=find_label_dynamic(n_ptr1->name_html, cx1[j], &dynamic);
			printf("\n\t\t<DIMENSION><NAME>%s</NAME><TITLE>%s</TITLE>", escape_special(n_ptr1->name_html), escape_special(n_ptr1->prompt));
			printf("\n\t\t<VALUE>%s<TITLE>%s</TITLE></VALUE></DIMENSION>", 
			(dynamic && cx1[j][0]!='.')? escape_special(tmp):escape_special(cx1[j]), escape_special(tmp));
			//printf("\n\t\t<DIMENSION><NAME>%s</NAME><VALUE>%s</VALUE></DIMENSION>", escape_special(n_ptr1->prompt), escape_special(tmp));
		}
	    	for(i=0; i<c2; i++) {
		    if (!strncmp(n_ptr2->name_html, "out_", 4)) {
			sprintf(buf, "xml%s", n_ptr2->name_html);
		    	tmp=find_label_dynamic(buf, cx2[i], &dynamic);
		    	k=dat_find(dx1, dx2, cx1[j], cx2[i], n, 1);
			if (!strcmp(tmp, "CI")) {
			    if (k>=0 && !(tmp2=strchr(dyc[k], '-'))) {

				printf("\n\t\t<LOWER_CONFIDENCE_LIMIT>%s</LOWER_CONFIDENCE_LIMIT>", dyc[k]);
				printf("\n\t\t<UPPER_CONFIDENCE_LIMIT>%s</UPPER_CONFIDENCE_LIMIT>", dyc[k]);
			    }
			    else {
				tmp2[0]=0;;
				tmp2=tmp2+1;
				printf("\n\t\t<LOWER_CONFIDENCE_LIMIT>%s</LOWER_CONFIDENCE_LIMIT>", k>=0? dyc[k]:" ");
				printf("\n\t\t<UPPER_CONFIDENCE_LIMIT>%s</UPPER_CONFIDENCE_LIMIT>", tmp2);
			    }
			}
			else printf("\n\t\t<%s>%s</%s>", escape_special(tmp), k>=0? dyc[k]:" ", escape_special(tmp));
		    }
		    else {
			printf("\n\t<RECORD>");
		    	tmp=find_label_dynamic(n_ptr1->name_html, cx1[j], &dynamic);
			printf("\n\t\t<DIMENSION><NAME>%s</NAME><TITLE>%s</TITLE>", escape_special(n_ptr1->name_html), escape_special(n_ptr1->prompt));
			printf("\n\t\t<VALUE>%s<TITLE>%s</TITLE></VALUE></DIMENSION>", 
			(dynamic && cx1[j][0]!='.')? escape_special(tmp):escape_special(cx1[j]), escape_special(tmp));
			//printf("\n\t\t<DIMENSION><NAME>%s</NAME><VALUE>%s</VALUE></DIMENSION>", escape_special(n_ptr1->prompt), escape_special(tmp));
		    	tmp=find_label_dynamic(n_ptr2->name_html, cx2[i], &dynamic);
			printf("\n\t\t<DIMENSION><NAME>%s</NAME><TITLE>%s</TITLE>", 
			escape_special(n_ptr2->name_html), escape_special(n_ptr2->prompt));
			printf("\n\t\t<VALUE>%s<TITLE>%s</TITLE></VALUE></DIMENSION>", escape_special(cx2[i]), escape_special(tmp));
		    	//printf("\n\t\t<DIMENSION><NAME>%s</NAME><VALUE>%s</VALUE></DIMENSION>", escape_special(n_ptr2->prompt), escape_special(tmp));
		    	k=dat_find(dx1, dx2, cx1[j], cx2[i], n, 1);
		    	printf("\n\t\t<VALUE>%s</VALUE>", k>=0? dyc[k]:" ");
			printf("\n\t</RECORD>");
		    }
		}
		if (!strncmp(n_ptr2->name_html, "out_", 4)) {
			printf("\n\t</RECORD>");
		}
	    }
	
	}
	else {
	    for (j=0; j<c1; j++) {
		printf("\n\t<RECORD>");
		printf("\n%s", lbl);
		tmp=find_label_dynamic(n_ptr1->name_html, cx1[j], &dynamic);
		printf("\n\t\t<DIMENSION><NAME>%s</NAME><TITLE>%s</TITLE>", escape_special(n_ptr1->name_html), escape_special(n_ptr1->prompt));
		printf("\n\t\t<VALUE>%s<TITLE>%s</TITLE></VALUE></DIMENSION>", 
		(dynamic && cx1[j][0]!='.')? escape_special(tmp):escape_special(cx1[j]), escape_special(tmp));
		//printf("\n\t\t<DIMENSION><NAME>%s</NAME><VALUE>%s</VALUE></DIMENSION>", escape_special(n_ptr1->prompt), escape_special(tmp));
		k=dat_find(dx1, dx2, cx1[j], NULL, n, 0);
		printf("\n\t\t<VALUE>%s</VALUE>", k>=0? dyc[k]:" ");
		printf("\n\t</RECORD>");
	    }

	}
}

void xml_celldata (char **dx1, char **dx2, char **dyc, char **cx1, char **cx2, char *lbl,
		int c1, int c2, int n) {
	int i, j, k, tc=0;
	char *tmp, *tmp2, buf[BUFFER_N], *cross1, *cross2;
	NAME *n_ptr1=NULL, *n_ptr2=NULL;

	if (cross1=find_path("cross1")) {
		if (!(n_ptr1=find_name(cross1, 1))) cross1=NULL;
		else cross1=n_ptr1->name_html;
	}
	if (cross2=find_path("cross2")) {
		if (!strcmp(cross2, "none")) cross2=NULL;
		else if (!(n_ptr2=find_name(cross2, 1))) cross2=NULL;
			else cross2=n_ptr2->name_html;
	}

	printf("\n<LABEL row=\"0\" column=\"0\">%s</LABEL>", n_ptr1? escape_special(n_ptr1->prompt) : " ");
	i=c2>0 ? c2 : 1;
	printf("\n<LABEL row=\"0\" column=\"1-%d\">%s</LABEL>", i, n_ptr2 ? escape_special(n_ptr2->prompt) : " ");

	tmp2=find_path("sequence");
	if (cross2) {
	    for(i=0; i<c2; i++) {
		for (j=0; j<c1; j++) {
		    k=dat_find(dx1, dx2, cx1[j], cx2[i], n, 1);
		    printf("\n<CELL_DATA row=\"%d\" column=\"%d\">%s</CELL_DATA>",
			j+2, i+1, k>=0? dyc[k]:" ");

		}
	    }
	
	}
	else {
	    for (j=0; j<c1; j++) {
		k=dat_find(dx1, dx2, cx1[j], NULL, n, 0);
		printf("\n<CELL_DATA row=\"%d\" column=\"1\">%s</CELL_DATA>",
			j+1, k>=0? dyc[k]:" ");
		}

	}
}

void xml_lbl_out(char * value, char * lbl) {
	int ps, ls, pb, lb, n, c1, c2, j, k;
	char **dx1=NULL, **dx2=NULL, **cx1=NULL, **cx2=NULL, **dyc=NULL;
	char *tmp;

	//printf("\n<TABLE name=\"%s\">", lbl);
	if (!(n=dat_get(&dx1, &dx2, &dyc, value))) return;
	dat_cross(dx1, dx2, &cx1, &cx2, &c1, &c2, n);

	//xml_label(dx1, dx2, cx1, cx2, lbl, c1, c2, n);
	//xml_celldata(dx1, dx2, dyc, cx1, cx2, lbl, c1, c2, n);
	xml_records(dx1, dx2, dyc, cx1, cx2, lbl, c1, c2, n);

        for (j=0; j<n; j++) {
            if (dx1[j]) free(dx1[j]);
            if (dyc[j]) free(dyc[j]);
        }
        free(dx1); free(dyc);; 
        if (dx2) {
            for (j=0; j<n; j++) if (dx2[j]) free(dx2[j]);
            free(dx2);
        }
	//printf("\n</TABLE>");
}

void xml_label2() {
	CROSS ** crosses;
	char *** dat;
	int i, j, crosses_cnt, rows, cols, rowcolor;
        char *bgcolor, *tabcolor[2];
	char buf[BUFFER_N], buf2[BUFFER_N], *tmp;
	FILE * format;
	FUNC * func_p;

        crosses=find_crosses_xml(&crosses_cnt);
	if (!(dat=dat_get3(&rows, &cols))) return;

	for (i=0; i<crosses_cnt; i++) {
	  if (crosses[i] && crosses[i]->name_ptr)
	      printf("\n<CROSS_VARIABLE ID=\"%d\">%s</CROSS_VARIABLE>", i+1, crosses[i]->name_ptr->name_html);
	}
	for (i=0; i<crosses_cnt; i++) {
	    printf("\n<LABEL row=\"0\" column=\"%d\">%s</LABEL>", i, escape_special(crosses[i]->name_ptr->prompt));
	}

	func_p=(FUNC *) find_func(h_func, "xml_out_mpa_file");
	if (func_p && func_p->value) {
		for (j=0; j<cols-crosses_cnt; j++) {
	  	  tmp=find_label(func_p->value, buf);
	  	  if (tmp) printf("\n<LABEL row=\"0\" column=\"%d\">%s</LABEL>", i+j, escape_special(tmp));
		}

	}
        else {
		tmp=find_path("func");
		sprintf(buf2, "xmlout_%s", tmp);
		for (j=0; j<cols-crosses_cnt; j++) {
	 	  sprintf(buf, "%d", j+1);
	  	  tmp=find_label(buf2, buf);
	  	  if (tmp) printf("\n<LABEL row=\"0\" column=\"%d\">%s</LABEL>", i+j, escape_special(tmp));
		}
	}

	for (j=0; j<rows; j++) {
	  for (i=0; i<crosses_cnt; i++) {
	    tmp=find_label(crosses[i]->name_ptr->name_html, de_space(dat[j][i]));
	    if (!tmp) tmp=dat[j][i];
	    if (atoi(crosses[i]->name_ptr->type2))
	      printf("\n<LABEL name=\"%s\" row=\"%d\" column=\"%d\">%s</LABEL>", crosses[i]->name_ptr->name_html, j+1, i, escape_special(tmp));
	    else
	      printf("\n<LABEL name=\"%s\" row=\"%d\" column=\"%d\" ", crosses[i]->name_ptr->name_html, j+1, i);
	      printf("drill_down=\"javascript:drill_down('%s', '%s');\">", crosses[i]->name_ptr->name_html, dat[j][i]);
	      printf("%s</LABEL>", tmp);
	  }
	}

}


void xml_celldata2() {
	CROSS ** crosses;
	char *** dat;
	int i, j, crosses_cnt, rows, cols, rowcolor;
        char *bgcolor, *tabcolor[2];
	char buf[BUFFER_N], buf2[BUFFER_N], *tmp;
	FILE * format;

        crosses=find_crosses_xml(&crosses_cnt);
	if (!(dat=dat_get3(&rows, &cols))) return;


	for (j=0; j<rows; j++) {
	  for (i=crosses_cnt; i<cols; i++) {
	    printf("\n<CELL_DATA row=\"%d\" column=\"%d\">%s</CELL_DATA>", j+1, i, dat[j][i]);
	  }
	}

	return;
}

void xml_sequence_select() {
	char *tmp1, *tmp2;
	int i;
	NAME *n_ptr;

	sequence_bld();
	sequence_compress();
	tmp2=find_path("sequence");
	if (!tmp2 || tmp2[0]==' ' || tmp2[0]=='\0') return;
	printf("\n<DRILL_DOWN_SEQUENCE ");
	if ((tmp1=find_path("drill_html")))
	    printf("drill_down_url=\"%s\">", escape_special(tmp1));
	else
	    printf("drill_down_url=\"\">");

	printf("\n<select name=next_seq>");
	for (i=0; ;i++) {
		if (!tmp2[0]) break;
		if (tmp1=strchr(tmp2, ' ')) tmp1[0]='\0';
		n_ptr=find_name(tmp2, 1);
		printf("\n<option value=\"%s\" %s> %s", escape_special(tmp2), 
			i? "" : "selected", escape_special(n_ptr? n_ptr->prompt:tmp2));
		if (!tmp1) break;
		tmp2=tmp1+1;
		tmp1[0]=' ';
	}
	printf("\n</select>"); 
	printf("\n</DRILL_DOWN_SEQUENCE>");
}

