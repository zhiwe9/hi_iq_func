/* HI-IQ System, the High Information Internet Query System,
	Copyright 1995, 1996 Utah Office of Health Data Analysis.

	hi_iq_sas.c 11/11/98
	build SAS program.

	We provide the interactive interface to make your data available
	to public through Internet.
*/

#include "hi_iq.h"
#include "hi_iq_var.h"

int _flag_=0;
int _next_=1;
char _length_buf[BUFFER_N];
char _proxy1_buf[BUFFER_N];
char _proxy2_buf[BUFFER_N];

char * get_sasname(char * str) {
	time_t now;
	struct tm *tp;

	if (h_sasname) {
		strcpy(str, h_sasname);
		return(str);
	}

	time(&now);
	tp=localtime(&now);
	sprintf(str, "SaSh%d_%d_%d", getpid(), tp->tm_mday, tp->tm_hour);
	if (!(h_sasname=malloc((strlen(str)+1)*sizeof(char)))) hbase_error(3, "sas-1");
	strcpy(h_sasname, str);
	return(str);
}

void sas_cross_bld(FILE * sas, char * cross, char * pop) {
	char * tmp, * tmp2, str[STRING_N], str2[STRING_N];
	int i, type, c;
	FILE * fgrp, * ffmt;
	NAME * n_ptr, *n_ptr2;
	VARI ** v_ptr, ** v_ptr2,  var;


	fprintf(sas, "\n\n\n/* Following codes from sas_cross_bld(%s) */", cross);
	fprintf(sas, "\n next%d: ", _next_);
	_next_++;
	tmp=find_path(cross);
	if (!tmp) return;
	if (!(n_ptr=find_name(tmp, 1))) return;

	type=atoi(n_ptr->type2);
	if (type == 0) return;
	if (type!=6 && type != 8 && type !=10) {
	  if (!isdigit(tmp[strlen(tmp)-1]))
	    hbase_error(31, n_ptr->type2);

/*
	  i=strlen(tmp);
	  if (i>2 && tmp[i-1]=='f' && tmp[i-2]=='_') {
	   i=0;
	  }
	  else {
*/
	  for (i=strlen(tmp)-1; i>0; i--) {
	    if (!isdigit(tmp[i])) {
	      tmp[i+1]=0;
	      strcat(tmp, "_f");
	      if (!(n_ptr=find_name(tmp, 1))) return;
	      type=atoi(n_ptr->type2);
//		break;
//	  }
	    }
	  }
	}
	if (!(v_ptr=find_vari(n_ptr->name_html, 1, type, &c))) return;

/*
	if (!(strcmp(n_ptr->name_html, "cause_f"))) {
		if (v_ptr[0]->value[0]=='8') strcpy(tmp, "cause8");
		else {
			if (!strcmp(cross, "cross1")) _cross_1=n_ptr->name_sas;
			if (!strcmp(cross, "cross2")) _cross_2=n_ptr->name_sas;
			if (!strcmp(cross, "cross3")) _cross_3=n_ptr->name_sas;
			n_ptr->name_sas=n_ptr->name_html;
		}
		return;
	}
	if (!(strcmp(n_ptr->name_html, "geo_f"))) {
		if (!(v_ptr=find_vari(n_ptr->name_html, 1, 8, &type))) return;
		if (v_ptr[0]->value[0]=='1') strcpy(tmp, "geo1");
		if (v_ptr[0]->value[0]=='2') strcpy(tmp, "geo2");
		return;
	}
*/

	if (!strcmp(cross, "cross1") && _cross_1 != NULL) n_ptr->name_sas=_cross_1;
	if (!strcmp(cross, "cross2") && _cross_2 != NULL) n_ptr->name_sas=_cross_2;
	if (!strcmp(cross, "cross3") && _cross_3 != NULL) n_ptr->name_sas=_cross_3;
	if (type==6) {
	//	n_ptr->type2="8";

		tmp=strstr(tmp, "_f");
		tmp[0]=0;
		strcat(tmp, v_ptr[0]->value);
		return;
	}
	else if (type==8) {
		strcpy(str, n_ptr->name_html);
		tmp2=strstr(str, "_f");
		tmp2[0]=0;
		strcat(str, v_ptr[0]->value);

		n_ptr2=find_name(str, 1);
		if (n_ptr2 && !(atoi(n_ptr2->type2))) {
		  tmp=strstr(tmp, "_f");
		  tmp[0]=0;
		  strcat(tmp, v_ptr[0]->value);
		  return;
		}

		if (v_ptr2=find_vari(str, 2, 3, &c)) {
		  if (!strcmp(cross, "cross1")) _cross_1=n_ptr->name_sas;
		  if (!strcmp(cross, "cross2")) _cross_2=n_ptr->name_sas;
		  if (!strcmp(cross, "cross3")) _cross_3=n_ptr->name_sas;
		  n_ptr->name_sas=n_ptr->name_html;
		  if (!strcmp(pop, "poptmp") && n_ptr->name_pop)
			n_ptr->name_pop=n_ptr->name_html;
		  free(v_ptr2);
		  return;
		}

fprintf(sas, "\n /* tmp: %s type: %d str: %s*/", tmp, type, str);
		strcat(str, ".grp");
		fgrp=file_open(str, 0);
		if (!fgrp) {
			strcpy(str, v_ptr[0]->value);
			strcat(str, ".grp");
			fgrp=file_open(str, 0);
		}
		if (!fgrp) {
			if (!(v_ptr=find_vari(n_ptr->name_html, 1, 8, &type))) return;
fprintf(sas, "\n /* 222tmp: %s type: %d str: %s*/", tmp, type, str);
			if (!strcmp(cross, "cross1")) _cross_1=n_ptr->name_sas;
			if (!strcmp(cross, "cross2")) _cross_2=n_ptr->name_sas;
			if (!strcmp(cross, "cross3")) _cross_3=n_ptr->name_sas;
			n_ptr->name_sas=n_ptr->name_html;
		  	if (!strcmp(pop, "poptmp") && n_ptr->name_pop)
				n_ptr->name_pop=n_ptr->name_html;
			return;
		}
/*
hbase_error(32, str2);
		fprintf(sas, "\n\n data %s;", pop);
		fprintf(sas, "\n\t set %s;", pop);
*/
		fprintf(sas, "\n %s = 0;", n_ptr->name_html);
		type = (!(strcmp(n_ptr->type1, "char")));
	
		if (!strcmp(pop, "tmp")) {
			tmp2=get_sasname(str);
			sprintf(str2, "%s%s.lbl", tmp2, n_ptr->name_html);
			if (!(ffmt=fopen(str2, "w"))) hbase_error(34, str2);
			fprintf(ffmt, ". All");
			fprintf(ffmt, "\n0 Other");
		}

		while (!feof(fgrp)) {
			if (!(tmp=fgets(str, STRING_N, fgrp))) break;
			if (str[0] <'0' || str[0] > '9') continue;
			if (!(tmp=strchr(str, ' '))) continue;
			tmp[0]=0;
			var.name_ptr=n_ptr;
			var.value=tmp+1;
			var.label=tmp;
			fprintf(sas, "\n if (");
			if (!strcmp(pop, "poptmp")) sas_pop_type3(&var, sas, type);
			else sas_group_type3(&var, sas, type);
			fprintf(sas, " ) then %s=%s;", n_ptr->name_html, str);

			if (!strcmp(pop, "tmp")) 
				fprintf(ffmt, "\n%s %s", str, tmp+1);
		}

/*
		fprintf(sas, "\n run;");
*/
		fclose(fgrp);
		if (!strcmp(pop, "tmp")) {
			fclose(ffmt);
			_label=2;
		}
	}
	else if (type==10) {
		strcpy(str, v_ptr[0]->value);

fprintf(sas, "\n /* 333tmp: %s type: %d str: %s*/", tmp, type, str);
/*
		if (v_ptr2=find_vari(str, 1, 0, &c)) {
		  if (!strcmp(cross, "cross1")) _cross_1=n_ptr->name_sas;
		  if (!strcmp(cross, "cross2")) _cross_2=n_ptr->name_sas;
		  if (!strcmp(cross, "cross3")) _cross_3=n_ptr->name_sas;
		  n_ptr->name_sas=n_ptr->name_html;
		  if (!strcmp(pop, "poptmp") && n_ptr->name_pop)
			n_ptr->name_pop=n_ptr->name_html;
		  free(v_ptr2);
		  return;
		}
*/
		strcat(str, ".grp");
		fgrp=file_open(str, 0);
		if (!fgrp) {
			if (!(v_ptr=find_vari(n_ptr->name_html, 1, 10, &type))) return;
fprintf(sas, "\n /* 444tmp: %s type: %d str: %s   c--*%d */", tmp, type, str, c);
			if (!strcmp(cross, "cross1")) _cross_1=n_ptr->name_sas;
			if (!strcmp(cross, "cross2")) _cross_2=n_ptr->name_sas;
			if (!strcmp(cross, "cross3")) _cross_3=n_ptr->name_sas;
			n_ptr->name_sas=n_ptr->name_html;
		  	if (!strcmp(pop, "poptmp") && n_ptr->name_pop)
				n_ptr->name_pop=n_ptr->name_html;



		if ((v_ptr2=find_vari(v_ptr[0]->value, 1, 3, &c))) {
		fprintf(sas, "\n %s = .;", n_ptr->name_html);
		type = (!(strcmp(n_ptr->type1, "char")));
	
		if (!strcmp(pop, "tmp")) {
			tmp2=get_sasname(str);
			sprintf(str2, "%s%s.lbl", tmp2, n_ptr->name_html);
			if (!(ffmt=fopen(str2, "w"))) hbase_error(34, str2);
			fprintf(ffmt, ". All");
			fprintf(ffmt, "\n0 Other");
		}

		for (i=0;i<c; i++) {
			fprintf(sas, "\n if (");
			if (!strcmp(pop, "poptmp")) sas_pop_type3(v_ptr2[i], sas, type);
			else sas_group_type3(v_ptr2[i], sas, type);
			fprintf(sas, " ) then %s=%d;", n_ptr->name_html, i+1);

			if (!strcmp(pop, "tmp")) 
				fprintf(ffmt, "\n%d %s", i+1, v_ptr2[i]->value);
		}

/*
		fprintf(sas, "\n run;");
*/
		if (!strcmp(pop, "tmp")) {
			fclose(ffmt);
			_label=2;
		}
		}
			return;
		}
/*
hbase_error(32, str2);
		fprintf(sas, "\n\n data %s;", pop);
		fprintf(sas, "\n\t set %s;", pop);
*/
		fprintf(sas, "\n %s = 0;", n_ptr->name_html);
		type = (!(strcmp(n_ptr->type1, "char")));
	
		if (!strcmp(pop, "tmp")) {
			tmp2=get_sasname(str);
			sprintf(str2, "%s%s.lbl", tmp2, n_ptr->name_html);
			if (!(ffmt=fopen(str2, "w"))) hbase_error(34, str2);
			fprintf(ffmt, ". All");
			fprintf(ffmt, "\n0 Other");
		}

		while (!feof(fgrp)) {
			if (!(tmp=fgets(str, STRING_N, fgrp))) break;
			if (str[0] <'0' || str[0] > '9') continue;
			if (!(tmp=strchr(str, ' '))) continue;
			tmp[0]=0;
			var.name_ptr=n_ptr;
			var.value=tmp+1;
			var.label=tmp;
			fprintf(sas, "\n if (");
			if (!strcmp(pop, "poptmp")) sas_pop_type3(&var, sas, type);
			else sas_group_type3(&var, sas, type);
			fprintf(sas, " ) then %s=%s;", n_ptr->name_html, str);

			if (!strcmp(pop, "tmp")) 
				fprintf(ffmt, "\n%s %s", str, tmp+1);
		}

/*
		fprintf(sas, "\n run;");
*/
		fclose(fgrp);
		if (!strcmp(pop, "tmp")) {
			fclose(ffmt);
			_label=2;
		}

	}
	else hbase_error(33, cross);

	if (!strcmp(cross, "cross1")) _cross_1=n_ptr->name_sas;
	if (!strcmp(cross, "cross2")) _cross_2=n_ptr->name_sas;
	if (!strcmp(cross, "cross3")) _cross_3=n_ptr->name_sas;
	n_ptr->name_sas=n_ptr->name_html;

fprintf(sas, "\n/* pop---*%s name_pop--*%s   */", pop, n_ptr->name_pop);
	if (!strcmp(pop, "poptmp") && n_ptr->name_pop)
		n_ptr->name_pop=n_ptr->name_html;
fprintf(sas, "\n/*  name_pop--*%s   */",  n_ptr->name_pop);
}

void sas_group_type3(VARI * vari_p, FILE * sas, int l) {
	int i, m;
	char *tmp, *tmp2, *tmp3, *name, *prompt, str[BUFFER_N];
	char str2[2];

	fprintf(sas, "\n/* sas_group_type3 */");
	tmp=strcpy(str, vari_p->value);
	tmp=de_space(tmp);
	name=vari_p->name_ptr->name_sas;
	prompt=vari_p->name_ptr->prompt;
	for (i=0; ; i++) {

	fprintf(sas, "\n/* sas_group_type3 11 tmplen --*%d tmp--%s--*/", strlen(tmp), tmp);
		if (!(tmp=sas_type2_cut(tmp, str))) break;
		if (!(tmp2=strchr(str, '-'))) {
			if (!(tmp2=strchr(str, '+'))) {
				tmp2=de_space(str);
				m=0;
				str2[0]=0;
				if (tmp2[0]=='>' || tmp2[0]=='<') {
				  str2[0]=tmp2[0];
				  str2[1]=0;
				  m=1;
				}
				if (_flag_ > 1 ) {
					if (form>0 && form!=3 && form!=4 && form!=6 && form!=8
					     && form!=21 && form!=22  && form!=23 && form !=30) {
					  if (m) {
						if (l) printf("\n\t %s(%s%s'%s') ", i ? " or " : " ", prompt, str2, tmp2+m);
						else printf("\n\t %s(%s%s%s) ", i ? " or " : " ", prompt, str2, tmp2+m);
					   }
					   else {
						if (l) printf("\n\t %s(%s=:'%s') ", i ? " or " : " ", prompt, tmp2);
						else printf("\n\t %s(%s=%s) ", i ? " or " : " ", prompt, tmp2);
					   }
					}
				}
				if (m) {
				if (l) fprintf(sas, "\n\t %s(upcase(%s)%supcase('%s')) ", i ? " or " : " ", name, str2, tmp2+m);
				else fprintf(sas, "\n\t %s(%s%s%s) ", i ? " or " : " ", name, str2, tmp2+m);
				}
				else {
				if (l) fprintf(sas, "\n\t %s(upcase(%s)=:upcase('%s')) ", i ? " or " : " ", name, tmp2);
				else fprintf(sas, "\n\t %s(%s=%s) ", i ? " or " : " ", name, tmp2);
				}
			}
			else {
				tmp2[0]=0;
				tmp2=de_space(str);
				if (_flag_ > 1 ) {
					if (form>0 && form!=3 && form!=4 && form!=6 && form!=8
					     && form!=21 && form!=22 && form!=23 && form!=30 ) {
						if (l) printf("\n\t %s(%s>=:'%s') ", i ? " or " : " ", prompt, tmp2);
						else printf("\n\t %s(%s>=%s) ", i ? " or " : " ", prompt, tmp2);
					}
				}
				if (l) fprintf(sas, "\n\t %s(upcase(%s)>=:upcase('%s')) ", i ? " or " : " ", name, tmp2);
				else fprintf(sas, "\n\t %s(%s>=%s) ", i ? " or " : " ", name, tmp2);
			}
		}
		else {
			tmp2[0]=0;
			tmp3=de_space(tmp2+1);
			tmp2=de_space(str);
			if (_flag_ > 1) {
				if (form>0 && form!=3 && form!=4 && form!=6 && form!=8
					     && form!=21 && form!=22 && form!=23 && form!=30) {
						if (l) printf("\n\t %s('%s' <=: %s <=: '%s') ", i? " or " : " ", tmp2, prompt, tmp3);
						else printf("\n\t %s(%s <= %s <= %s) ", i ? " or " : " ", tmp2, prompt, tmp3);
					}
			}
			if (l) fprintf(sas, "\n\t %s(upcase('%s') <=: upcase(%s) <=: upcase('%s')) ", i? " or " : " ", tmp2, name, tmp3);
			else fprintf(sas, "\n\t %s(%s <= %s <= %s) ", i ? " or " : " ", tmp2, name, tmp3);
		}
	}
}

void sas_group_type5(VARI * v_ptr, FILE * sas, int c) {
	NAME ** n_ptr;
	VARI * new_ptr[2];
	int i, j, k, type2, flag=0;
	char buf[BUFFER_N];

	if (!(new_ptr[0]=(VARI *) malloc(sizeof(VARI)))) 
		hbase_error(3, "sas_type5-1");
	new_ptr[0]->label=NULL;
	new_ptr[1]=NULL;
	
	if ((n_ptr=find_name_group(v_ptr->name_ptr->name_html,1,&j))) {
		for (k=0; k<j; k++) {
			type2=atoi(n_ptr[k]->type2);
			if (type2!=0 && type2!=1) continue;
			strcpy(buf, v_ptr->value);
			new_ptr[0]->name_ptr=n_ptr[k];
			new_ptr[0]->value=buf;
//fprintf(sas, "\n /* buf ---*%s type2 ---*%d form ---*%d*/", buf, type2, form);
	if (form>0 && form!=3 && form!=4 && form!=6 && form!=8
		) {
	  if (form != 21 && form !=22 && form!=23 && form!=30) printf("\n %s  ", flag ? "<LI>or" : "<LI>");
	fprintf(sas, "\n %s  ", flag ? "or" : "");
				switch(type2) {
				case 0: sas_type1(new_ptr, sas, 1, form);
				break;
				case 1: sas_type2(new_ptr, sas, 1, form);
				break;
				}
				flag=1;
			}
		}
	}
	free(new_ptr[0]);
}

void sas_group_bld(VARI * vari_p, FILE * sas) {
	char buf1[BUFFER_N], buf2[BUFFER_N], *tmp, *tmp2;
	int i, j, d, type2;
	FILE * ffmt;
	VARI ** v_ptr;
	NAME * name_p, *name_p2;

	fprintf(sas, "\n /* sas_group_bld vari_p->value -- %s vari_p->name_html -- %s  type2--*%s*/", vari_p->value, vari_p->name_ptr->name_html, vari_p->name_ptr->type2);
	
	type2=atoi(vari_p->name_ptr->type2);
	strcpy(buf1, vari_p->value);
	strcpy(buf2, vari_p->name_ptr->name_html);
	if (numberValue(buf1) && (tmp=strstr(buf2, "_f"))) {
	  tmp[0]=0;
	  strcat(buf2, buf1);
	}
	else strcpy(buf2, buf1);

	//if (tmp=strstr(buf2, "_f")) {
		name_p2=vari_p->name_ptr;
/*
		tmp[0]=0;
		strcat(buf2, buf1);
*/
		v_ptr=find_vari(buf2, 1, 3, &d);
		if (!v_ptr || d<=0) {
		  v_ptr=find_vari(buf1, 1, 3, &d);
		}
		if (!v_ptr || d<=0) {
		  v_ptr=find_vari(buf2, 1, 5, &d);
		}
		if (!v_ptr || d<=0) {
		  v_ptr=find_vari(buf1, 1, 5, &d);
		}
fprintf(sas, "\n /* buf1 -- *%s buf2 ---*%s d----*%d */", buf1, buf2, d);

		if (v_ptr && d>0) {
			type2=atoi(v_ptr[0]->name_ptr->type2);
//fprintf(sas, "\n /* type2---*%d */", type2);
			//if (!(name_p=find_name_type(v_ptr[0]->name_ptr->name_sas, 2, 8))) return;
			name_p=vari_p->name_ptr;
			fprintf(sas, "\n next%d:", _next_);
			_next_++;
			fprintf(sas, "\n\n%s=0;", name_p->name_html);
			j= (!(strcmp(v_ptr[0]->name_ptr->type1, "char")));
			if (form>0 && form!=3 && form!=4 && form!=6 && form!=8
				&& form!=21 && form!=22 && form!=23 && form!=30) {
				printf("\n %s ( ", _flag_ ? "<LI>and" : "<LI>");
			}
			_flag_+=2;

			tmp2=get_sasname(buf1);
			sprintf(buf2, "%s%s.lbl", tmp2, name_p2->name_html);
			if (!(ffmt=fopen(buf2, "w"))) hbase_error(34, buf2);
			fprintf(ffmt, ". All");
			fprintf(ffmt, "\n0 Other");

			for (i=0; i<d; i++) {
				if (form!=21 && form!=22 && form!=23 && form!=30) 
				  printf("%s", i ? " or " : "");
				fprintf(sas, "\n if (");
				if (type2==3) sas_group_type3(v_ptr[i], sas, j);
				else if (type2==5) sas_group_type5(v_ptr[i], sas, j);
				fprintf(sas, "\n ) then %s=%d;", name_p2->name_html, i+1);

				fprintf(ffmt, "\n%d %s", i+1, v_ptr[i]->value);
			}
			_flag_-=2;
			if (!_flag_) _flag_=1;
			fprintf(sas, "\n\t if (%s >0) then do;", name_p2->name_html);
			fprintf(sas, "\n goto next%d;", _next_);
			fprintf(sas, "\n end;");
			fprintf(sas, "\n else goto no_obs;");
			if (form>0 && form!=3 && form!=4 && form!=6 && form!=8
				&& form!=21 && form!=22 && form!=23 && form!=30) {
				printf(")");
			}

			fclose(ffmt);
			_label=1;
		}
		free(v_ptr);
	//}
}

void sas_group (FILE *sas) {
	int i, j, c;
	char *tmp;
	VARI ** vari_p;

	fprintf(sas, "\n\n/* Following codes from sas_group() */");
/*
	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n set tmp;");
*/
	fprintf(sas, "\n%s", _length_buf);

	for (i=0; i<h_name_i; i++) {
		j=atoi(h_name[i]->type2);
		if (j==8 || j==10) {
			vari_p=find_vari(h_name[i]->name_html, 1, j, &c);
			if (c<=0 || !vari_p) continue;
			sas_group_bld(vari_p[0], sas);
			free(vari_p);
		}
	}

/*
	fprintf(sas, "\n run;");
*/
	if (!_flag_) {
		if (form>0 && form!=3 && form!=4 && form!=6 && form!=8
			&& form!=21 && form!=22 && form!=23 && form!=30) {
			tmp=find_path("default");
			printf("<br>The query result is based on %s", tmp? tmp: "default values.");
		}
	}
}
		
void sas_pop_type1(FILE * sas, VARI ** v_ptr, int c) {
	int i, j=0;

	fprintf(sas, "\n\n/* Following codes from sas_pop_type1() */");
/*
	fprintf(sas, "\n data poptmp;");
	fprintf(sas, "\n\t set poptmp;");
*/
	fprintf(sas, "\n if (");
	if (!strcmp(v_ptr[0]->name_ptr->type1, "char")) j=1;
	if (j) {
		for (i=0; i<c; i++) {
			fprintf(sas, "\n %s(%s = '%s') ", i ? " or " : " ", 
				v_ptr[i]->name_ptr->name_pop, v_ptr[i]->value);
		}
	}
	else {
		for (i=0; i<c; i++) {
			fprintf(sas, "\n %s(%s = %s) ", i ? " or " : " ", 
				v_ptr[i]->name_ptr->name_pop, v_ptr[i]->value);
		}
	}
	fprintf(sas, " );");
/*
	fprintf(sas, "\n run;");
*/
}

void sas_pop_type2(FILE * sas, VARI ** v_ptr, int c) {
	char * name2, * tmp, *tmp2, *tmp3, str[BUFFER_N];
	int i, k, l=0;

	fprintf(sas, "\n\n/* Following codes from sas_pop_type2() */");
/*
	fprintf(sas, "\n data poptmp;");
	fprintf(sas, "\n\t set poptmp;");
*/
	fprintf(sas, "\n if (");
	if (!strcmp(v_ptr[0]->name_ptr->type1, "char")) l=1;
	name2=v_ptr[0]->name_ptr->name_pop;
   for (k=0; k<c; k++) {
	tmp=v_ptr[k]->value;
	if (strlen(tmp)>BUFFER_N) hbase_error(18, tmp);
	tmp2=v_ptr[k]->label;
	fprintf(sas, "\n %s", k ? "or " : "");
	for (i=0; ; i++) {
		if (!(tmp=sas_type2_cut(tmp, str))) break;
		if (!(tmp2=strchr(str, '-'))) {
		  if (!(tmp2=strchr(str, '+'))) {
			tmp2=de_space(str);
			if (l) fprintf(sas, "\n %s(upcase(%s)=:upcase('%s')) ", i ? " or " : " ", 
				name2, tmp2);
			else fprintf(sas, "\n %s(%s=%s) ", i ? " or " : " ", 
				name2, tmp2);
		  }
		  else {
			tmp2[0]=0;
		        tmp2=de_space(str);
			if (l) fprintf(sas, "\n %s(upcase(%s)>=:upcase('%s')) ", i ? " or " : " ", 
				name2, tmp2);
			else fprintf(sas, "\n %s(%s>=%s) ", i ? " or " : " ", 
				name2, tmp2);
		  }
		}
		else {
			tmp2[0]=0;
			tmp3=de_space(tmp2+1);
			tmp2=de_space(str);
			if (l) fprintf(sas, "\n %s(upcase('%s')<=:upcase(%s)<=:upcase('%s')) ", i ? " or " : " ", 
				tmp2, name2, tmp3);
			else fprintf(sas, "\n %s(%s<=%s<=%s) ", i ? " or " : " ", 
				tmp2, name2, tmp3);
		}
	}
   }
	fprintf(sas, " );");
/*
	fprintf(sas, "\n run;");
*/
}

void sas_pop_type3(VARI * vari_p, FILE * sas, int l) {
	int i;
	char *tmp, *tmp2, *tmp3, *name, *prompt, str[BUFFER_N];

	tmp=strcpy(str, vari_p->value);
	tmp=de_space(tmp);
	name=vari_p->name_ptr->name_pop;
	prompt=vari_p->name_ptr->prompt;
	for (i=0; ; i++) {
		if (!(tmp=sas_type2_cut(tmp, str))) break;
		if (!(tmp2=strchr(str, '-'))) {
			if (!(tmp2=strchr(str, '+'))) {
				tmp2=de_space(str);
				if (_flag_ > 1) {
					if (l) printf("\n\t %s(%s=:'%s') ", i ? " or " : " ", prompt, tmp2);
					else printf("\n\t %s(%s=%s) ", i ? " or " : " ", prompt, tmp2);
				}
				if (l) fprintf(sas, "\n\t %s(upcase(%s)=:upcase('%s')) ", i ? " or " : " ", name, tmp2);
				else fprintf(sas, "\n\t %s(%s=%s) ", i ? " or " : " ", name, tmp2);
			}
			else {
				tmp2[0]=0;
				tmp2=de_space(str);
				if (_flag_ > 1) {
					if (l) printf("\n\t %s(%s>=:'%s') ", i ? " or " : " ", prompt, tmp2);
					else printf("\n\t %s(%s>=%s) ", i ? " or " : " ", prompt, tmp2);
				}
				if (l) fprintf(sas, "\n\t %s(upcase(%s)>=:upcase('%s')) ", i ? " or " : " ", name, tmp2);
				else fprintf(sas, "\n\t %s(%s>=%s) ", i ? " or " : " ", name, tmp2);
			}
		}
		else {
			tmp2[0]=0;
			tmp3=de_space(tmp2+1);
			tmp2=de_space(str);
			if (_flag_ > 1) {
				if (l) printf("\n\t %s('%s' <=: %s <=: '%s') ", i? " or " : " ", tmp2, prompt, tmp3);
				else printf("\n\t %s(%s <= %s <= %s) ", i ? " or " : " ", tmp2, prompt, tmp3);
			}
			if (l) fprintf(sas, "\n\t %s(upcase('%s') <=: upcase(%s) <=: upcase('%s')) ", i? " or " : " ", tmp2, name, tmp3);
			else fprintf(sas, "\n\t %s(%s <= %s <= %s) ", i ? " or " : " ", tmp2, name, tmp3);
		}
	}
}

void sas_pop_group(FILE * sas, VARI * vari_p) {
	char buf1[BUFFER_N], buf2[BUFFER_N], *tmp;
	int i, j, d;
	VARI ** v_ptr;
	NAME * name_p;

	fprintf(sas, "\n\n/* Following codes from sas_pop_group() */");
	strcpy(buf1, vari_p->value);
	strcpy(buf2, vari_p->name_ptr->name_html);

	if (numberValue(buf1) && (tmp=strstr(buf2, "_f"))) {
	  tmp[0]=0;
	  strcat(buf2, buf1);
	}
	else strcpy(buf2, buf1);

	//if (tmp=strstr(buf2, "_f")) {
		v_ptr=find_vari(buf2, 1, 3, &d);
		if (v_ptr && d>0) {
			name_p=vari_p->name_ptr;
/*
			fprintf(sas, "\n data poptmp;");
			fprintf(sas, "\n\t set poptmp;");
*/
			fprintf(sas, "\n%s=0;", name_p->name_html);
			j= (!(strcmp(v_ptr[0]->name_ptr->type1, "char")));

			for (i=0; i<d; i++) {
				fprintf(sas, "\n if (");
				sas_pop_type3(v_ptr[i], sas, j);
				fprintf(sas, "\n ) then %s=%d;", name_p->name_html, i+1);
			}
			if (!_flag_) _flag_=1;
			fprintf(sas, "\n\t if (%s >0);", name_p->name_html);
/*
			fprintf(sas, "\n run;");
*/
		}
		free(v_ptr);
	//}
}

void sas_pop_select(FILE *sas, char *name) {
	int i, j, c;
	char *tmp, *tmp2, str[STRING_N];
	VARI ** v_ptr;

	fprintf(sas, "\n\n/* Following codes from sas_pop_select() */");
	if (!(tmp=find_path(name))) hbase_error(48, name); 
	if ((tmp2=find_path("pop_where"))) {
	  tmp2=data_where_cr(tmp2);
	  sprintf(str, " (where=(%s)) ", tmp2);
	}
	else tmp2=NULL;
	fprintf(sas, "\n data poptmp;");
	fprintf(sas, "\n\t set pop.%s%s;", tmp, tmp2? str : "");
	fprintf(sas, "\n%s", _length_buf);

	for (i=0; i < h_name_i; i++) {
		j=atoi(h_name[i]->type2);
		if (filterExcluded(h_name[i])) continue;
		if ((j==0 || j==1 || j==3 || j==8) && h_name[i]->name_pop) {
			v_ptr=find_vari(h_name[i]->name_html, 1, j, &c);
			if (!strcmp(h_name[i]->name_html, "cause_f")) continue;
			if (c <= 0 || !v_ptr) continue;
			switch(j) {
			case 0: sas_pop_type1(sas, v_ptr, c);
				break;
			case 1: sas_pop_type2(sas, v_ptr, c);
				break;
			case 3: sas_pop_type2(sas, v_ptr, c);
				break;
			case 8: sas_pop_group(sas, v_ptr[0]);
				break;
			default: break;
			}
		}
	}
	sas_cross_bld(sas, "cross1", "poptmp");
	sas_cross_bld(sas, "cross2", "poptmp");

	if (_proxy1_buf[0]) fprintf(sas, "\n %s=trim(left(%s));", _proxy1_buf, _proxy1_buf);
	if (_proxy2_buf[0]) fprintf(sas, "\n %s=trim(left(%s));", _proxy2_buf, _proxy2_buf);
	fprintf(sas, "\n run;");
}

void sas_pop_select_nogeo(FILE *sas, char *name) {
	int i, j, c;
	char *tmp, *tmp2, str[STRING_N];
	VARI ** v_ptr;

	fprintf(sas, "\n\n/* Following codes from sas_pop_select() */");
	if (!(tmp=find_path(name))) hbase_error(48, name); 
	if ((tmp2=find_path("pop_where"))) {
	  tmp2=data_where_cr(tmp2);
	  sprintf(str, " (where=(%s)) ", tmp2);
	}
	else tmp2=NULL;
	fprintf(sas, "\n data poptmpnogeo;");
	fprintf(sas, "\n\t set pop.%s%s;", tmp, tmp2? str : "");

	for (i=0; i < h_name_i; i++) {
		j=atoi(h_name[i]->type2);
		if ((j==0 || j==1 || j==3 || j==8) && h_name[i]->name_pop) {
			v_ptr=find_vari(h_name[i]->name_html, 1, j, &c);
			if (!strcmp(h_name[i]->name_html, "cause_f")) continue;
			if (c <= 0 || !v_ptr) continue;
			if (!strncmp(v_ptr[0]->name_ptr->name_html, "Geo", 3)) continue;
			switch(j) {
			case 0: sas_pop_type1(sas, v_ptr, c);
				break;
			case 1: sas_pop_type2(sas, v_ptr, c);
				break;
			case 3: sas_pop_type2(sas, v_ptr, c);
				break;
			case 8: sas_pop_group(sas, v_ptr[0]);
				break;
			default: break;
			}
		}
	}
	sas_cross_bld(sas, "cross1", "poptmp");
	sas_cross_bld(sas, "cross2", "poptmp");

	fprintf(sas, "\n run;");
}

void sas_out(FILE * sas, char * dy, char * dl, int small) {
	char str[BUFFER_N], *tmp, *tmp1, *tmp2, *type1, *type2;
	NAME *  n_ptr;
	char c1[BUFFER_N], c2[BUFFER_N], p1[BUFFER_N], p2[BUFFER_N];

	fprintf(sas, "\n\n/* Following codes from sas_out() */");
	sas_find_cross(c1, c2, p1, p2);
	if (c1[0]) tmp1=c1;
	else tmp1=NULL;
	if (c2[0]) tmp2=c2;
	else tmp2=NULL;
	type1="num";
	type2=type1;

/*
	if (tmp1=find_path("cross1")) {
		if (!(n_ptr=find_name(tmp1, 1))) tmp1=NULL;
		else {
			tmp1=n_ptr->name_sas;
			type1=n_ptr->type1;
		}
	}
	if (tmp2=find_path("cross2")) {
		if (!strcmp(tmp2, "none")) tmp2=NULL;
		else {
			if (!(n_ptr=find_name(tmp2, 1))) tmp2=NULL;
			else {
				tmp2=n_ptr->name_sas;
				type2=n_ptr->type1;
			}
		}
	}
*/

	fprintf(sas, "\n data _null_;");
	fprintf(sas, "\n set tmp;");
	tmp=get_sasname(str);
	fprintf(sas, "\n file \"%s.dat\" lrecl=80;", tmp);
	if (tmp1) if (strcmp(type1, "num")) 
			fprintf(sas, "\n put @1 %s $10. ", tmp1);
		  else fprintf(sas, "\n put @1 %s 10. ", tmp1);
	else fprintf(sas, "put ' '");
	if (tmp2) if (strcmp(type2, "num"))
			fprintf(sas, " @16 %s $10. @;", tmp2);
		  else fprintf(sas, " @16 %s 10. @;", tmp2);
	else fprintf(sas, " @;");
	if (small && (tmp=find_path("small_num")) 
		&& (atoi(tmp)>0)) {
		fprintf(sas, "\n if (%s < %s) then put @31 'X';", dy,tmp);
		fprintf(sas, "\n else put @31 %s %s;", dy, dl);
	}
	else fprintf(sas, "\n put @31 %s %s;", dy, dl);
	fprintf(sas, "\n run;");
}

void sas_out_l(FILE * sas, char * dy, char * dl) {
	char str[BUFFER_N], *tmp, *tmp1, *tmp2, *type1, *type2;
	NAME *  n_ptr;

	fprintf(sas, "\n\n/* Following codes from sas_out_l() */");
	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n set tmp;");
	fprintf(sas, "\n if (number<15) then %s=.;", dy);
	fprintf(sas, "\n run;");

	if (tmp1=find_path("cross1")) {
		if (!(n_ptr=find_name(tmp1, 1))) tmp1=NULL;
		else {
			tmp1=n_ptr->name_sas;
			type1=n_ptr->type1;
		}
	}
	if (tmp2=find_path("cross2")) {
		if (!strcmp(tmp2, "none")) tmp2=NULL;
		else {
			if (!(n_ptr=find_name(tmp2, 1))) tmp2=NULL;
			else {
				tmp2=n_ptr->name_sas;
				type2=n_ptr->type1;
			}
		}
	}

	fprintf(sas, "\n\n data _null_;");
	fprintf(sas, "\n set tmp;");
	tmp=get_sasname(str);
	fprintf(sas, "\n file \"%s.dat\" lrecl=80;", tmp);
	if (tmp1) if (strcmp(type1, "num")) 
			fprintf(sas, "\n put @1 %s $10. ", tmp1);
		else fprintf(sas, "\n put @1 %s 10. ", tmp1);
	if (tmp2) if (strcmp(type2, "num"))
			fprintf(sas, " @16 %s $10. @;", tmp2);
		else fprintf(sas, " @16 %s 10. @;", tmp2);
	else fprintf(sas," @;");
	if ((tmp=find_path("small_num")) && (atoi(tmp)>0)) {
		fprintf(sas, "if (number < %s) then put  @31 'X'; ", tmp);
		fprintf(sas, "else put @31 %s %s;", dy, dl);
    }
	else fprintf(sas, "\n put @31 %s %s;", dy, dl);
	fprintf(sas, "\n run;");
}

void sas_out_3(FILE * sas, char ** dx, char *lbl_name, int length, char *snum, char *spop) {
	int i, j, k;
	char c1[STRING_N], c2[STRING_N], p1[STRING_N], p2[STRING_N];
	char str[STRING_N], *tmp, *tmp1, *tmp2, *tmp3;
	NAME *  n_ptr;

	fprintf(sas, "\n\n/* Following codes from sas_out_3() */");
	sas_find_cross(c1, c2, p1, p2);

	if (tmp1=find_path("cross1")) {
		if (!(n_ptr=find_name(tmp1, 1))) tmp1=NULL;
		else {
			tmp1=n_ptr->name_sas;
		}
	}
	if (tmp2=find_path("cross2")) {
		_cross_2=malloc(strlen(tmp2)+1);
		strcpy(_cross_2, tmp2);
		strcpy(tmp2, lbl_name);
	}

	fprintf(sas, "\n data _null_;");
	fprintf(sas, "\n set tmp;");
	tmp=get_sasname(str);
	fprintf(sas, "\n file \"%s.dat\" lrecl=80;", tmp);

	if (!(tmp=find_path("small_num"))) {tmp="."; j=0;}
	else j=1;
	if (!(tmp3=find_path("small_pop"))) {tmp3="."; k=0;}
	else k=1;

	for (i=0; i<length; i++) {
	    if (strcmp(n_ptr->type1, "num"))
           	fprintf(sas, "\n put @1 %s $10. ", c1);
            else fprintf(sas, "\n put @1 %s 10. ", c1);
            fprintf(sas, " @16 '%d' @ ;", i+1);

	    if (j && snum && k && spop) {
		if (!strstr(dx[i], spop)) {
		    fprintf(sas, "\n if (%s < %s or %s < %s) then put @31 'X';", snum, tmp, spop, tmp3);
		    fprintf(sas, "\n else put @31 %s ;", dx[i]);
		}
		else fprintf(sas, "\n put @31 %s ;", dx[i]);

	    }
	    else if (j && snum) {
		if (!strstr(dx[i], snum)) {
		    fprintf(sas, "\n if (%s < %s) then put @31 'X';", snum, tmp);
		    fprintf(sas, "\n else put @31 %s ;", dx[i]);
		}
		else {
			fprintf(sas, "\n put @31 %s ;", dx[i]);
		}
	    }
	    else if (k && spop) {
		if (!strstr(dx[i], spop)) {
		    fprintf(sas, "\n if (%s < %s) then put @31 'X';", spop, tmp3);
		    fprintf(sas, "\n else put @31 %s ;", dx[i]);
		}
		else fprintf(sas, "\n put @31 %s ;", dx[i]);
	    }
	    else fprintf(sas, "\n put @31 %s;", dx[i]);
	}
	fprintf(sas, "\n run;");
}

char * data_where_cr(char * dw) {
	int i, j, k, len=strlen(dw);
	char * buf;
	len=len+(len/80)+8;

	if (!(buf=(char *) malloc(len))) 
		hbase_error(3, "data_where");
	i=0; k=0;
	for (j=0; j<strlen(dw); j++) {
		buf[k++]=dw[j];
		i++;
		if ((dw[j]==',' || dw[j]==' ') && i>60) {
		  buf[k++]='\n';
		  i=0;
		}
	}
	buf[k]=0;
        return buf;
}

int filterExcluded(NAME *name) {
	char * tmp, str[BUFFER_N];
	char ** feA;
	int i, c;

	feA=filterExclude(&c);
//printf("\n feA--*%d c--*%d", feA, c); fflush(stdout);
	if (feA==NULL || c<=0) return 0;

	for (i=0; i<c; i++) {
		if (!(strcmp(feA[i], name->name_html))) return 1;
	}
/*
	tmp=find_path("filter_exclude");
	if (!tmp) return 0;

	str[0]=' ';
	str[1]=0;
	strcat(str, name->name_html);
	if (strstr(tmp, str)) return 1;
	strcat(str, " ");
	if (strstr(tmp, str)) return 1;
	if (strstr(tmp, str+1)) return 1;
*/
	return 0;
}

void sas_dataFrame_cross(FILE *sas) {
	char *c1, *c2, *cross1, *cross2;
	VARI ** vpr1=NULL, ** vpr2=NULL;
	int i, j, cnt1=0, cnt2=0;
	int proxy1=0, proxy2=0;
	char ** list1, ** list2;

	fprintf(sas, "\n/* following code from data_Frame_cross. */\n");
	_length_buf[0]=0;
	_proxy1_buf[0]=0;
	_proxy2_buf[0]=0;

	/*sas_find_cross(c1, c2, p1, p2);*/
	c1=find_path("cross1");
	if (c1 && !strcmp(c1, "none")) c1=NULL;
	if (c1 && !strcmp(c1, "null")) c1=NULL;
	c2=find_path("cross2");
	if (c2 && !strcmp(c2, "none")) c2=NULL;
	if (c2 && !strcmp(c2, "null")) c2=NULL;

	if (c1) {
		vpr1=find_vari(c1, 1, 0, &cnt1);
		if (vpr1==NULL || cnt1<=0) {
			vpr1=find_vari(c1, 1, 10, &cnt1);
			if (vpr1 && cnt1>0) {
				cross1=vpr1[0]->value;
				vpr1=find_vari(cross1, 1, 3, &cnt1);
				if (vpr1 && cnt1>0) {
					proxy1=1;
				}
				else {
				  vpr1=find_vari(cross1, 1, 0, &cnt1);
				  if (vpr1 && cnt1>0) {
					proxy1=0;
				  }
				}
			}
		}

		if (vpr1 && cnt1>0) {
			if (!(list1=(char **) malloc(cnt1*sizeof(char *)))) 
				hbase_error(3, "sas_dateFrame_corss-1");
			fprintf(sas, "\n data df_%s;", proxy1? c1 : vpr1[0]->name_ptr->name_sas);
			fprintf(sas, "\n length count 8. ");
			if (!strcmp(vpr1[0]->name_ptr->type1, "num")) {
				fprintf(sas, "%s %s. ;", proxy1? c1 : vpr1[0]->name_ptr->name_sas, vpr1[0]->name_ptr->note);
				sprintf(_length_buf, "length %s %s. ;", proxy1? c1 : vpr1[0]->name_ptr->name_sas, vpr1[0]->name_ptr->note);
			}
			else {
				fprintf(sas, "%s $%s. ;", proxy1? c1 : vpr1[0]->name_ptr->name_sas, vpr1[0]->name_ptr->note);
				strcpy(_proxy1_buf, proxy1? c1 : vpr1[0]->name_ptr->name_sas);
				sprintf(_length_buf, "length %s $%s. ;", _proxy1_buf, vpr1[0]->name_ptr->note);
			}
			fprintf(sas, "\n input count %s;", proxy1? c1 : vpr1[0]->name_ptr->name_sas);
			fprintf(sas, "\n cards; ");

			for (i=0; i<cnt1; i++) {
				if (proxy1) {
					if (!(list1[i]=(char *) malloc(5*sizeof(char)))) 
						hbase_error(3, "sas_dateFrame_corss-2");
					sprintf(list1[i], "%d", i+1);
				}
				else { 
					if (!(list1[i]=(char *) malloc((strlen(vpr1[i]->value)+1)*sizeof(char)))) 
						hbase_error(3, "sas_dateFrame_corss-2");
					strcpy(list1[i], vpr1[i]->value);
				}	
				fprintf(sas, "\n 0 %s", list1[i]);	
			}
			fprintf(sas, "\n ; \n run;");
		}
	}

	if (c2) {
		vpr2=find_vari(c2, 1, 0, &cnt2);
		if (vpr2==NULL || cnt1<=0) {
			vpr2=find_vari(c2, 1, 10, &cnt2);
			if (vpr2 && cnt2>0) {
				cross2=vpr2[0]->value;
				vpr2=find_vari(cross2, 1, 3, &cnt2);
				if (vpr2 && cnt2>0) {
					proxy2=1;
				}
				else {
				  vpr2=find_vari(cross2, 1, 0, &cnt2);
				  if (vpr2 && cnt2>0) {
					proxy2=0;
				  }
				}
			}
		}

		if (vpr2 && cnt2>0) {
			if (!(list2=(char **) malloc(cnt2*sizeof(char *)))) 
				hbase_error(3, "sas_dateFrame_corss-1");
			fprintf(sas, "\n data df_%s;", proxy2? c2 : vpr2[0]->name_ptr->name_sas);
			fprintf(sas, "\n length count 8. ");
			if (!strcmp(vpr2[0]->name_ptr->type1, "num")) {
				fprintf(sas, "%s %s. ;", proxy2? c2 : vpr2[0]->name_ptr->name_sas, vpr2[0]->name_ptr->note);
				sprintf(_length_buf, "length %s %s. ;", proxy2? c2 : vpr2[0]->name_ptr->name_sas, vpr2[0]->name_ptr->note);
			}
			else {
				fprintf(sas, "%s $%s. ;", proxy2? c2 : vpr2[0]->name_ptr->name_sas, vpr2[0]->name_ptr->note);
				strcpy(_proxy2_buf, proxy2? c2 : vpr2[0]->name_ptr->name_sas);
				sprintf(_length_buf, "length %s $%s. ;", _proxy2_buf, vpr2[0]->name_ptr->note);
			}
			fprintf(sas, "\n input count %s;", proxy2? c2 : vpr2[0]->name_ptr->name_sas);
			fprintf(sas, "\n cards; ");

			for (i=0; i<cnt2; i++) {
				if (proxy2) {
					if (!(list2[i]=(char *) malloc(5*sizeof(char)))) 
						hbase_error(3, "sas_dateFrame_corss-2");
					sprintf(list2[i], "%d", i+1);
				}
				else { 
					if (!(list2[i]=(char *) malloc((strlen(vpr2[i]->value)+1)*sizeof(char)))) 
						hbase_error(3, "sas_dateFrame_corss-2");
					strcpy(list2[i], vpr2[i]->value);
				}	
				fprintf(sas, "\n 0 %s", list2[i]);	
			}
			fprintf(sas, "\n ; \n run;");
		}
	}

	if (vpr1 && cnt1>0 && vpr2 && cnt2>0) {
		fprintf(sas, "\n data df_%s%s;", proxy1? c1 : vpr1[0]->name_ptr->name_sas, proxy2? c2 : vpr2[0]->name_ptr->name_sas);
		fprintf(sas, "\n length count 8. ");
		sprintf(_length_buf, "\n length count 8. ");
		if (!strcmp(vpr1[0]->name_ptr->type1, "num")) {
			fprintf(sas, "%s %s. ", proxy1? c1 : vpr1[0]->name_ptr->name_sas, vpr1[0]->name_ptr->note);
			strcpy(_proxy1_buf, proxy1? c1 : vpr1[0]->name_ptr->name_sas);
			strcat(_length_buf, _proxy1_buf);
			strcat(_length_buf, " ");
			strcat(_length_buf, vpr1[0]->name_ptr->note);
			strcat(_length_buf, ". ");
		}
		else {
			fprintf(sas, "%s $%s. ", proxy1? c1 : vpr1[0]->name_ptr->name_sas, vpr1[0]->name_ptr->note);
			strcpy(_proxy1_buf, proxy1? c1 : vpr1[0]->name_ptr->name_sas);
			strcat(_length_buf, _proxy1_buf);
			strcat(_length_buf, " $");
			strcat(_length_buf, vpr1[0]->name_ptr->note);
			strcat(_length_buf, ". ");
		}
		if (!strcmp(vpr2[0]->name_ptr->type1, "num")) {
			fprintf(sas, "%s %s. ;", proxy2? c2 : vpr2[0]->name_ptr->name_sas, vpr2[0]->name_ptr->note);
			strcpy(_proxy2_buf, proxy2? c2 : vpr2[0]->name_ptr->name_sas);
			strcat(_length_buf, _proxy2_buf);
			strcat(_length_buf, " ");
			strcat(_length_buf, vpr2[0]->name_ptr->note);
			strcat(_length_buf, ".;");
		}
		else {
			fprintf(sas, "%s $%s. ;", proxy2? c2 : vpr2[0]->name_ptr->name_sas, vpr2[0]->name_ptr->note);
			strcpy(_proxy2_buf, proxy2? c2 : vpr2[0]->name_ptr->name_sas);
			strcat(_length_buf, _proxy2_buf);
			strcat(_length_buf, " $");
			strcat(_length_buf, vpr2[0]->name_ptr->note);
			strcat(_length_buf, ".;");
		}
		fprintf(sas, "\n input count %s %s;", proxy1? c1 : vpr1[0]->name_ptr->name_sas, proxy2? c2 : vpr2[0]->name_ptr->name_sas);
		fprintf(sas, "\n cards; ");
		for (i=0; i<cnt1; i++) {
			for (j=0; j<cnt2; j++) {
				fprintf(sas, "\n 0 %s %s", list1[i], list2[j]);	
			}
		}
		fprintf(sas, "\n ; \n run;");
		
	}
}

void sas_dataFrame(FILE * sas) {
	char * tmp, str[BUFFER_N], buf[BUFFER_N];
	VARI ** vpr;
	int c, i;
	char c1[BUFFER_N], c2[BUFFER_N], p1[BUFFER_N], p2[BUFFER_N];

	tmp=find_path("data_frame");
	fprintf(sas, "\n/* following code from dataFrame111. */\n");
	if (tmp==NULL) return;


	while(tmp) {
	strcpy(str, tmp);
	tmp=strchr(str, ' ');
	if (tmp!=NULL) tmp[0]=0;
	vpr=find_vari(str, 1, 0, &c);
	if (vpr==NULL || c<=0) {
		strcpy(buf, "dataframe_");
		strcat(buf, str);

	fprintf(sas, "\n/* following code from dataFrame. %s*/\n", buf);
		vpr=find_vari(buf, 1, 0, &c);
		if (vpr==NULL || c<=0) return;
	}

	fprintf(sas, "\n data df_%s;", str);
	fprintf(sas, "\n length count 3. ");
	if (!strcmp(vpr[0]->name_ptr->type1, "num")) 
		fprintf(sas, "%s %s. ;", vpr[0]->name_ptr->name_sas, vpr[0]->name_ptr->note);
	else fprintf(sas, "%s $%s. ;", vpr[0]->name_ptr->name_sas, vpr[0]->name_ptr->note);
	fprintf(sas, "\n input count %s;", vpr[0]->name_ptr->name_sas);
	fprintf(sas, "\n cards; ");

	for (i=0; i<c; i++) {
		fprintf(sas, "\n 0 %s", vpr[i]->value);	
	}
	fprintf(sas, "\n ; \n run;");

	if (tmp==NULL) break;
	tmp=tmp+1;
	}
}

void sas_select(FILE * sas) {
	char * tmp, *tmp2, str[BUFFER_N];
	int i, j, c, flag=0;
	VARI ** vari_ptr;

	fprintf(sas, "\n\n/* Following codes from sas_select() 111*/");
	if ((tmp2=find_path("data_where"))) {
	  tmp2=data_where_cr(tmp2);
	  sprintf(str, " (where=(%s)) ", tmp2);
	}
	else tmp2=NULL;

	tmp=find_path("dataset");
	if (form>0 && form!=3 && form!=4 && form!=6 && form!=8
		&& form!=21 && form!=22 && form!=23  && form!=30) {
		printf("\n<B><FONT SIZE = \"+2\"> Query: </FONT>%s<UL><I>", tmp? tmp : "no dataset name");
	}
	fprintf(sas, "\n data tmp;");
	if (!(tmp=find_path("sasdata"))) hbase_error(7, "sasdata");
	fprintf(sas, "\n set data.%s %s end = eof;", tmp, tmp2? str : "");
	fprintf(sas, "\n retain flag 0;");
/*
	fprintf(sas, "\n x=1;");
*/

	_flag_ = 0;
	for (i=0; i<h_name_i; i++) {
		j = atoi(h_name[i]->type2);
		if (filterExcluded(h_name[i])) continue;
	//	if (j==0 || j==1) {
		if (j==0 || j==1 || j==3 || j==5) {
			if ((vari_ptr=find_vari(h_name[i]->name_html,1,j,&c))) {
				if (c<=0 || !strlen(de_space(vari_ptr[0]->value))
					 || (!(vari_ptr[0]->name_ptr->name_sas) && j!=5)) continue;
	//			if (c==1) sequence_erase(vari_ptr[0]->name_ptr->name_html);
				sas_vari_bld(vari_ptr, sas, c, flag);
				free(vari_ptr);
				vari_ptr=NULL;
				flag = 1;
				_flag_ = flag;
			}
		}
	}

	if (flag) {
		fprintf(sas, "\n then do;");
		fprintf(sas, "\n goto next%d;", _next_);
		fprintf(sas, "\n end;");
		fprintf(sas, "\n else goto no_obs;");
/*
		fprintf(sas, "\n if eof and flag = 0 then do;");
		fprintf(sas, "\n file print notitles;");
		fprintf(sas, "\n put \'************************************************\';");
		fprintf(sas, "\n put \'  Sorry, <B>NO OBSERVATION</B> for this query!\';");
		fprintf(sas, "\n put \'************************************************\';");
		fprintf(sas, "\n end;");
*/
	}

	fflush(stdout);
/*
	fprintf(sas, "\n run;");
	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n set tmp;");
*/
}

void sas_select_nogeo(FILE * sas) {
	char * tmp, *tmp2, str[BUFFER_N];
	int i, j, c, flag=0;
	VARI ** vari_ptr;

	fprintf(sas, "\n\n/* Following codes from sas_select_nogeo() 111*/");
	if ((tmp2=find_path("data_where"))) {
	  tmp2=data_where_cr(tmp2);
	  sprintf(str, " (where=(%s)) ", tmp2);
	}
	else tmp2=NULL;

	tmp=find_path("dataset");
	fprintf(sas, "\n data tmpnogeo;");
	if (!(tmp=find_path("sasdata"))) hbase_error(7, "sasdata");
	fprintf(sas, "\n set data.%s %s end = eof;", tmp, tmp2? str : "");
	fprintf(sas, "\n retain flag 0;");

	_flag_ = 0;
	for (i=0; i<h_name_i; i++) {
		j = atoi(h_name[i]->type2);
	//	if (j==0 || j==1) {
		if (j==0 || j==1 || j==3 || j==5) {
			if ((vari_ptr=find_vari(h_name[i]->name_html,1,j,&c))) {
				if (c<=0 || !strlen(de_space(vari_ptr[0]->value))
					 || (!(vari_ptr[0]->name_ptr->name_sas) && j!=5)) continue;
	//			if (c==1) sequence_erase(vari_ptr[0]->name_ptr->name_html);
				if (!strncmp(vari_ptr[0]->name_ptr->name_html, "Geo", 3)) continue;
					
				sas_vari_bld(vari_ptr, sas, c, flag);
				free(vari_ptr);
				vari_ptr=NULL;
				flag = 1;
				_flag_ = flag;
			}
		}
	}

	if (flag) {
		fprintf(sas, "\n then do;");
		fprintf(sas, "\n goto next%d;", _next_);
		fprintf(sas, "\n end;");
		fprintf(sas, "\n else goto no_obs;");
	}

	fflush(stdout);
}
		
void sas_no_obs(FILE * sas) {
char * tmp, str[BUFFER_N];
	tmp=get_sasname(str);
	if (_proxy1_buf[0]) fprintf(sas, "\n %s=trim(left(%s));", _proxy1_buf, _proxy1_buf);
	if (_proxy2_buf[0]) fprintf(sas, "\n %s=trim(left(%s));", _proxy2_buf, _proxy2_buf);
fprintf(sas, "\n output;");
fprintf(sas, "\n no_obs:");
fprintf(sas, "\n run;");
fprintf(sas, "\n proc contents data=tmp out=cont noprint;");
fprintf(sas, "\n data _null_;");
fprintf(sas, "\n set cont;");
fprintf(sas, "\n if nobs=0 and _n_ = 1 then do;");
fprintf(sas, "\n file print notitles;");
//fprintf(sas, "\n put \'************************************************\';");
fprintf(sas, "\n put \'  Sorry, NO OBSERVATION for this query!\';");
//fprintf(sas, "\n put \'************************************************\';");
fprintf(sas, "\n put ;");
fprintf(sas, "\n file '%s.dat';", tmp);
fprintf(sas, "\n put ;");
fprintf(sas, "\n end;");
fprintf(sas, "\n else if _n_=1 then do;");
fprintf(sas, "\n file print notitles;");
//fprintf(sas, "\n put \'************************************************\';");
fprintf(sas, "\n put \'  Sorry, SAS ERROR for this query!\';");
//fprintf(sas, "\n put \'************************************************\';");
fprintf(sas, "\n put ;");
fprintf(sas, "\n file '%s.dat';", tmp);
fprintf(sas, "\n put ;");
fprintf(sas, "\n end;");
fprintf(sas, "\n run;");
}

void sas_vari_bld(VARI ** v_ptr, FILE * sas, int c, int flag) {
	int j;
	char str[BUFFER_N];
	
	fprintf(sas, "\n /* sas_vari_bld %s  */", v_ptr[0]->name_ptr->name_sas);
	j = atoi(v_ptr[0]->name_ptr->type2);
	if (j==2) {
		strcpy(str, v_ptr[0]->value);
		if (strlen(de_space(str))==0) return;
	}
	if (form>0 && form!=3 && form!=4 && form!=6 && form!=8
		&& form!=21 && form!=22 && form!=23 && form!=30) {
		printf("\n %s ( ", flag ? "<LI>and" : "<LI>");
	}
	fprintf(sas, "\n %s ( ", flag ? "and" : "if");
fprintf(sas, "\n/* j---------type2----------*%d */", j);
	switch(j) {
		case 0: sas_type1(v_ptr, sas, c, form);
			break;
		case 1: sas_type2(v_ptr, sas, c, form);
			break;
		case 3: sas_type2(v_ptr, sas, c, form);
			break;
		case 5: sas_type5(v_ptr, sas, c, form);
			break;
		case 9: break;
		default: hbase_error(17, v_ptr[0]->name_ptr->type2);
			break;
	}
		if (form>0 && form!=3 && form!=4 && form!=6 && form!=8
			&& form!=21 && form!=22 && form!=23  && form!=30) 
			 printf("\n )");
	fprintf(sas, "\n )");
}

char * sas_type2_cut(char * buf, char * back) {
	int flag1=0, flag2=0, flag3=0;
	unsigned short i, j=0;
	static char str[BUFFER_N];

	if (buf[0]==0) return NULL;

	for (i=0; i<strlen(buf); i++) {
		if (buf[i]!='.') {
			str[j]=buf[i];
			j++;
		}
	}
	str[j]=0;
	j=0;
	for (i=0; i<strlen(str); i++) {
		if ((str[i]==' ' || str[i]==',') && !flag1) continue;
		if ((str[i]==' ' || str[i]==',') && flag1) { flag3=1; continue;}
		if (str[i]=='-') {
			if (!flag1 || flag2) continue;
			flag1=0;
			flag2=1;
			flag3=0;
			back[j]=str[i];
			j++;
			continue;
		}
		if (flag3) {
			back[j]=0;
			return(str+i);
		}
		flag1=1;
		back[j]=str[i];
		j++;
	}
	back[j]=0;
	if (strlen(back)) return(str+i);
	return NULL;
}

char * sas_type2_label(char * value, char * name, char * buf) {
	FILE * lbl;
	int i;
	char * tmp;

	sprintf(buf, "%s.lbl", name);
	if (!(lbl=file_open(buf, 0))) return NULL;
	i=strlen(value);
	while (!feof(lbl)) {
		if (!(tmp=fgets(buf, BUFFER_N, lbl))) break;
		if (!strncmp(value, tmp, i) && (tmp[i]=='@')) {
			strcpy(buf, tmp+i+1);
			fclose(lbl);
			return buf;
		}
	}
	fclose(lbl);
	return NULL;
}

void sas_type2(VARI ** v_ptr, FILE * sas, int c, int out) {
	char * name, *name2, * tmp, *tmp2, *tmp3, str[BUFFER_N];
	int i, j=1, k, l=0;

// fprintf(sas, "\n /* sas_type2 -- %s -- %d */", v_ptr[0]->name_ptr->name_html, c);
	if (!strcmp(v_ptr[0]->name_ptr->type1, "char")) l=1;
	else if (!strcmp(v_ptr[0]->name_ptr->type1, "date")) l=2;

	name=v_ptr[0]->name_ptr->prompt;
	name2=v_ptr[0]->name_ptr->name_sas;
   for (k=0; k<c; k++) {
	tmp=v_ptr[k]->value;
	if (strlen(tmp)>BUFFER_N) hbase_error(18, tmp);
	tmp2=v_ptr[k]->label;
	if (tmp2) {
	if (form>0 && form!=3 && form!=4 && form!=6 && form!=8
		&& form!=21 && form!=22 && form!=23 && form!=30) {
			if (l) printf("\n %s%s = '%s'", k ? "<br>or " : " ", name, tmp2);
			else printf("\n %s%s = %s", k ? "<br>or " : " ", name, tmp2);
		}
		j=0;
	}
	else {
	if (form>0 && form!=3 && form!=4 && form!=6 && form!=8
		&& form!=21 && form!=22 && form!=23 && form!=30) {
			printf("\n %s", k ? "or " : "");
		}
		j=1;
	}
	fprintf(sas, "\n %s", k ? "or " : "");
	for (i=0; ; i++) {
		if (!(tmp=sas_type2_cut(tmp, str))) break;
		if ((tmp2=strchr(str, '-'))) {
			tmp2[0]=0;
			tmp3=de_space(tmp2+1);
			tmp2=de_space(str);
			if (j) { 
				if (form>0 && form!=3 && form!=4 && form!=6 && form!=8
					&& form!=21 && form!=22 && form!=23 && form!=30) {
					if (l) printf("\n %s('%s'<=:(%s)<=:'%s') ", i ? " or " : " ", 
						tmp2, name, tmp3);
					else printf("\n %s(%s<=(%s)<=%s) ", i ? " or " : " ", 
						tmp2, name, tmp3);
				}
			}
			if (l==1) fprintf(sas, "\n %s(upcase('%s')<=:upcase(%s)<=:upcase('%s')) ", i ? " or " : " ", 
				tmp2, name2, tmp3);
			else if (l==2) fprintf(sas, "\n %s(input('%s', mmddyy12.)<=%s<=input('%s', mmddyy12.)) ", i ? " or " : " ", 
				tmp2, name2, tmp3);
			else fprintf(sas, "\n %s(%s<=%s<=%s) ", i ? " or " : " ", 
				tmp2, name2, tmp3);
		}
		else if ((tmp2=strchr(str, '+'))) {
			tmp2[0]=0;
			if (j && out) {
				if (l) printf("\n %s(%s>=:'%s') ", i ? " or " : " ", 
				name, str);
				else printf("\n %s(%s>=%s) ", i ? " or " : " ", 
				name, str);
			}
			if (l==1) fprintf(sas, "\n %s(upcase(%s)>=:upcase('%s')) ", i ? " or " : " ", 
				name2, str);
			else if (l==2) fprintf(sas, "\n %s(%s>=input('%s', mmddyy12.)) ", i ? " or " : " ", 
				name2, str);
			else fprintf(sas, "\n %s(%s>=%s) ", i ? " or " : " ", 
				name2, str);
		}
		else if ((tmp2=strstr(str, "<="))) {
			tmp2[0]=0;
			if (j && out) {
				if (l) printf("\n %s(''<%s<=:'%s') ", i ? " or " : " ", 
				name, tmp2+1);
				else printf("\n %s(.<%s<=%s) ", i ? " or " : " ", 
				name, tmp2+1);
			}
			if (l==1) fprintf(sas, "\n %s(''<upcase(%s)<=:upcase('%s')) ", i ? " or " : " ", 
				name2, tmp2+1);
			else if (l==2) fprintf(sas, "\n %s(.<%s<=input('%s', mmddyy12.)) ", i ? " or " : " ", 
				name2, tmp2+1);
			else fprintf(sas, "\n %s(.<%s<=%s) ", i ? " or " : " ", 
				name2, tmp2+1);
		}
		else if ((tmp2=strchr(str, '<'))) {
			tmp2[0]=0;
			if (j && out) {
				if (l) printf("\n %s(''<%s<'%s') ", i ? " or " : " ", 
				name, tmp2+1);
				else printf("\n %s(.<%s<%s) ", i ? " or " : " ", 
				name, tmp2+1);
			}
			if (l==1) fprintf(sas, "\n %s(''<upcase(%s)<upcase('%s')) ", i ? " or " : " ", 
				name2, tmp2+1);
			else if (l==2) fprintf(sas, "\n %s(.<%s<input('%s', mmddyy12.)) ", i ? " or " : " ", 
				name2, tmp2+1);
			else fprintf(sas, "\n %s(.<%s<%s) ", i ? " or " : " ", 
				name2, tmp2+1);
		}
		else if ((tmp2=strstr(str, ">="))) {
			tmp2[0]=0;
			if (j && out) {
				if (l) printf("\n %s(%s>=:'%s') ", i ? " or " : " ", 
				name, tmp2+1);
				else printf("\n %s(%s>=%s) ", i ? " or " : " ", 
				name, tmp2+1);
			}
			if (l==1) fprintf(sas, "\n %s(upcase(%s)>=:upcase('%s')) ", i ? " or " : " ", 
				name2, tmp2+1);
			else if (l==2) fprintf(sas, "\n %s(%s>=input('%s', mmddyy12.)) ", i ? " or " : " ", 
				name2, tmp2+1);
			else fprintf(sas, "\n %s(%s>=%s) ", i ? " or " : " ", 
				name2, tmp2+1);
		}
		else if ((tmp2=strchr(str, '>'))) {
			tmp2[0]=0;
			if (j && out) {
				if (l) printf("\n %s(%s>'%s') ", i ? " or " : " ", 
				name, tmp2+1);
				else printf("\n %s(%s>%s) ", i ? " or " : " ", 
				name, tmp2+1);
			}
			if (l==1) fprintf(sas, "\n %s(upcase(%s)>upcase('%s')) ", i ? " or " : " ", 
				name2, tmp2+1);
			else if (l==2) fprintf(sas, "\n %s(%s>input('%s', mmddyy12.)) ", i ? " or " : " ", 
				name2, tmp2+1);
			else fprintf(sas, "\n %s(%s>%s) ", i ? " or " : " ", 
				name2, tmp2+1);
		}
		else {
			tmp2=de_space(str);
			if (j && out) {
				if (l) printf("\n %s(%s=:'%s') ", i ? " or " : " ", 
				name, tmp2);
				else printf("\n %s(%s=%s) ", i ? " or " : " ", 
				name, tmp2);
			}
			if (l==1) fprintf(sas, "\n %s(upcase(%s)=:upcase('%s')) ", i ? " or " : " ", 
				name2, tmp2);
			else if (l==2) fprintf(sas, "\n %s(%s=input('%s', mmddyy12.)) ", i ? " or " : " ", 
				name2, tmp2);
			else fprintf(sas, "\n %s(%s=%s) ", i ? " or " : " ", 
				name2, tmp2);
		}
	}
   }
}

void sas_type5(VARI ** v_ptr, FILE * sas, int c, int out) {
	NAME ** n_ptr;
	VARI * new_ptr[2];
	int i, j, k, type2, flag=0;
	char buf[BUFFER_N];

	if (!(new_ptr[0]=(VARI *) malloc(sizeof(VARI)))) 
		hbase_error(3, "sas_type5-1");
	new_ptr[0]->label=NULL;
	new_ptr[1]=NULL;
	
	for (i=0; i<c; i++) {
		if ((n_ptr=find_name_group(v_ptr[i]->name_ptr->name_html,1,&j))) {
			for (k=0; k<j; k++) {
				type2=atoi(n_ptr[k]->type2);
				if (type2!=0 && type2!=1) continue;
				strcpy(buf, v_ptr[i]->value);
				new_ptr[0]->name_ptr=n_ptr[k];
				new_ptr[0]->value=buf;
	if (form>0 && form!=3 && form!=4 && form!=6 && form!=8
		&& form!=21 && form!=22 && form!=23 && form!=30) {
		printf("\n %s  ", flag ? "<LI>or" : "<LI>");
	}
	fprintf(sas, "\n %s  ", flag ? "or" : "");
				switch(type2) {
				case 0: sas_type1(new_ptr, sas, 1, form);
				break;
				case 1: sas_type2(new_ptr, sas, 1, form);
				break;
				}
				flag=1;
			}
		}
	}
	free(new_ptr[0]);
}

void sas_type1(VARI ** v_ptr, FILE * sas, int c, int out) {
	char * tmp;
	int i, j=0;

	if (!strcmp(v_ptr[0]->name_ptr->type1, "char")) j=1;
	tmp=v_ptr[0]->name_ptr->prompt;
	if (j) {
		for (i=0; i<c; i++) {
			if (form>0 && form!=3 && form!=4 && form!=6 && form!=8
				&& form!=21 && form!=22 && form!=23 && form!=30) {
					printf("\n %s(%s = '%s') ", i ? " or " : " ", tmp, 
						v_ptr[i]->label ? v_ptr[i]->label : v_ptr[i]->value);
				}
			fprintf(sas, "\n %s(%s = '%s') ", i ? " or " : " ", 
				v_ptr[i]->name_ptr->name_sas, v_ptr[i]->value);
		}
	}
	else {
		for (i=0; i<c; i++) {
			if (form>0 && form!=3 && form!=4 && form!=6 && form!=8
				&& form!=21 && form!=22 && form!=23 && form!=30) {
					printf("\n %s(%s = %s) ", i ? " or " : " ", tmp, 
						v_ptr[i]->label ? v_ptr[i]->label : v_ptr[i]->value);
				}
			fprintf(sas, "\n %s(%s = %s) ", i ? " or " : " ", 
				v_ptr[i]->name_ptr->name_sas, v_ptr[i]->value);
		}
	}
}

void sas_cross(char * cross1, char * cross2) {
	char * tmp1, *tmp2;
	NAME * n_ptr;

	if (tmp1=find_path("cross1")) {
		if (!(n_ptr=find_name(tmp1, 1))) cross1[0]=0;
		else {
			strcpy(cross1, n_ptr->name_html);
		}
	}
	if (tmp2=find_path("cross2")) {
		if (!strcmp(tmp2, "none")) cross2[0]=0;
		else {
			if (!(n_ptr=find_name(tmp2, 1))) cross2[0]=0;
			else {
				strcpy(cross2, n_ptr->name_html);
			}
		}
	}
}

NAME * get_crossVar_f(char * cross) {
	VARI ** v_ptr;
	int c;
	NAME * n_ptr;
	char buf[BUFFER_N], *tmp;

	v_ptr=find_vari(cross, 1, 8, &c);
	if (!v_ptr || c<=0) {
	  v_ptr=find_vari(cross, 1, 10, &c);
	  if (!v_ptr || c<=0) return NULL;
	  n_ptr=find_name(v_ptr[0]->value, 1);
	  if (!n_ptr) hbase_error(59, v_ptr[0]->value);
	  c=atoi(n_ptr->type2);
  	  if (c==0) return n_ptr;
	  else return NULL;
	}

	if (numberValue(v_ptr[0]->value)) {
	  strcpy(buf, cross);
	  tmp=strstr(buf, "_f");
	  if (tmp) {
  	    tmp[0]=0;
	    strcat(buf, v_ptr[0]->value);
	  }
	  else strcpy(buf, cross);

	  n_ptr=find_name(buf, 1);
	}
	else n_ptr=find_name(v_ptr[0]->value, 1);

	c=atoi(n_ptr->type2);
	if (c==0) return n_ptr;
	else return NULL;
}

void sas_find_cross(char * cross1, char * cross2, char * p1, char * p2) {
	char * tmp1, *tmp2;
	NAME * n_ptr, * n_ptr2;
	int type;

	if (tmp1=find_path("cross1")) {
		if (!(n_ptr=find_name(tmp1, 1))) { cross1[0]=0; p1[0]=0; }
		else {
			type=atoi(n_ptr->type2);
			if (type==8 || type==10) {
				n_ptr2=get_crossVar_f(tmp1);
				if (n_ptr2) n_ptr=n_ptr2;
			}
			strcpy(cross1, n_ptr->name_sas);

			if (n_ptr->name_pop) 
				strcpy(p1, n_ptr->name_pop);
			else p1[0]=0;

		}
	}
	if (tmp2=find_path("cross2")) {
		if (!strcmp(tmp2, "none")) { cross2[0]=0; p2[0]=0; }
		else {
			if (!(n_ptr=find_name(tmp2, 1))) { cross2[0]=0; p2[0]=0; }
			else {
				type=atoi(n_ptr->type2);
				if (type==8 || type==10) {
					n_ptr2=get_crossVar_f(tmp2);
					if (n_ptr2) n_ptr=n_ptr2;
				}
				strcpy(cross2, n_ptr->name_sas);

				if (n_ptr->name_pop) 
					strcpy(p2, n_ptr->name_pop);
				else p2[0]=0;

			}
		}
	}
}

void sas_find_cross2(char * cross1, char * cross2, char * p1, char * p2) {
	char * tmp1, *tmp2;
	NAME * n_ptr, * n_ptr2;
	int type;

	if (tmp1=find_path("cross1")) {
		if (!(n_ptr=find_name(tmp1, 1))) { cross1[0]=0; p1[0]=0; }
		else {
			type=atoi(n_ptr->type2);
			if (type==8 || type==10) {
				n_ptr2=get_crossVar_f(tmp1);
				if (n_ptr2) n_ptr=n_ptr2;
			}
			strcpy(cross1, n_ptr->name_sas);


			if (n_ptr->name_pop) 
				strcpy(p1, n_ptr->name_pop);
			else p1[0]=0;

		}
	}
	if (tmp2=find_path("cross2")) {
		if (!strcmp(tmp2, "none")) { cross2[0]=0; p2[0]=0; }
		else {
			if (!(n_ptr=find_name(tmp2, 1))) { cross2[0]=0; p2[0]=0; }
			else {
				type=atoi(n_ptr->type2);
				if (type==8 || type==10) {
					n_ptr2=get_crossVar_f(tmp2);
					if (n_ptr2) n_ptr=n_ptr2;
				}
				strcpy(cross2, n_ptr->name_sas);

				if (n_ptr->name_pop) 
					strcpy(p2, n_ptr->name_pop);
				else p2[0]=0;

			}
		}
	}
}

void sas_stdpop(FILE * sas) {
	char *tmp;
	int c;
	VARI ** v_ptr=NULL;
	
	fprintf(sas, "\n\n/* Following codes from sas_stdpop() */");
	if (!(tmp=find_path("sasstdpop"))) hbase_error(49, "sasstdpop");
	if (form!=21 && form!=22  && form!=23 && form!=30 && !(v_ptr=find_vari("stdpop", 1, 7, &c))) hbase_warning(7);

	fprintf(sas, "\n data stdpop;");
	fprintf(sas, "\n\t set pop.%s;", tmp);
	if (v_ptr) fprintf(sas, "\n if (%s=%s);", v_ptr[0]->name_ptr->name_sas, v_ptr[0]->value);
	else {
		tmp=find_stdpop(0);
		fprintf(sas, "\n if (stdyr=%s);", tmp);
	}
	fprintf(sas, "\n run;");
	fprintf(sas, "\n proc sort data=stdpop;");
	fprintf(sas, "\n by agepop;");
	fprintf(sas, "\n run;");
}

void sas_lbl_out(FILE * sas, char * dy, char *dl, 
	char ** dx, char * lbl_name, int length, char * snum, char *spop) {
	char * tmp, buf[BUFFER_N], buf2[BUFFER_N], * name;
	char c1[BUFFER_N], c2[BUFFER_N], p1[BUFFER_N], p2[BUFFER_N];
	char * tmp2, *tmp3, *tmp4, * cross1, * cross2, * type1, * type2;
	int flag=0, i, j, k;
	FILE * format;
    	NAME *  n_ptr;

        fprintf(sas, "\n\n/* Following codes from sas_lbl_out() */");
/*
	sas_find_cross(c1, c2, p1, p2);
	if (c1[0]) cross1=c1;
	else cross1=NULL;
	if (c2[0]) cross2=c2;
	else cross2=NULL;
*/
        if (cross1=find_path("cross1")) {
                if (!(n_ptr=find_name(cross1, 1))) cross1=NULL;
                else {
                        cross1=n_ptr->name_sas;
                        type1=n_ptr->type1;
                }
        }

        if (cross2=find_path("cross2")) {
                if (!strcmp(cross2, "none")) cross2=NULL;
                else {
                        if (!(n_ptr=find_name(cross2, 1))) {
			sas_out_3(sas, dx, lbl_name, length, snum, spop);
							return;
						}
                        else {
				name=n_ptr->name_html;
                                cross2=n_ptr->name_sas;
                                type2=n_ptr->type1;
                        }
                }
        }

	if (!cross1 || !cross2) {
		sas_out(sas, dy, dl, 0);
		return;
	}

	tmp2=get_sasname(buf);
	sprintf(buf2, "%s%s.lbl", tmp2, name);
	if ((format=fopen(buf2, "r"))) flag=1;

	if (!flag) {
		sprintf(buf2, "%s.lbl", name);
		if (!(format=file_open(buf2, 0))) return;
	}

	if (!(tmp4=find_path("small_num"))) {tmp="."; j=0;}
	else j=1;
	if (!(tmp3=find_path("small_pop"))) {tmp3="."; k=0;}
	else k=1;

	fprintf(sas, "\n %%macro lbl_out(i);");
    	fprintf(sas, "\n data _null_;");
	tmp=strstr(cross2, "_f");
	if (!strcmp(type2, "char") && !tmp) {
        fprintf(sas, "\n set tmp (where=(%s=\"&i\"));", cross2);
        fprintf(sas, "\n file \"%s%%str(&i).dat\" lrecl=80;", tmp2);
	}
	else {
        fprintf(sas, "\n set tmp (where=(%s=&i));", cross2);
        fprintf(sas, "\n file \"%s%%quote(&i).dat\" lrecl=80;", tmp2);
	}
	for (i=0; i<length; i++) {
	    if (strcmp(type1, "num"))
           	fprintf(sas, "\n put @1 %s $10. ", cross1);
            else fprintf(sas, "\n put @1 %s 10. ", cross1);
            fprintf(sas, " @16 '%d' @ ;", i+1);

	    if (j && snum && k && spop) {
		if (!strstr(dx[i], spop)) {
		    fprintf(sas, "\n if (%s < %s or %s < %s) then put @31 'X';", snum, tmp4, spop, tmp3);
		    fprintf(sas, "\n else put @31 %s ;", dx[i]);
		}
		else fprintf(sas, "\n put @31 %s ;", dx[i]);

	    }
	    else if (j && snum) {
		if (!strstr(dx[i], spop)) {
		    fprintf(sas, "\n if (%s < %s) then put @31 'X';", snum, tmp4);
		    fprintf(sas, "\n else put @31 %s ;", dx[i]);
		}
		else fprintf(sas, "\n put @31 %s ;", dx[i]);
	    }
	    else if (k && spop) {
		if (!strstr(dx[i], spop)) {
		    fprintf(sas, "\n if (%s < %s) then put @31 'X';", spop, tmp3);
		    fprintf(sas, "\n else put @31 %s ;", dx[i]);
		}
		else fprintf(sas, "\n put @31 %s ;", dx[i]);
	    }
	    else fprintf(sas, "\n put @31 %s;", dx[i]);
	}
    	fprintf(sas, "\n run;");
	fprintf(sas, "\n %%mend;");

	while (!feof(format)) {
		if (!(tmp=fgets(buf, BUFFER_N, format))) break;
		if (!(tmp2=strchr(tmp, '~'))) 
			if (!(tmp2=strchr(tmp, ' ' ))) continue;
		tmp2[0]=0;
		if (tmp[0]=='.' || tmp[0]=='~' || tmp[0]==' ') {
			sas_out(sas, dy, dl, 0);
			//continue;
		}
		fprintf(sas, "\n %%lbl_out(%s);", tmp);
	}
	fclose(format);
	_cross_3=malloc(strlen(lbl_name)+1);
	strcpy(_cross_3, lbl_name);
	return;
}

void sas_lbl_out3(FILE * sas, char * dy, char *dl, 
	char ** dx, char * lbl_name, int length, char * snum, char *spop) {
	char * tmp, buf[BUFFER_N], buf2[BUFFER_N], * name;
	char c1[BUFFER_N], c2[BUFFER_N], p1[BUFFER_N], p2[BUFFER_N];
	char * tmp2, *tmp3, *tmp4, * cross1, * cross2, * type1, * type2;
	int flag=0, i, j, k;
	FILE * format;
    	NAME *  n_ptr, *n_ptr2;

        fprintf(sas, "\n\n/* Following codes from sas_lbl_out3() */");

/*
	sas_find_cross(c1, c2, p1, p2);
	if (c1[0]) cross1=c1;
	else cross1=NULL;
	if (c2[0]) cross2=c2;
	else cross2=NULL;
*/
        if (cross1=find_path("cross1")) {
                if (!(n_ptr=find_name(cross1, 1))) cross1=NULL;
                else {
			i=atoi(n_ptr->type2);
			if (i==8) {
				n_ptr2=get_crossVar_f(cross1);
				if (n_ptr2) n_ptr=n_ptr2;
			}
			name=n_ptr->name_html;
                        cross1=n_ptr->name_sas;
                        type1=n_ptr->type1;
                }
        }

        if (cross2=find_path("cross2")) {
                if (!strcmp(cross2, "none")) cross2=NULL;
                else {
                        if (!(n_ptr=find_name(cross2, 1))) {
			sas_out_3(sas, dx, lbl_name, length, snum, spop);
							return;
						}
                        else {
				i=atoi(n_ptr->type2);
				if (i==8) {
					n_ptr2=get_crossVar_f(cross2);
					if (n_ptr2) n_ptr=n_ptr2;
				}
				name=n_ptr->name_html;
                                cross2=n_ptr->name_sas;
                                type2=n_ptr->type1;
                        }
                }
        }
	fprintf(sas, "\n /* cross1--*%s cross2--*%s  */", cross1, cross2);

	if (!cross1 || !cross2) {
		sas_out(sas, dy, dl, 0);
		return;
	}

	tmp2=get_sasname(buf);
	sprintf(buf2, "%s%s.lbl", tmp2, name);
	if ((format=fopen(buf2, "r"))) flag=1;

fprintf(sas, "\n /* tmp2--*%s name--*%s */", tmp2, name);
fprintf(sas, "\n /* type1--*%s type2--*%s */", type1, type2);
	if (!flag) {
		sprintf(buf2, "%s.lbl", name);
		if (!(format=file_open(buf2, 0))) return;
	}

	if (!(tmp4=find_path("small_num"))) {tmp="."; j=0;}
	else j=1;
	if (!(tmp3=find_path("small_pop"))) {tmp3="."; k=0;}
	else k=1;

	fprintf(sas, "\n %%macro lbl_out(i);");
    	fprintf(sas, "\n data _null_;");
	tmp=strstr(cross2, "_f");
	if (!strcmp(type2, "char") && !tmp) {
        fprintf(sas, "\n set tmp (where=(%s=\"&i\"));", cross2);
        fprintf(sas, "\n file \"%s%%str(&i).dat\" lrecl=80;", tmp2);
	}
	else {
        fprintf(sas, "\n set tmp (where=(%s=&i));", cross2);
        fprintf(sas, "\n file \"%s%%quote(&i).dat\" lrecl=80;", tmp2);
	}
	for (i=0; i<length; i++) {
	    if (strcmp(type1, "num"))
           	fprintf(sas, "\n put @1 %s $10. ", cross1);
            else fprintf(sas, "\n put @1 %s 10. ", cross1);
            fprintf(sas, " @16 '%d' @ ;", i+1);

	    if (j && snum && k && spop) {
		if (!strstr(dx[i], spop)) {
		    fprintf(sas, "\n if (%s < %s or %s < %s) then put @31 'X';", snum, tmp4, spop, tmp3);
		    fprintf(sas, "\n else put @31 %s ;", dx[i]);
		}
		else fprintf(sas, "\n put @31 %s ;", dx[i]);

	    }
	    else if (j && snum) {
		if (!strstr(dx[i], spop)) {
		    fprintf(sas, "\n if (%s < %s) then put @31 'X';", snum, tmp4);
		    fprintf(sas, "\n else put @31 %s ;", dx[i]);
		}
		else fprintf(sas, "\n put @31 %s ;", dx[i]);
	    }
	    else if (k && spop) {
		if (!strstr(dx[i], spop)) {
		    fprintf(sas, "\n if (%s < %s) then put @31 'X';", spop, tmp3);
		    fprintf(sas, "\n else put @31 %s ;", dx[i]);
		}
		else fprintf(sas, "\n put @31 %s ;", dx[i]);
	    }
	    else fprintf(sas, "\n put @31 %s;", dx[i]);
	}
    	fprintf(sas, "\n run;");
	fprintf(sas, "\n %%mend;");

	while (!feof(format)) {
		if (!(tmp=fgets(buf, BUFFER_N, format))) break;
		if (!(tmp2=strchr(tmp, '~'))) 
			if (!(tmp2=strchr(tmp, ' ' ))) continue;
		tmp2[0]=0;
		if (tmp[0]=='.' || tmp[0]=='~' || tmp[0]==' ') {
			sas_out(sas, dy, dl, 0);
			//continue;
		}
		fprintf(sas, "\n %%lbl_out(%s);", tmp);
	}
	fclose(format);
	_cross_3=malloc(strlen(lbl_name)+1);
	strcpy(_cross_3, lbl_name);
	return;
}

CROSS ** find_crosses(int * cnt) {
	CROSS ** crosses_ptr=NULL;
	char *tmp, buf[BUFFER_N];
	int i, j, crosses_cnt, vari_cnt;
	NAME * name_p;
	VARI ** vari_p;

	for (i=0, crosses_cnt=0; i<h_path_i; i++) {
	  if (!strncmp("cross", h_path[i]->name, 5)) {
	    if (!find_name(h_path[i]->path, 1)) continue;
	    crosses_cnt++;
	  }
	}
	crosses_ptr=(CROSS **) malloc(sizeof(CROSS *)*(crosses_cnt+1));
	if (!crosses_ptr) hbase_error(3, "find_crosses-1");
	for (i=0, j=0; i<h_path_i; i++) {
	  if (!strncmp("cross", h_path[i]->name, 5)) {
	    if (!(name_p=find_name(h_path[i]->path, 1))) continue;
	    crosses_ptr[j]=(CROSS *) malloc(sizeof(CROSS));
	    if (!crosses_ptr[j]) hbase_error(3, "find_crosses-2");
	    crosses_ptr[j]->id=j+1;
	    crosses_ptr[j]->name=h_path[i]->name;
	    crosses_ptr[j]->value=h_path[i]->path;
	    crosses_ptr[j]->name_ptr=find_name(crosses_ptr[j]->value, 1);

	    if (atoi(name_p->type2)!=0) {
		vari_p=find_vari(h_path[i]->path, 1, 8, &vari_cnt);
	        if (vari_p!=NULL) {
	    	    if (name_p=find_name(vari_p[0]->value, 1)) {
		      if (atoi(name_p->type2)==0) {
	    		crosses_ptr[j]->value=vari_p[0]->value;
	    		crosses_ptr[j]->name_ptr=name_p;
		      }
		    }
		}
		else {
		vari_p=find_vari(h_path[i]->path, 1, 10, &vari_cnt);
	        if (vari_p!=NULL) {
	    	    if (name_p=find_name(vari_p[0]->value, 1)) {
		      if (atoi(name_p->type2)==0) {
	    		crosses_ptr[j]->value=vari_p[0]->value;
	    		crosses_ptr[j]->name_ptr=name_p;
		      }
		    }
		}

//printf("j--*%d corss-sas_name--*%s sas_pop--*%s type2--*%s", j, crosses_ptr[j]->name_ptr->name_sas, crosses_ptr[j]->name_ptr->name_pop, crosses_ptr[j]->name_ptr->type2);
		}
	    }
	    j++;
	  }
	}
	crosses_ptr[crosses_cnt]=NULL;
	*cnt=crosses_cnt;
	return crosses_ptr;
}

CROSS ** find_crosses_xml(int * cnt) {
	CROSS ** crosses_ptr=NULL;
	char *tmp, buf[BUFFER_N];
	int i, j, crosses_cnt, vari_cnt;
	NAME * name_p;
	VARI ** vari_p;

	for (i=0, crosses_cnt=0; i<h_path_i; i++) {
	  if (!strncmp("cross", h_path[i]->name, 5)) {
	    if (!find_name(h_path[i]->path, 1)) continue;
	    crosses_cnt++;
	  }
	}
	crosses_ptr=(CROSS **) malloc(sizeof(CROSS *)*(crosses_cnt+1));
	if (!crosses_ptr) hbase_error(3, "find_crosses-1");
	for (i=0, j=0; i<h_path_i; i++) {
	  if (!strncmp("cross", h_path[i]->name, 5)) {
	    if (!(name_p=find_name(h_path[i]->path, 1))) continue;
	    crosses_ptr[j]=(CROSS *) malloc(sizeof(CROSS));
	    if (!crosses_ptr[j]) hbase_error(3, "find_crosses-2");
	    crosses_ptr[j]->id=j+1;
	    crosses_ptr[j]->name=h_path[i]->name;
	    crosses_ptr[j]->value=h_path[i]->path;
	    crosses_ptr[j]->name_ptr=find_name(crosses_ptr[j]->value, 1);

	    if (atoi(name_p->type2)!=0) {
		vari_p=find_vari(h_path[i]->path, 1, 8, &vari_cnt);
	        if (vari_p!=NULL) {
	    	    if (name_p=find_name(vari_p[0]->value, 1)) {
		      if (atoi(name_p->type2)==0) {
	    		crosses_ptr[j]->value=vari_p[0]->value;
	    		crosses_ptr[j]->name_ptr=name_p;
		      }
		    }
		}
		else {
		vari_p=find_vari(h_path[i]->path, 1, 10, &vari_cnt);
	        if (vari_p!=NULL) {
	    	    if (name_p=find_name(vari_p[0]->value, 1)) {
	    		crosses_ptr[j]->value=vari_p[0]->value;
	    		crosses_ptr[j]->name_ptr=name_p;
		    }
		}

		}
	    }
	    j++;
	  }
	}
	crosses_ptr[crosses_cnt]=NULL;
	*cnt=crosses_cnt;
	return crosses_ptr;
}

char * get_cross_name(CROSS * cross) {
	int j=0;
	NAME *n_ptr;

	if (cross->name_ptr) {
	    j=atoi(cross->name_ptr->type2);
	}
	if (j==8 || j==10) {
	    n_ptr=get_crossVar_f(cross->value);
	    if (!n_ptr) n_ptr=cross->name_ptr;
	}
	else n_ptr=cross->name_ptr;

	return(n_ptr->name_sas);
}

void sas_suppress_normal(FILE * sas, 
	char ** dx, char * snum, char *spop) {
	char *tmp, buf[BUFFER_N];
	int i, j, crosses_cnt;
	CROSS ** crosses;
	FUNC * func_p;

	char *small_num, *small_pop;

	if (!(small_num=find_path("small_num"))) {small_num=".";}
	if (!(small_pop=find_path("small_pop"))) {small_pop=".";}
	if (small_num[0]=='.' && small_pop[0]=='.') return;
	crosses=find_crosses(&crosses_cnt);
        if (crosses_cnt==0) hbase_error(58, "");
	func_p=find_func(h_func, "suppressed_variables");

	if (snum==NULL) snum="n";
        fprintf(sas, "\n\n/* Following codes from sas_suppress_normal() */"); fflush(sas);
	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n set tmp;");
	fprintf(sas, "\n /* snum--*%s small_num--*%s spop--*%s small_pop--*%s */", snum, small_num, spop, small_pop);
	if (snum && small_num[0]!='.' && spop && small_pop[0]!='.') {
	  fprintf(sas, "\n if (%s < %s or %s < %s) then do; ", snum, small_num, spop, small_pop);
	}
	else if (snum && small_num[0]!='.') {
	  fprintf(sas, "\n if (%s < %s) then do; ", snum, small_num);
	}
	else if (spop && small_pop[0]!='.') {
	  fprintf(sas, "\n if (%s < %s) then do; ", spop, small_pop);
	}
	else {
	  fprintf(sas, "\n if (1=2) then do;");
	}

	  fprintf(sas, "\n /* func_p -- *%d */", func_p);
	if (func_p!=NULL && func_p->script) {
	  for (i=0; func_p->script[i]; i++) {
	    fprintf(sas, "\n %s = .A;", func_p->script[i]);
fprintf(sas, "\n /* i  -- *%d */", i);
	  }
	}
	else {
	  strcpy(buf, dx[0]);
	  if ((tmp=strchr(de_space(buf), ' '))) tmp[0]=0;
	  fprintf(sas, "\n   %s = .A;", buf);
	}
	//fprintf(sas, "\n   %s = .A;", snum);
	fprintf(sas, "\n end;");
	fprintf(sas, "\n run;");
}

void sas_suppress_cv(FILE * sas, 
	char ** dx, char * snum, char *spop) {
	char *tmp, buf[BUFFER_N];
	int i, j, crosses_cnt;
	CROSS ** crosses;
	FUNC * func_p;

/*
	char *small_num, *small_pop;

	if (!(small_num=find_path("small_num"))) {small_num=".";}
	if (!(small_pop=find_path("small_pop"))) {small_pop=".";}
	if (small_num[0]=='.' && small_pop[0]=='.') return;
*/
	crosses=find_crosses(&crosses_cnt);
        if (crosses_cnt==0) hbase_error(58, "");
	func_p=find_func(h_func, "suppressed_variables");

	if (snum==NULL) snum="cv";
        fprintf(sas, "\n\n/* Following codes from sas_suppress_cv() */"); fflush(sas);
	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n set tmp;");
	fprintf(sas, "\n if (cv>50) then do; ");

	  fprintf(sas, "\n /* func_p -- *%d */", func_p);
	if (func_p!=NULL && func_p->script) {
	  for (i=0; func_p->script[i]; i++) {
	    fprintf(sas, "\n %s = .A;", func_p->script[i]);
fprintf(sas, "\n /* i  -- *%d */", i);
	  }
	}
	else {
	  strcpy(buf, dx[0]);
	  if ((tmp=strchr(de_space(buf), ' '))) tmp[0]=0;
	  fprintf(sas, "\n   %s = .A;", buf);
	}
	//fprintf(sas, "\n   %s = .A;", snum);
	fprintf(sas, "\n end;");
	fprintf(sas, "\n run;");
}


void sas_suppress_cell(FILE * sas, 
	char ** dx, char * snum, char *spop) {
	char *tmp, buf[BUFFER_N];
	int i, j, crosses_cnt;
	CROSS ** crosses;
	FUNC * func_p;
	char *small_num, *small_pop;

	fprintf(sas, "\n /* following codes are from sas_suppress_cell.;  */");
/*
	if (!(small_num=find_path("small_num"))) {small_num=".";}
	if (!(small_pop=find_path("small_pop"))) {small_pop=".";}
	if (small_num[0]=='.' && small_pop[0]=='.') return;
*/
	crosses=find_crosses(&crosses_cnt);
        if (crosses_cnt==0) hbase_error(58, "");

	tmp=find_path("suppress_rule");
	if (tmp && !(strcmp(tmp, "cv"))) {
	  sas_suppress_cv(sas, dx, snum, spop);
	}
	else {
	  func_p=find_func(h_func, "suppress_rule");

	  if (func_p && !(strcmp(func_p->value, "cv"))) {
	    sas_suppress_cv(sas, dx, snum, spop);
	  }
	  else {
	    sas_suppress_normal(sas, dx, snum, spop);
	  }
	}
	func_p=find_func(h_func, "suppressed_variables");

	if (snum==NULL) snum="n";
/*
	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n set tmp;");
	if (snum && small_num[0]!='.' && spop && small_pop[0]!='.') {
	  fprintf(sas, "\n if (%s < %s or %s < %s) then do; ", snum, small_num, spop, small_pop);
	}
	else if (snum && small_num[0]!='.') {
	  fprintf(sas, "\n if (%s < %s) then do; ", snum, small_num);
	}
	else if (spop && small_pop[0]!='.') {
	  fprintf(sas, "\n if (%s < %s) then do; ", spop, small_pop);
	}
	else {
	  fprintf(sas, "\n if (1=2) then do;");
	}

	if (func_p!=NULL && func_p->script) {
	  for (i=0; func_p->script[i]; i++) {
	    if (func_p->script[i]) {
	      fprintf(sas, "\n %s = .A;", func_p->script[i]);
	    }
	  }
	}
	else {
	  strcpy(buf, dx[0]);
	  if ((tmp=strchr(de_space(buf), ' '))) tmp[0]=0;
	  fprintf(sas, "\n   %s = .A;", buf);
	}
	//fprintf(sas, "\n   %s = .A;", snum);
	fprintf(sas, "\n end;");
	fprintf(sas, "\n run;");
*/

        fprintf(sas, "\n\n/* Following codes from sas_suppress_cell() */"); fflush(sas);
	//fprintf(sas, "\n /* snum--*%s small_num--*%s spop--*%s small_pop--*%s */", snum, small_num, spop, small_pop);
	fprintf(sas, "\n %%macro small_cross1(cross1);");
	fprintf(sas, "\n proc sort data=tmp;");
	fprintf(sas, "\n by descending &cross1.;");
	fprintf(sas, "\n run;");
	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n set tmp end=eof;");
	fprintf(sas, "\n retain _si1 0;");
	fprintf(sas, "\n if (eof and _si1=1) then do;");
	if (func_p!=NULL && func_p->script) {
	  for (i=0; func_p->script[i]; i++) {
	    if (func_p->script[i]) {
	      fprintf(sas, "\n %s = .A;", func_p->script[i]);
	    }
	  }
	}
	else {
	  strcpy(buf, dx[0]);
	  if ((tmp=strchr(de_space(buf), ' '))) tmp[0]=0;
	  if (buf) {
	    fprintf(sas, "\n   %s = .A;", buf);
	  }
	}
	fprintf(sas, "\n   %s = .A;", snum);
	fprintf(sas, "\n end;");
	fprintf(sas, "\n else if (%s=.A) then _si1=_si1+1;", snum);
	fprintf(sas, "\n drop _si1;");
	fprintf(sas, "\n run;");
	fprintf(sas, "\n %%mend;");

	fprintf(sas, "\n %%macro small_cross1_2(cross1, cross2);");
	fprintf(sas, "\n proc sort data=tmp;");
	fprintf(sas, "\n by descending &cross1. descending &cross2.;");
	fprintf(sas, "\n run;");
	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n set tmp;");
	fprintf(sas, "\n by descending &cross1. descending &cross2.;");
	fprintf(sas, "\n retain _si1 0;");
	fprintf(sas, "\n if (first.&cross1.) then _si1=0;");
	fprintf(sas, "\n if (last.&cross1. and _si1=1) then do;");
	if (func_p!=NULL && func_p->script) {
	  for (i=0; func_p->script[i]; i++) {
	    if (func_p->script[i]) {
	      fprintf(sas, "\n %s = .A;", func_p->script[i]);
	    }
	  }
	}
	else {
	  strcpy(buf, dx[0]);
	  if ((tmp=strchr(de_space(buf), ' '))) tmp[0]=0;
	  if (buf) {
	    fprintf(sas, "\n   %s = .A;", buf);
	  }
	}
	fprintf(sas, "\n   %s = .A;", snum);
	fprintf(sas, "\n end;");
	fprintf(sas, "\n else if (%s=.A) then _si1=_si1+1;", snum);
	fprintf(sas, "\n drop _si1;");
	fprintf(sas, "\n run;");
	fprintf(sas, "\n %%mend;");

	if (crosses_cnt==1) {
	  fprintf(sas, "\n %%small_cross1(%s);", get_cross_name(crosses[0]));
	}
	else {
	  fprintf(sas, "\n %%small_cross1_2(%s, %s);", get_cross_name(crosses[0]), get_cross_name(crosses[1]));
	  fprintf(sas, "\n %%small_cross1_2(%s, %s);", get_cross_name(crosses[1]), get_cross_name(crosses[0]));

	}
}
int check_map(char * var) {
	char * tmp, *tmp2;
	tmp2=de_space(var);
	tmp=find_path("check_map");
	if (!tmp || strcmp(tmp, tmp2)) return 0;
	else {
//	printf("\n return 1");
 		return 1;
	}
}

void sas_lbl_out2(FILE * sas, char * dy, char *dl, 
	char ** dx, char * lbl_name, int length, char * snum, char *spop) {

	CROSS ** crosses;
	char *tmp, buf[BUFFER_N];
	int i, j, k, crosses_cnt;
	NAME * n_ptr;
	FUNC * func_p;
	int cv=0, ucr=0, skip=0;
	
	tmp=find_path("suppress_rule");
	cv= (tmp && !strcmp(tmp, "cv"));
	ucr= (tmp && !strcmp(tmp, "ucr"));
	skip= (tmp && !strcmp(tmp, "skip"));
	func_p=(FUNC *) find_func(h_func, "suppress_rule");
	if (!cv) {
	  cv= (func_p && !strcmp(func_p->value, "cv"));
	}
	if (!ucr) {
	  ucr= (func_p && !strcmp(func_p->value, "ucr"));
	}
	if (!skip) {
	  skip= (func_p && !strcmp(func_p->value, "skip"));
	}

	if (!skip) sas_suppress_cell(sas, dx, snum, spop);

	crosses=find_crosses(&crosses_cnt);
	tmp=get_sasname(buf);
        fprintf(sas, "\n\n/* Following codes from sas_lbl_out2() */"); fflush(sas);
        fprintf(sas, "\n\n/* snum -- %s spop--%s cnt--*%d */", snum, spop, crosses_cnt);
	fprintf(sas, "\n\n proc sort data=tmp;");
	func_p=(FUNC *) find_func(h_func, "result_sort");
	if (func_p!=NULL && func_p->value != NULL) {
		fprintf(sas, "\n %s", func_p->value);
	}
	else {
		fprintf(sas, "\n   by ");
		for (i=0; i<crosses_cnt; i++) {
		  j=0;
		  if (crosses[i]->name_ptr && crosses[i]->name_ptr->note) {
		    if (!strcmp(crosses[i]->name_ptr->note, "98")) j=1;
		  }
		  if (!j) fprintf(sas, " %s ", get_cross_name(crosses[i]));
		}

		fprintf(sas, ";");
	}
	fprintf(sas, "\n   run;");

	fprintf(sas, "\n\n data _null_;");
	fprintf(sas, "\n set tmp;");
        fprintf(sas, "\n file \"%s.dat\" lrecl=1024;", tmp);
	for (i=0; i<crosses_cnt; i++) {
	  if (crosses[i]->name_ptr)
	    j=atoi(crosses[i]->name_ptr->type2);
	    if (j==8) {
		n_ptr=get_crossVar_f(crosses[i]->value);
		if (!n_ptr) n_ptr=crosses[i]->name_ptr;
	    }
	    else n_ptr=crosses[i]->name_ptr;
	    if  (!(strcmp(n_ptr->type1, "char"))) {
		fprintf(sas, "\n if (%s='') then put '\".\", ' @; ", n_ptr->name_sas); 
	    	fprintf(sas, "\n else put '\"' %s '\", ' @; ", n_ptr->name_sas);
	    }
	    else  {
	    	fprintf(sas, "\n put '\"' %s '\", ' @; ", n_ptr->name_sas);
	    }
	}

	for (i=0; i<length; i++) {
	    strcpy(buf, dx[i]);
	    if (strlen(de_space(buf))<1) continue;
	    if ((tmp=strchr(de_space(buf), ' '))) tmp[0]=0;
	    fprintf(sas, "\n if (%s = .A) then put '\"**\"'", buf);
	    if (i<length-1)  fprintf(sas, " ', ' @;");
	    else fprintf(sas, ";");
	    if (cv) {
		fprintf(sas, "\n else if (30<cv<=50) then do; ");
		if(check_map(buf)) fprintf(sas, "\n put '\"' %s '\"'", dx[i]);
		else fprintf(sas, "\n put '\"' %s '*\"'", dx[i]);
	    	if (i<length-1)  fprintf(sas, " ', ' @;");
	    	else fprintf(sas, ";");
		fprintf(sas, "\n end;");
		fprintf(sas, "\n else if (cv>50) then do; ");
		fprintf(sas, "\n put '\"'  '**\"'");
	    	if (i<length-1)  fprintf(sas, " ', ' @;");
	    	else fprintf(sas, ";");
		fprintf(sas, "\n end;");
            }
	    if (ucr) {
	  	func_p=(FUNC *) find_func(h_func, "ucr_variable");

		fprintf(sas, "\n else if (5<=n<=15) then do; ");
		if (func_p && strstr(dx[i], func_p->value)) {
		  if(check_map(dx[i])) fprintf(sas, "\n put '\"' %s '\"'", dx[i]);
		  else fprintf(sas, "\n put '\"' %s '*\"'", dx[i]);
		}
		else {
		  fprintf(sas, "\n put '\"' %s '\"'", dx[i]);
		}
	    	if (i<length-1)  fprintf(sas, " ', ' @;");
	    	else fprintf(sas, ";");
		fprintf(sas, "\n end;");

	    }
	    fprintf(sas, "\n else put '\"' %s '\"'", dx[i]);
	    if (i<length-1)  fprintf(sas, " ', ' @;");
	    else fprintf(sas, ";");
	}
	fprintf(sas, "\n run;");

}
