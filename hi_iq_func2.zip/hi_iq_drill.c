/* HI-IQ System, the High Information Internet Query System,
	Copyright 1995, 1996, 1997, 1998 Utah Office of Health Data Analysis.

	hi_iq_drill.c	11/11/98
	Support drill-down feature.

	We provide the interactive interface to make your data available
	to public through Internet.
*/

#include "hi_iq.h"
#include "hi_iq_var.h"

char * drill_vari(char *qt, char *key, char *buf) {
	char * tmp;
	int i, len;

	len=strlen(key);
	if (!(tmp=strstr(qt, key))) return NULL;
	for (i=0; tmp[i+len]!='&' && tmp[i+len]!='\0'; i++)
		buf[i]=tmp[i+len];
	if (i==0) return NULL;
	else buf[i]='\0';
	return buf;
}
	
char *cross_back_qt(char *qt, char *cross, char *buf) {
	char str[STRING_N], *tmp1, *tmp2;

	sprintf(buf, "%s=", cross);
	if (!(tmp1=(strstr(buf, "_f"))) 
	 || !(tmp2=drill_vari(qt, buf, str))) {
		strcpy(buf, cross);
	}
	else {
		tmp1[0]='\0';
		strcat(buf, str);
	}
	return buf;
}

void drill_cross(char *qt, char *key, char *cross, char *name, char *next) {
	char * tmp, buf[STRING_N], buf2[STRING_N];
	int i, len;

	len=strlen(key);
	if (tmp=strstr(qt, key)) {
		for (i=0; tmp[i+len]!='&' && tmp[i+len]!='\0'; i++)
			buf[i]=tmp[i+len];
		buf[i]='\0';
		if (!strcmp(cross_back_qt(qt, buf, buf2), name)) {
			sprintf(cross, "%s%s", key, next);
			for (i=1; tmp[i]!='&' && tmp[i]!='\0'; i++)
				tmp[i]='&';
		}
	}
}

char *query_drill(char *qt) {
	char next_seq[STRING_N], drill_name[STRING_N], drill_value[STRING_N];
	char *tmp, cross[STRING_N];
	int i;

	if (!drill_vari(qt, "&next_seq=", next_seq)) return NULL;
	if (!drill_vari(qt, "&drill_name=", drill_name)) return NULL;
	//if (!drill_vari(qt, "&drill_value=", drill_value)) return NULL;
	drill_vari(qt, "&drill_value=", drill_value);

	drill_cross(qt, "&cross1=", cross, drill_name, next_seq);
	drill_cross(qt, "&cross2=", cross, drill_name, next_seq);
		
	sprintf(next_seq, "&%s=", drill_name);
	while ((tmp=strstr(qt, next_seq))) {
		for (i=1; tmp[i]!='&' && tmp[i]!='\0'; i++)
			tmp[i]='&';
	}
	if (drill_value != NULL && strcmp(drill_value, ".") )
          strcat(next_seq, drill_value);

	if (!(tmp=malloc(strlen(qt)+strlen(cross)+strlen(next_seq)+1)))
		hbase_error(3, "drill-1");
	sprintf(tmp, "%s%s%s", qt, cross, next_seq);
	return tmp;
}


void pre_query() {
	bld_pre_query();
}

char * bld_pre_query() {
	char *tmp, buf[BUFFER_N], buf2[BUFFER_N];
	int i, l, preq;
	NAME *n_ptr;

	preq=-1;
	buf[0]='\0';
	for (i=0; i<h_path_i; i++) {
		if (!(strcmp(h_path[i]->name, "pre_query"))) preq=i;
		else if (!(strcmp(h_path[i]->name, "cross2"))) {
			n_ptr=find_name(h_path[i]->path, 1);
			if (!n_ptr || n_ptr->type2[0]=='6') {
				strcat(buf, "&");
				strcat(buf, h_path[i]->name);
				strcat(buf, "=");
				strcat(buf, _cross_2? _cross_2:"none");
				continue;
			}
		}
		if (h_path[i]->type[0]=='r') {
			strcat(buf, "&");
			strcat(buf, h_path[i]->name);
			strcat(buf, "=");
			strcat(buf, h_path[i]->path);
		}
	}
	if (preq==-1) return;

	buf2[0]='\0';
	for (i=0, l=0; i<h_vari_i; i++) {
		strcat(buf2, "&");
		strcat(buf2, h_vari[i]->name_ptr->name_html);
		strcat(buf2, "=");
		strcat(buf2, h_vari[i]->value);
	}

	if (!(tmp=malloc(strlen(buf)+strlen(buf2)+1)))
		hbase_error(3, "drill-2");
	sprintf(tmp, "%s%s", buf, buf2);

	h_path[preq]->path=tmp;
	return tmp;
}

void sequence_erase(char *key) {
	char *sequence, *tmp;
	int i;

	sequence = find_path("sequence");
	if (tmp=strstr(sequence, key)) {
		for (i=0; ; i++) {
			if (tmp[i]==' ' || tmp[i]=='\0' ) break;
			tmp[i]=' ';
		}
	}
}

void sequence_bld() {
	char *sequence, *cross;

	sequence = find_path("sequence");
	if (sequence==NULL) {
		sequence="none";
		return;
	}
	if (cross=find_path("cross1")) sequence_erase(cross);
	if (cross=find_path("cross2")) 
		if (strcmp(cross, "none")) sequence_erase(cross);
}

void sequence_compress() {
	char *sequence, buf[BUFFER_N];
	int i, j, len, flag;

	sequence = find_path("sequence");
	len=strlen(sequence);
	for (i=0, j=0, flag=0; i<len; i++) {
		if (sequence[i]!=' ') {
			buf[j]=sequence[i];
			j++;
			flag=1;
		}
		else {
			if (flag) {
				buf[j]=sequence[i];
				j++;
				flag=0;
			}
		}
	}
	buf[j]='\0';
	strcpy(sequence, buf);
}

void sequence_select() {
	char *tmp1, *tmp2;
	int i;
	NAME *n_ptr;

	sequence_bld();
	sequence_compress();
	tmp2=find_path("sequence");
	if (!tmp2 || tmp2[0]==' ' || tmp2[0]=='\0') return;
	if ((tmp1=find_path("drill_html")))
	printf("\nUse the <a href=\"%s\">drill-down</a> variable tool to amend the current query", tmp1);
	else
	printf("\nUse the drill-down variable tool to amend the current query");
	printf("\n<select name=next_seq>");
	for (i=0; ;i++) {
		if (!tmp2[0]) break;
		if (tmp1=strchr(tmp2, ' ')) tmp1[0]='\0';
		n_ptr=find_name(tmp2, 1);
		printf("\n<option value=\"%s\" %s> %s", tmp2, 
			i? "" : "selected", n_ptr? n_ptr->prompt:tmp2);
		if (!tmp1) break;
		tmp2=tmp1+1;
		tmp1[0]=' ';
	}
	printf("\n</select>"); fflush(stdout);
}

char * tail_cut(char *start, char *buf) {
	int i, j, f1, len;

	len=strlen(start);
	for (i=0, j=0, f1=0; i<len; i++) {
		switch(f1) {
		case 0:
			switch(start[i]) {
			case ' ':
			case '\n':
				break;
			case '\'':
				f1=2;
				j=0;
				break;
			case '\"':	
				f1=3;
				j=0;
				break;
			case '>':
			case '\0':
				buf[j]='\0';
				f1=9;
				break;
			default:
				f1=1;
				buf[0]=start[i];
				j=1;
				break;
			}
			break;
		case 1:
			switch(start[i]) {
			case ' ':
			case '\n':
			case '>':
			case '\0':
				buf[j]='\0';
				f1=9;
				break;
			default:
				buf[j]=start[i];
				j++;
				break;
			}
			break;
		case 2:
			switch(start[i]) {
			case '\'':
			case '>':
			case '\0':
				buf[j]='\0';
				f1=9;
				break;
			default:
				buf[j]=start[i];
				j++;
				break;
			}
			break;
		case 3:
			switch(start[i]) {
			case '\"':
			case '>':
			case '\0':
				buf[j]='\0';
				f1=9;
				break;
			default:
				buf[j]=start[i];
				j++;
				break;
			}
			break;
		default:
			break;
		}
	}
	return (f1==9? start+i-1 : NULL);
}

void tail_hidden(char *line) {
	char str[STRING_N], name[STRING_N], value[STRING_N];
	char *tmp, *tmp1, *tmp2;
	
	if (!strstr(line, "input") || !strstr(line, "hidden")) {
		puts(line);
	}
	else {
		if ( !(tmp1=strstr(line, "name")) 
		  || !(tmp2=strchr(tmp1, '=')) 
		  || !(tmp1=tail_cut(tmp2+1, name))) {
			puts(line);
			return;
		}

		if ( !(tmp1=strstr(line, "value")) 
		  || !(tmp2=strchr(tmp1, '='))
		  || !(tmp1=tail_cut(tmp2+1, value))) {
			puts(line);
			return;
		}

		sprintf(str, "%%%s%%", name);
		if (  (strcmp(str, value))
		  || !(tmp=find_path(name))) {
			puts(line);
			return;
		}

		tmp2[1]='\0';
		printf("%s\"%s\"%s", line, tmp, tmp1);	
	}
}

void std_htmltail(char *filename) {
	FILE * tail;
	char c ;
	char buf[BUFFER_N];
	int f1, i;

	pre_query();
	if (!(tail=file_open(filename, 0))) hbase_error(37, filename);
	f1=0;
	while (!feof(tail)) {
		c=fgetc(tail);
		if (f1==0) {
			if (c=='<') {
				f1=1; 
				buf[0]=c;
				i=1;
			}
			else if (!feof(tail)) putchar(c);
		}
		else {
			if (c=='<' || i==BUFFER_N-2) {
				buf[i]=c;
				i++;
				buf[i]='\0';
				puts(buf);
				f1=0;
			}
			else if (c=='>') {
				buf[i]=c;
				i++;
				buf[i]='\0';
				tail_hidden(buf);
				f1=0;
			}
			else if (feof(tail)) {
				buf[i]='\0';
				tail_hidden(buf);
			}
			else if (c) {
				buf[i]=c;
				i++;
			}
		}
	fflush(stdout);
	} /* while */
	fclose(tail);
	fflush(stdout);
}

