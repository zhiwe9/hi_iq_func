/* HI-IQ System, the High Information Internet Query System,
	Copyright 1995, 1996, 1997, 1998 Utah Office of Health Data Analysis.

	hi_iq_survey.c 02/20/2006
	to build up SAS program proc surveymean.

	We provide the interactive interface to make your data available
	to public through Internet.
*/

#include "hi_iq.h"
#include "hi_iq_var.h"

char * survey_array[16];
int survey_array_i;
int _flag_;
int _next_;

void sas_bld_survey() {
	FILE * sas;
	char str[STRING_N], * tmp, * tmp2;
	int i;

	if (form==21 || form==23 || form==23) {
	  //printf("\n<SUB_POPULATION>");
	}

	for (survey_array_i=0; survey_array_i<16; survey_array_i++)
	  survey_array[survey_array_i]=0;
	survey_array_i=0;

	tmp = get_sasname(str);
	strcat(tmp, ".sas");
	if (!(sas=fopen(tmp, "w"))) hbase_error(5, NULL);

	fprintf(sas, "\n /* Following codes from sas_bld_survey() */");
	if (!(tmp=find_path("saspath"))) hbase_error(6, NULL);
	fprintf(sas, "\n libname data \"%s\";", tmp);
	tmp2=find_path("saspop");
	fprintf(sas, "\n libname pop \"%s\";", tmp2 ? tmp2 : tmp);
	fprintf(sas, "\n options mlogic mprint source source2;");
	fflush(sas);
	sas_dataFrame_cross(sas);
	fflush(sas);

	sas_select_survey(sas);
	fflush(sas);

        sas_cross_bld(sas, "cross1", "tmp");
        sas_cross_bld(sas, "cross2", "tmp");
        sas_cross_bld(sas, "cross3", "tmp");

	sas_no_obs(sas);
	fflush(sas);

	sas_func_def(sas);

	sas_func_bld(sas, h_func);
	fflush(sas);
	fclose(sas);
        func_test_out();

	if (form==21 || form==23 || form==23) {
	  //printf("\n</SUB_POPULATION>");
	}
}

void sas_select_survey(FILE * sas) {
	char * tmp, *tmp2, str[BUFFER_N];
	int i, j, c, flag=0;
	VARI ** vari_ptr;

	fprintf(sas, "\n\n/* Following codes from sas_select_survey() */");
	if ((tmp2=find_path("data_where"))) sprintf(str, " (where=(%s)) ", tmp2);
	else tmp2=NULL;

	tmp=find_path("dataset");
	if (form>0 && form!=3 && form!=4 && form!=6 && form!=8
		&& form!=21 && form!=22 && form!=23 && form!=30) {
		printf("\n<B><FONT SIZE = \"+2\"> Query: </FONT>%s<UL><I>", tmp? tmp : "no dataset name");
	}
	fprintf(sas, "\n data tmp;");
	if (!(tmp=find_path("sasdata"))) hbase_error(7, "sasdata");
	fprintf(sas, "\n set data.%s %s end = eof;", tmp, tmp2? str : "");
	fprintf(sas, "\n retain flag 0;");
/*
	fprintf(sas, "\n x=1;");
*/

	_flag_ = 0;
	for (i=0; i<h_name_i; i++) {
		j = atoi(h_name[i]->type2);
		if (filterExcluded(h_name[i])) continue;
		if (j==0 || j==1 || j==3 || j==5) {
			if ((vari_ptr=find_vari(h_name[i]->name_html,1,j,&c))) {
				if (c<=0 || !strlen(de_space(vari_ptr[0]->value))
					 || (!(vari_ptr[0]->name_ptr->name_sas) && j!=5)) continue;
		   		if (strcmp(h_name[i]->note, "99")) {
				    sas_vari_bld(vari_ptr, sas, c, flag);
				    flag = 1;
				    _flag_ = flag;
				}
				free(vari_ptr);
				vari_ptr=NULL;
			}
		}
	}

	if (flag) {
		fprintf(sas, "\n then do;");
		fprintf(sas, "\n goto next%d;", _next_);
		fprintf(sas, "\n end;");
		fprintf(sas, "\n else goto no_obs;");
	}

	fprintf(sas, "\n next%d:", _next_);
	_next_ ++;
	for (i=0; i<h_name_i; i++) {
		j = atoi(h_name[i]->type2);
		if (j==0 || j==1 || j==3 || j==5) {
			if ((vari_ptr=find_vari(h_name[i]->name_html,1,j,&c))) {
				if (c<=0 || !strlen(de_space(vari_ptr[0]->value))
					 || (!(vari_ptr[0]->name_ptr->name_sas) && j!=5)) continue;
		   		if (!strcmp(h_name[i]->note, "99")) {
				    sas_vari_flag(vari_ptr, sas, c, flag);
				}
				free(vari_ptr);
				vari_ptr=NULL;
				flag = 1;
				_flag_ = flag;
			}
		}
	}
	
	fflush(stdout);
}
		
void sas_vari_flag(VARI ** vari_p, FILE * sas, int c, int flag) {
  int i, j;
  char * cross;

  fprintf(sas, "\n\n/* ---Following codes from sas_vari_flag() %s %d*/", 
		vari_p[0]->name_ptr->name_sas, c);

  cross=find_path("cross1");
  if (!strcmp(vari_p[0]->name_ptr->name_html, cross)) return;
  cross=find_path("cross2");
  if (!strcmp(vari_p[0]->name_ptr->name_html, cross)) return;
  cross=find_path("cross3");
  //if (!cross) return;
  //if (!strcmp(vari_p[0]->name_ptr->name_html, cross)) return;
  
  fprintf(sas, "\n %s ( ", flag? "if" : "if");
  j=atoi(vari_p[0]->name_ptr->type2);
  switch(j) {
    case 0: sas_type1(vari_p, sas, c, form);
  	    break;
    case 1:
    case 3:
	    sas_type2(vari_p, sas, c, form);
    	    break;
    case 5: 
	    sas_type5(vari_p, sas, c, form);
	    break;

  }
  fprintf(sas, "\n )");

/*
  fprintf(sas, "\n if (%s in (", vari_p[0]->name_ptr->name_sas);
  for (i=0; i<c; i++) {
    if (strcmp(vari_p[0]->name_ptr->type1, "num")) {
      fprintf(sas, "%s '%s'", i==0? "":", ", vari_p[i]->value);
    }
    else {
      fprintf(sas, "%s %s", i==0? "":", ", vari_p[i]->value);
    }
  }
  fprintf(sas, "))");
*/
  fprintf(sas, " then %s_sflag=1;", vari_p[0]->name_ptr->name_sas);
  fprintf(sas, "\n else %s_sflag=0;", vari_p[0]->name_ptr->name_sas);

  survey_array[survey_array_i]=(char *) malloc(strlen(vari_p[0]->name_ptr->name_sas)+7);
  sprintf(survey_array[survey_array_i], "%s_sflag", vari_p[0]->name_ptr->name_sas);
  survey_array_i++;
}

void sas_vari_flag_after(VARI ** vari_p, FILE * sas, int c, int flag) {
  char *cross1, *cross2, *cross3;

  fprintf(sas, "\n\n/* Following codes from sas_vari_flag_after() %s %d*/", 
		vari_p[0]->name_ptr->name_sas, c);

  cross1=find_path("cross1");
  cross2=find_path("cross2");
  cross3=find_path("cross3");

  if (cross3) {
  if (!strcmp(vari_p[0]->name_ptr->name_html, cross1)
    ||!strcmp(vari_p[0]->name_ptr->name_html, cross2)
    ||!strcmp(vari_p[0]->name_ptr->name_html, cross3)) {
	sas_vari_bld(vari_p, sas, c, 0);
	//sas_vari_bld(vari_p, sas, c, flag);
	  fprintf(sas, ";");
  }
  else fprintf(sas, "\n if  %s_sflag^=0;", vari_p[0]->name_ptr->name_sas);
  }
  else {
  if (!strcmp(vari_p[0]->name_ptr->name_html, cross1)
    ||!strcmp(vari_p[0]->name_ptr->name_html, cross2)) {
	sas_vari_bld(vari_p, sas, c, 0);
	//sas_vari_bld(vari_p, sas, c, flag);
	  fprintf(sas, ";");
  }
  else fprintf(sas, "\n if  %s_sflag^=0;", vari_p[0]->name_ptr->name_sas);
  }

}

void sas_special_survey(FILE *sas, FUNC **func) {
	char c1[STRING_N], c2[STRING_N], p1[STRING_N], p2[STRING_N];
	char *tmp, buf[BUFFER_N], *dx[1], sflags1[BUFFER_N], sflags2[BUFFER_N];
	char **ptA, **feA;
	int i, j, crosses_cnt, crosses_cnt2, cnt2;
	FUNC * func_p, * func_p2;
	FUNC *func_n, *func_pop;
	char *n_v=NULL, *pop_v=NULL;
	REPLACE ** cross;
	CROSS ** crosses;

	fprintf(sas, "\n\n/* Following codes from sas_special_survey() */\n");
        ptA=passThrough(&crosses_cnt);
        crosses=find_crosses(&crosses_cnt2);
        feA=filterExclude(&cnt2);
        if (!(cross=(REPLACE**) malloc((crosses_cnt+crosses_cnt2+cnt2+25)*sizeof(REPLACE*)))) hbase_error(3, "func-4");

        sas_find_cross(c1, c2, p1, p2);
        for (i=0; i<crosses_cnt+crosses_cnt2+cnt2+24; i++)
                if (!(cross[i]=(REPLACE*) malloc(sizeof(REPLACE)))) hbase_error(3, "func-4");
  
        cross[0]->key="cross1";
        if (c1[0]) cross[0]->rep=c1;
        else cross[0]->rep=NULL;
        cross[1]->key="cross2";
        if (c2[0]) cross[1]->rep=c2;
        else cross[1]->rep=NULL;
        cross[2]->key="popcross1";
        if (p1[0]) cross[2]->rep=p1;
        else cross[2]->rep=NULL;
        cross[3]->key="popcross2";
        if (p2[0]) cross[3]->rep=p2;
        else cross[3]->rep=NULL;
 
	for (i=4, j=0; j<crosses_cnt2; i++, j++) {
	    cross[i]->key=malloc(7);
	    sprintf(cross[i]->key, "%s", crosses[j]->name);
	    cross[i]->rep=crosses[j]->name_ptr->name_sas;

	    i++;
	    cross[i]->key=malloc(10);
	    sprintf(cross[i]->key, "popcross%d", j+1);
	    cross[i]->rep=crosses[j]->name_ptr->name_pop;
	}
	if (i<9) {
	    cross[i]->key="cross3";
	    cross[i]->rep=NULL;
	    fprintf(sas, "\n\n/* cross3 -- %s */\n", cross[i]->rep);
	    i++;
	}

        for (i=4; i<14; i++) {
                cross[i]->key=malloc(8);
                sprintf(cross[i]->key, "spvar%d", i-3);
                cross[i]->rep=find_path(cross[i]->key);
        }
        for (i=i, j=0; j<crosses_cnt; i++, j++) {
                cross[i]->key=ptA[j];
                cross[i]->rep=find_path(cross[i]->key);
        }
        for (i=i, j=0; j<cnt2; i++, j++) {
                cross[i]->key=feA[j];
                cross[i]->rep=getVariValues(cross[i]->key);
        }

	if (func_p=find_func(func, "include")) {
	    cross[i]->key="include";
	    tmp = get_sasname(buf);
	    strcat(buf, "_include.sas");
	    if ((!(cross[i]->rep=malloc(strlen(buf)+3)))) hbase_error(3, buf);
	    sprintf(cross[i]->rep, "'%s'", buf);
	    i++;
	}

	if (survey_array_i>0) {
	  strcpy(sflags1, " * ");
	  strcat(sflags1, survey_array[0]);
	  strcpy(sflags2, survey_array[0]);
	  for (j=1; j<survey_array_i; j++) {
	    strcat(sflags1, " * ");
	    strcat(sflags1, survey_array[j]);
	    strcat(sflags2, " ");
	    strcat(sflags2, survey_array[j]);
          }
	}
	else {
	  strcpy(sflags1, "");
	  strcpy(sflags2, "");
	}
	cross[i]->key="surveyvar1";
	cross[i]->rep=sflags1;
	i++;
	cross[i]->key="surveyvar2";
	cross[i]->rep=sflags2;
	i++;
	cross[i]->key="ageAdjustedFilter";
	cross[i]->rep=sas_ageAdjustedFilter();
	i++;  
	cross[i]=NULL;

	if (func_p=find_func(func, "include")) {
	     sas_bld_include(cross, func_p->value, buf);
	}

	if (func_p=find_func(func, "data_where")) {
		data_where(sas, func_p, "tmp");
	}

	tmp=find_path("saspopdata");
	if (tmp && strcmp(tmp, "none")) {
		sas_pop_select(sas, "saspopdata");
		if (func_p=find_func(func, "pop_where")) {
			data_where(sas, func_p, "poptmp");
		}
	}

	if (!(func_p=find_func(func, "script"))) hbase_error(47, "script");
	for (i=0; func_p->script[i]; i++) {
		tmp=replace_line(func_p->script[i], buf, cross);
		fprintf(sas, "%s", tmp);
	}

	sas_select_after_survey(sas);

	func_p=find_func(func, "out_detail");
	func_p2=find_func(func, "no_total");
/*
	if (!func_p2 || strcmp(func_p2->value, "true")) {
	fprintf(sas, "\n proc summary data=tmp;");
	fprintf(sas, "\n  var ");
	for (i=0; func_p->script[i] && i<2; i++) {
	  strcpy(buf, func_p->script[i]);
	  tmp=strchr(de_space(buf), ' ');
	  if (tmp) tmp[0]=0;
	  fprintf(sas, " %s ", buf);
	}
	fprintf(sas, "; \n  class");
	for (i=0; cross[i]; i++) {
	  if (!strcmp(cross[i]->key, "cross1") 
		|| !strcmp(cross[i]->key, "cross3")
		|| !strcmp(cross[i]->key, "surveyvar2")) {
	    if (cross[i]->rep) fprintf(sas, " %s ", cross[i]->rep);
	  }
	}
	fprintf(sas, ";");
	fprintf(sas, "\n output out=total sum(");
	for (i=0; func_p->script[i] && i<2; i++) {
	  strcpy(buf, func_p->script[i]);
	  tmp=strchr(de_space(buf), ' ');
	  if (tmp) tmp[0]=0;
	  fprintf(sas, " %s ", buf);
	}
	fprintf(sas, ")=;");
	fprintf(sas, "\n run;");

fprintf(sas, "\n title \"survey special --1-- total\";");
fprintf(sas, "\n proc print data=total;");
fprintf(sas, "\n run;");

	fprintf(sas, "\n data total;");
	fprintf(sas, "\n set total;");

	for (i=0; cross[i]; i++) {
	  if (!strcmp(cross[i]->key, "cross1") 
		|| !strcmp(cross[i]->key, "cross3")) {
	    if (cross[i]->rep) fprintf(sas, "\n if %s=. then delete; ", cross[i]->rep);
	  }
	}

	for (i=0; i<survey_array_i; i++) {
	  fprintf(sas, "\n if %s=. then delete; ", survey_array[i]);
        }

fprintf(sas, "\n title \"survey special --2---- total\";");
fprintf(sas, "\n proc print data=total;");
fprintf(sas, "\n run;");

	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n set tmp total;");
	for (i=0; cross[i]; i++) {
	  if (!strcmp(cross[i]->key, "cross1") 
		|| !strcmp(cross[i]->key, "cross3")) {
	    if (cross[i]->rep) fprintf(sas, "\n if %s=-1 then %s=.; ", cross[i]->rep, cross[i]->rep);
	  }
	}
	for (i=0; i<survey_array_i; i++) {
	  fprintf(sas, "\n if %s=-1 then %s=.; ", survey_array[i], survey_array[i]);
	}
	fprintf(sas, "\n run;");
	}

*/
fprintf(sas, "\n title \"survey special --3-- tmp\";");
fprintf(sas, "\n proc print data=tmp;");
fprintf(sas, "\n run;");

	if ((func_n=find_func(func, "n_variable"))) n_v=func_n->value;
	if (n_v==NULL) n_v="n";
	if ((func_pop=find_func(func, "pop_variable"))) pop_v=func_pop->value;
	if (!(func_p2=find_func(func, "out_variable"))) hbase_error(47, "out_variable");
	if (!(func_p=find_func(func, "out_detail"))) {
	    sas_out(sas, func_p2->value, " ", 0);
	}
	else {
		for (i=0; func_p->script[i]; i++) {
			if (strstr(func_p->script[i], func_p2->value))
				_out_variable=i+1;
		}

	if (form==21) 
	  sas_lbl_out3(sas, func_p2->value, " ", func_p->script, func_p->value, i, n_v, pop_v);
	else if (form==23 || form==23)  {
	  sas_lbl_out2(sas, func_p2->value, " ", func_p->script, func_p->value, i, n_v, pop_v);
		}
	  else {

		j=atoi(find_path("form"));
		if (j==2) sas_out(sas, func_p2->value, " ", 0);
		else if (j==5 || j==6 || j==22 || j==23 || j==30) sas_lbl_out2(sas, func_p2->value, " ", func_p->script, func_p->value, i, n_v, pop_v);
		else sas_lbl_out(sas, func_p2->value, " ", func_p->script, func_p->value, i, n_v, pop_v);
	  }
	}
}

void sas_special_survey2(FILE *sas, FUNC **func) {
	char c1[STRING_N], c2[STRING_N], p1[STRING_N], p2[STRING_N];
	char *tmp, buf[BUFFER_N], *dx[1], sflags1[BUFFER_N], sflags2[BUFFER_N];
	int i, j, crosses_cnt;
	FUNC * func_p, * func_p2;
	FUNC *func_n, *func_pop;
	char *n_v=NULL, *pop_v=NULL;
	REPLACE * cross[38];
	CROSS ** crosses;

	fprintf(sas, "\n\n/* Following codes from sas_special_survey2() */\n");
	crosses=find_crosses(&crosses_cnt);
	for (i=0; i<37; i++) 
		if (!(cross[i]=(REPLACE*) malloc(sizeof(REPLACE)))) hbase_error(3, "func-4");
	for (i=0, j=0; i<crosses_cnt; i++) {
	    cross[j]->key=malloc(7);
	    sprintf(cross[j]->key, "%s", crosses[i]->name);
	    cross[j]->rep=crosses[i]->name_ptr->name_sas;
	    j++;

	    cross[j]->key=malloc(10);
	    sprintf(cross[j]->key, "popcross%d", i+1);
	    cross[j]->rep=crosses[i]->name_ptr->name_pop;
	    j++;
	}
	if (i<3) {
	    cross[j]->key="cross3";
	    cross[j]->rep=NULL;
	    fprintf(sas, "\n\n/* cross3 -- %s */\n", cross[j]->rep);
	    j++;
	}
	if (func_p=find_func(func, "include")) {
	    cross[j]->key="include";
	    tmp = get_sasname(buf);
	    strcat(buf, "_include.sas");
	    if ((!(cross[j]->rep=malloc(strlen(buf)+3)))) hbase_error(3, buf);
	    sprintf(cross[j]->rep, "'%s'", buf);
	    j++;
	}

	for (i=j; i<34; i++) {
		cross[i]->key=malloc(8);
		sprintf(cross[i]->key, "spvar%d", i-3);
		cross[i]->rep=find_path(cross[i]->key);
	}
	if (survey_array_i>0) {
	  strcpy(sflags1, " * ");
	  strcat(sflags1, survey_array[0]);
	  strcpy(sflags2, survey_array[0]);
	  for (i=1; i<survey_array_i; i++) {
	    strcat(sflags1, " * ");
	    strcat(sflags1, survey_array[i]);
	    strcat(sflags2, " ");
	    strcat(sflags2, survey_array[i]);
          }
	}
	else {
	  strcpy(sflags1, "");
	  strcpy(sflags2, "");
	}
	cross[34]->key="surveyvar1";
	cross[34]->rep=sflags1;
	cross[35]->key="surveyvar2";
	cross[35]->rep=sflags2;
	cross[36]->key="ageAdjustedFilter";
	cross[36]->rep=sas_ageAdjustedFilter();
	  
	cross[37]=NULL;

	if (func_p=find_func(func, "include")) {
	     sas_bld_include(cross, func_p->value, buf);
	}

	if (func_p=find_func(func, "data_where")) {
		data_where(sas, func_p, "tmp");
	}

	if (func_p=find_func(func, "data_filter")) {
		data_filter(sas, func_p, "tmp");
	}

	tmp=find_path("saspopdata");
	if (tmp && strcmp(tmp, "none")) {
		sas_pop_select(sas, "saspopdata");
		if (func_p=find_func(func, "pop_where")) {
			data_where(sas, func_p, "poptmp");
		}
	}

	if (!(func_p=find_func(func, "script"))) hbase_error(47, "script");
	for (i=0; func_p->script[i]; i++) {
		tmp=replace_line(func_p->script[i], buf, cross);
		fprintf(sas, "%s", tmp);
	}

	sas_select_after_survey(sas);

	func_p=find_func(func, "out_detail");
	func_p2=find_func(func, "no_total");

	if (!func_p2 || strcmp(func_p2->value, "true")) {
	fprintf(sas, "\n proc summary data=tmp;");
	fprintf(sas, "\n  var ");
	for (i=0; func_p->script[i] && i<2; i++) {
	  strcpy(buf, func_p->script[i]);
	  tmp=strchr(de_space(buf), ' ');
	  if (tmp) tmp[0]=0;
	  fprintf(sas, " %s ", buf);
	}
	fprintf(sas, "; \n  class");
	for (i=0; cross[i]; i++) {
	  if (!strcmp(cross[i]->key, "cross1") 
		|| !strcmp(cross[i]->key, "cross3")
		|| !strcmp(cross[i]->key, "surveyvar2")) {
	    if (cross[i]->rep) fprintf(sas, " %s ", cross[i]->rep);
	  }
	}
	fprintf(sas, ";");
	fprintf(sas, "\n output out=total sum(");
	for (i=0; func_p->script[i] && i<2; i++) {
	  strcpy(buf, func_p->script[i]);
	  tmp=strchr(de_space(buf), ' ');
	  if (tmp) tmp[0]=0;
	  fprintf(sas, " %s ", buf);
	}
	fprintf(sas, ")=;");
	fprintf(sas, "\n run;");

fprintf(sas, "\n title \"survey special --1-- total\";");
fprintf(sas, "\n proc print data=total;");
fprintf(sas, "\n run;");

	fprintf(sas, "\n data total;");
	fprintf(sas, "\n set total;");
/*
	for (i=0; cross[i]; i++) {
	  if (!strcmp(cross[i]->key, "cross1") 
		|| !strcmp(cross[i]->key, "cross3")) {
	    if (cross[i]->rep) fprintf(sas, "\n if %s=. then delete; ", cross[i]->rep);
	  }
	}
*/
/*
	for (i=0; i<survey_array_i; i++) {
	  fprintf(sas, "\n if %s=. then %s=-1; ", survey_array[i]);
        }
*/


fprintf(sas, "\n title \"survey special --2-- total\";");
fprintf(sas, "\n proc print data=total;");
fprintf(sas, "\n run;");
	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n set tmp total;");
	for (i=0; cross[i]; i++) {
	  if (!strcmp(cross[i]->key, "cross1") 
		|| !strcmp(cross[i]->key, "cross3")) {
	    if (cross[i]->rep) fprintf(sas, "\n if %s=-1 then %s=.; ", cross[i]->rep, cross[i]->rep);
	  }
	}
	for (i=0; i<survey_array_i; i++) {
	  fprintf(sas, "\n if %s=-1 then %s=.; ", survey_array[i], survey_array[i]);
	}
	fprintf(sas, "\n run;");
	}

fprintf(sas, "\n title \"survey special --3-- tmp\";");
fprintf(sas, "\n proc print data=tmp;");
fprintf(sas, "\n run;");

	if ((func_n=find_func(func, "n_variable"))) n_v=func_n->value;
	if (n_v==NULL) n_v="n";
	if ((func_pop=find_func(func, "pop_variable"))) pop_v=func_pop->value;
	if (!(func_p2=find_func(func, "out_variable"))) hbase_error(47, "out_variable");
	if (!(func_p=find_func(func, "out_detail"))) {
	    sas_out(sas, func_p2->value, " ", 0);
	}
	else {
		for (i=0; func_p->script[i]; i++) {
			if (strstr(func_p->script[i], func_p2->value))
				_out_variable=i+1;
		}

	if (form==21) 
	  sas_lbl_out3(sas, func_p2->value, " ", func_p->script, func_p->value, i, n_v, pop_v);
	else if (form==22 || form==23 || form==30)  
	  sas_lbl_out2(sas, func_p2->value, " ", func_p->script, func_p->value, i, n_v, pop_v);
	  else {

		j=atoi(find_path("form"));
		if (j==2) sas_out(sas, func_p2->value, " ", 0);
		else if (j==5 || j==6 || j==22 || j==23 || j==30) sas_lbl_out2(sas, func_p2->value, " ", func_p->script, func_p->value, i, n_v, pop_v);
		else sas_lbl_out(sas, func_p2->value, " ", func_p->script, func_p->value, i, n_v, pop_v);
	  }
	}
}

void sas_select_after_survey(FILE * sas) {
	char * tmp, *tmp2, str[BUFFER_N];
	int i, j, c, flag=0;
	VARI ** vari_ptr;

	fprintf(sas, "\n\n/* Following codes from sas_select_after_survey() */");
	fprintf(sas, "\n data tmp;");
	fprintf(sas, "\n set tmp;");

	_flag_ = 0;

	for (i=0; i<h_name_i; i++) {
		j = atoi(h_name[i]->type2);
		if (j==0 || j==1 || j==3|| j==5) {
			if ((vari_ptr=find_vari(h_name[i]->name_html,1,j,&c))) {
				if (c<=0 || !strlen(de_space(vari_ptr[0]->value))
					 || (!(vari_ptr[0]->name_ptr->name_sas) && j!=5)) continue;
		   		if (!strcmp(h_name[i]->note, "99")) {
				    sas_vari_flag_after(vari_ptr, sas, c, flag);
				    flag = 1;
				    _flag_ = flag;
				}
				free(vari_ptr);
				vari_ptr=NULL;
			}
		}
	}
	
	if (flag) {
	  fprintf(sas, "\n run;");
	}
	fflush(stdout);
}
		
char*  sas_ageAdjustedFilter() {
	char * tmp, *tmp2, str[BUFFER_N];
	int i, j, c, flag=0;
	VARI ** vari_ptr;
	FILE * tmpsas;

	_flag_ = 0;
	tmpsas=tmpfile();
	fprintf(tmpsas, "\n/* following codes from ageAdjustedFilter */ \n");
	for (i=0; i<survey_array_i; i++) {
	  fprintf(tmpsas, "\n if %s=. then delete; ", survey_array[i]);
        }

	for (i=0; i<h_name_i; i++) {
		j = atoi(h_name[i]->type2);
		if (j==0 || j==1 || j==3|| j==5) {
			if ((vari_ptr=find_vari(h_name[i]->name_html,1,j,&c))) {
				if (c<=0 || !strlen(de_space(vari_ptr[0]->value))
					 || (!(vari_ptr[0]->name_ptr->name_sas) && j!=5)) continue;
		   		if (!strcmp(h_name[i]->note, "99")) {
				    sas_vari_flag_after(vari_ptr, tmpsas, c, flag);
				    flag = 1;
				    _flag_ = flag;
				}
				free(vari_ptr);
				vari_ptr=NULL;
			}
		}
	}

	rewind(tmpsas);
	i=0;
	while(!feof(tmpsas)) {
	  if (!(tmp=fgets(str, BUFFER_N, tmpsas))) break;;
	  i+=strlen(tmp);
	}
	if (!(tmp2=(char*)malloc((i+10)*sizeof(char)))) hbase_error(3, "ageAdjustedFilter");
	tmp2[0]=0;
	rewind(tmpsas);
	while(!feof(tmpsas)) {
	  if (!(tmp=fgets(str, BUFFER_N, tmpsas))) break;;
	  strcat(tmp2, tmp);
        }

	fclose(tmpsas);
	return tmp2;
}
		
