/* HI-IQ System, the High Information Internet Query System,
	Copyright 1995, 1996, 1997, 1998 Utah Office of Health Data Analysis.

	hi_iq.c	11/11/98
	main entry of the program.

	We provide the interactive interface to make your data available
	to public through Internet.
*/

#include "hi_iq.h"

PATH ** h_path;
NAME ** h_name;
VARI ** h_vari;
USER ** h_user;
FUNC ** h_func;
MAP  ** h_map;

int     content_type=0;
int	form=1;
int     xml=0;
int	_label=0;
int	_out_variable=3;
int     h_path_i=0;
int     h_name_i=0;
int     h_vari_i=0;
int 	h_user_i=0;
int 	h_map_i=0;
 
char *  h_sasname=NULL;
char *_cross_1=NULL;
char *_cross_2=NULL;
char *_cross_3=NULL;

/* main entry of the program */
int main(int argc, char *argv[]) {
    int test, sas, j;
	char * method;

	char *qt, *tmp, str[BUFFER_N], str2[BUFFER_N], buf[BUFFER_N];
	FILE *test_file;

	//printf("Content-type: text/html%c%c",10,10); 
		
	method=getenv("REQUEST_METHOD");
/*	for method="POST" */
	if (method && !strcmp(method, "POST")) {
		j=atoi(getenv("CONTENT_LENGTH")); 
		if (!(qt=(char *)malloc(j+2))) hbase_error(3, "main-1");
		tmp=fgets(qt, j+1, stdin);
	}

/*	for method="GET" */
	else if (method && !strcmp(method, "GET")) {
    		if (!(qt = getenv("QUERY_STRING"))) hbase_error(1, "main-2");
	}

/*	for testing */
	else {
		if (!(test_file=fopen("url.test", "r"))) hbase_error(38, "url.test");
		if (!(qt=fgets(buf, BUFFER_N, test_file))) hbase_error(39, NULL);
	}

/*	cleaning the query string passed by web server to 
	eliminate invalid input */
	query_clean(qt, 1);
	//if ((tmp=query_drill(qt))) qt=tmp;
	//query_clean(qt, 2);
	if (!(tmp=(char *)malloc((strlen(qt)+1)))) hbase_error(3, "main-2");
	strcpy(tmp, qt);

/* read configuration file, parse query string into variables and values, 
	based on output format request to send out MIME header */
	query_conf(&qt);
	query_vari(qt);

	tmp=find_path("output");
	form=atoi(find_path("form"));
	if (tmp && !strcmp(tmp, "xml") ) {
	  if (form==23 || form==30) reset_path("form", "30");
	  else reset_path("form", "22");
	}

	form=atoi(find_path("form"));
	if (form==21 || form==22 || form==23 || form==30) xml=1;
	else xml=0;
     
	if (form==8) {
		printf("Content-type: application/vnd.ms-excel%c%c",10,10); 
		fflush(stdout);
	}
        else if (form==21 || form==22 || form==23 || form==30) {
		printf("Content-type: text/plain%c%c", 10, 10); 
		fflush(stdout);
		std_html(1, 0);
		xml_query();
        }
	else if (form>0 && form!=3 && form!=4 && form!=6) {
		printf("Content-type: text/html%c%c",10,10); 
		fflush(stdout);
		std_html(1, 0);
	}
        else  {
		printf("Content-type: text/html%c%c",10,10); 
		fflush(stdout);
	}
	content_type=1;

/*	go to the workpath */
#ifdef WIN_NT
	if ((qt=find_path("workpath"))) _chdir(qt);
#else
qt=find_path("workpath");
//printf("\n qt-----*%s", qt);
	if ((qt=find_path("workpath"))) chdir(qt);
#endif

/*	query_save(tmp);*/
	free(tmp);

/* access control */
    if ((tmp=find_path("logon"))) {
    	j=atoi(tmp);
    	if (j==1 && !user_check(0)) {
            deny_access();
            hbase_clear();
	    exit(0);
        }
	else if (j==2 && !role_check()) {
	    deny_access();
	    hbase_clear();
	    exit(0);
	}
    }
	
/* output configuration and variable values for debug */
        test=atoi(find_path("test"));
	sas=atoi(find_path("sas"));
	if (xml && (test>0 || sas>0)) printf("\n<DEBUGS>");
	test_out(test);
	tmp=find_path("survey");
	if (tmp && atoi(tmp)==1) {
		sas_bld_survey();
	}
	else {
		sas_bld();
	}

if (test) {printf("\n after sas_bld."); fflush(stdout);}
#ifndef WIN_NT
/* on Unix platform, fork another process for mail output */
	if (form==3 || form==4 || form==6) {
		signal(SIGCHLD, SIG_IGN);
/*
		chdir("/");
*/
		j=fork();
		if (j<0) hbase_error(35, "Can not fork.");
		if (j>0) {
			mail_out_std();
/*
			hbase_clear();
*/
			exit(0);
		}
	}
#endif

/* run SAS */
	qt=get_sasname(str2);
	if (!(tmp=find_path("sas_bin"))) tmp="sas";
	sprintf(str, "%s %s.sas", tmp, qt);
	system(str);

/* SAS output for debug */
	switch(sas) {
		case 1: std_html(4, 1); break;
		case 2: std_html(5, 1); break;
		case 3: std_html(3, 1); break;
		case 4: std_html(6, 1); break;
		default: break;
	}
	if (xml && (test>0 || sas>0)) printf("\n</DEBUGS>");
/* result output */
	switch(form) {
		case 0: plain_out(); break;
		case 1: tb_out(); break;
		case 2: gif_out(); break;
		case 3: mail_out(); break;
		case 4: comma_out(); break;
		case 5: tb_out2(); break;
		case 6: mail_out2(); break;
		case 8: excel_out(); break;
		case 21: xml_out(); break;
		case 22: xml_out2(); break;
		case 23: xml_out3(); break;
		case 30: xml_out3(); break;
		default: gif_out(); 
				printf("\n <hr>");
				tb_out(); 
				break;
	}

/* clean workpath */
	enc_note();
	hbase_clear();
	if (form>0 && form!=3 && form!=4 && form!=6 && form!=8) {
		std_html(2, 0);
	}
	return 0;
}


